package credit.accessory;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import credit.common.JsonResult;

/**
 * 统一错误码异常处理
 */
@RestControllerAdvice
@SuppressWarnings("rawtypes")
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);


    @ExceptionHandler(value = Exception.class)
    public JsonResult OtherExceptionHandler(HttpServletRequest request, Exception e) throws Exception {
        log.info("globalExceptionHandler::: URL=" + request.getRequestURL());
        log.error("globalExceptionHandler::: URL=" + request.getRequestURL());
        log.error("globalExceptionHandler:::Exception=" + e.getMessage());

        StackTraceElement[] list = e.getStackTrace();
        String traceMessage = "";
        for (StackTraceElement temp : list) {
            traceMessage += "at " + temp.getClassName() + "." + temp.getMethodName()
                    + "(" + temp.getFileName() + ":" + temp.getLineNumber() + ")\r\n";
        }
        log.error(traceMessage);
        return JsonResult.fail(JsonResult.FAIL, "系统异常");
    }

}

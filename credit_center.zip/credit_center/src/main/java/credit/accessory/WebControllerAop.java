package credit.accessory;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.RequestFacade;
import org.apache.catalina.connector.ResponseFacade;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.alibaba.fastjson.JSONArray;

import credit.common.JsonResult;

@Component
@Aspect
public class WebControllerAop {
    private Logger log = LoggerFactory.getLogger(getClass());
    
    @SuppressWarnings("rawtypes")
    @AfterReturning(value = "execution(* credit.controller..*.*(..))", returning = "keys")
    public void doAfterReturnAdvice1(JoinPoint joinPoint, Object keys) {

        try {

            if (!keys.getClass().equals(JsonResult.class)) {
                return;
            }

            Signature signature = joinPoint.getSignature();

            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
            HttpServletRequest request = (HttpServletRequest) requestAttributes.resolveReference(RequestAttributes.REFERENCE_REQUEST);

            Object[] requestParams = joinPoint.getArgs();
            JSONArray requestJson = new JSONArray();
            for (int i = 0; i < requestParams.length; i++) {
                if (requestParams[i].getClass().equals(RequestFacade.class)
                        || requestParams[i].getClass().equals(ResponseFacade.class)) {
                    continue;
                }
                requestJson.add(requestParams[i]);
            }
            JsonResult responseJson = (JsonResult) keys;
            String requestUri = request.getRequestURI();
            String contextPath = request.getContextPath();
            String url = requestUri.substring(contextPath.length());
            
        } catch (Exception e) {
        }
    }


    @Pointcut("execution(* credit.controller..*.*(..))")
    public void executeService() {

    }

    /*@Before("executeService()")
    public void doBeforeAdvice(JoinPoint joinPoint) {

        try {
            Signature signature = joinPoint.getSignature();
            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

            HttpServletRequest request = (HttpServletRequest) requestAttributes.resolveReference(RequestAttributes.REFERENCE_REQUEST);
            Object[] requestParams = joinPoint.getArgs();
            JSONArray vo = new JSONArray();
            for (int i = 0; i < requestParams.length; i++) {
                if (requestParams[i].getClass().equals(RequestFacade.class)) {
                    continue;
                }
                vo.add(requestParams[i]);
            }
            String requestUri = request.getRequestURI();
            String contextPath = request.getContextPath();
            String url = requestUri.substring(contextPath.length());
            if (includeUrls.contains(url)) {
                log.info(request.getMethod() + ":::" + signature.toShortString() + vo.toJSONString());
            }

        } catch (Exception e) {
        }
    }*/
}

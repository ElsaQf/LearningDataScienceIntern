package credit.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import credit.entity.UserInfo;
import credit.service.IUserInfoService;

@RestController
@RequestMapping("/user")
public class UserController {
	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
    @Autowired
    IUserInfoService userInfoService;
    
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public void test() throws Exception {
    	// 通过报告id查询用户认证表
    	UserInfo vo = userInfoService.getUserCreditInfoByRid("D1FK45464d3b1cd94b26a86e60c71e57d475");
        log.info(vo.getUser_name());
    }
    
}

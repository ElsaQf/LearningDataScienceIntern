package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.DishonestReport;

public interface DishonestReportRespository extends ElasticsearchRepository<DishonestReport, String> {

}

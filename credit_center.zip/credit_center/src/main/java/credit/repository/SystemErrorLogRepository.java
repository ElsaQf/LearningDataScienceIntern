package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.SystemErrorLog;

public interface SystemErrorLogRepository extends ElasticsearchRepository<SystemErrorLog, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.JdContactReport;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.repository
 * Created by bob on 18-7-7.
 * Description:   电商联系人
 *******************************************************************************/
public interface JdContactReportRepository extends ElasticsearchRepository<JdContactReport, String> {

}

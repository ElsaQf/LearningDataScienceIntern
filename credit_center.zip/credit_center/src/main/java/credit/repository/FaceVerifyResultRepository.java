package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.FaceVerifyResult;

public interface FaceVerifyResultRepository extends ElasticsearchRepository<FaceVerifyResult, String> {

}

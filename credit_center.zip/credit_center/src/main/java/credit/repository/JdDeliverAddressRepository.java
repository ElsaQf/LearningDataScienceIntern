package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.JdDeliverAddressReport;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.repository
 * Created by bob on 18-7-6.
 * Description:  电商地址分析
 *******************************************************************************/
public interface JdDeliverAddressRepository extends ElasticsearchRepository<JdDeliverAddressReport, String> {
}

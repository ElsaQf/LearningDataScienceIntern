package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.JdbOverdueData;

/**
 * @author: YCM
 * @date: 2018-12-03
 **/
public interface JdbOverdueDataRepository extends ElasticsearchRepository<JdbOverdueData, String> {

}

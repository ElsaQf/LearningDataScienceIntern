package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.JobInfoHistory;

public interface JobInfoHistoryRepository extends ElasticsearchRepository<JobInfoHistory, String> {

}

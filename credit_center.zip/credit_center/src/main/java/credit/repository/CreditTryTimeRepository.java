package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CreditTryTime;

public interface CreditTryTimeRepository  extends ElasticsearchRepository<CreditTryTime, String> {

}

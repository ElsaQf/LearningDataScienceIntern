package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.ShebaoInfo;

public interface ShebaoInfoRepository extends ElasticsearchRepository<ShebaoInfo, String> {

}

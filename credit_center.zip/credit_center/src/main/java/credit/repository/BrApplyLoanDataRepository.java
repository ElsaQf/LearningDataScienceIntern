package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.BrApplyLoanData;

/**
 * 黑名单
 * @author YCM
 * @date 2019年3月12日 下午1:53:22
 */
public interface BrApplyLoanDataRepository extends ElasticsearchRepository<BrApplyLoanData, String> {

}

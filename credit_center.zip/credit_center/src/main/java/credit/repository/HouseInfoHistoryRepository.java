package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.HouseInfoHistory;

public interface HouseInfoHistoryRepository extends ElasticsearchRepository<HouseInfoHistory, String> {

}
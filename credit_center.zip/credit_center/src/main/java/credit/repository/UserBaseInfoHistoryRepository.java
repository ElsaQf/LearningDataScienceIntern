package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.UserBaseInfoHistory;

public interface UserBaseInfoHistoryRepository extends ElasticsearchRepository<UserBaseInfoHistory, String> {

}

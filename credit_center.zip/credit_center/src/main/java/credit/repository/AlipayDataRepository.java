package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.AlipayData;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public interface AlipayDataRepository extends ElasticsearchRepository<AlipayData, String> {

}

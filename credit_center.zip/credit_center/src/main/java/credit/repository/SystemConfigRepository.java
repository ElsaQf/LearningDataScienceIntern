package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.SystemConfig;

public interface SystemConfigRepository extends ElasticsearchRepository<SystemConfig, String> {

}

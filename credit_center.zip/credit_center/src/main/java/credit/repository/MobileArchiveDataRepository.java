package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.MobileArchiveData;

public interface MobileArchiveDataRepository extends ElasticsearchRepository<MobileArchiveData, String> {

}

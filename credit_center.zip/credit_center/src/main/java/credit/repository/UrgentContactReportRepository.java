package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.UrgentContactReport;

public interface UrgentContactReportRepository extends ElasticsearchRepository<UrgentContactReport, String> {
	
}

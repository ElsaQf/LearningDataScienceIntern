package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.EarnInfoHistory;

public interface EarnInfoHistoryRepository extends ElasticsearchRepository<EarnInfoHistory, String> {

}

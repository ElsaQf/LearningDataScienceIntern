package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.WyjtData;

/**
 * 黑名单
 * @author YCM
 * @date 2019年3月12日 下午1:53:22
 */
public interface WyjtDataRepository extends ElasticsearchRepository<WyjtData, String> {

}

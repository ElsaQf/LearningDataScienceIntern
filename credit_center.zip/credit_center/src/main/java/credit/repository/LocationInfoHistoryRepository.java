package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.LocationInfoHistory;

public interface LocationInfoHistoryRepository extends ElasticsearchRepository<LocationInfoHistory, String> {

}
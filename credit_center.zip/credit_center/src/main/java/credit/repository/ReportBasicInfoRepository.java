package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.ReportBasicInfo;

public interface ReportBasicInfoRepository extends ElasticsearchRepository<ReportBasicInfo, String> {

}
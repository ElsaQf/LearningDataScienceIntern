package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.MobileBillReport;

public interface MobileBillReportRepository extends ElasticsearchRepository<MobileBillReport, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.GjjInfo;

public interface GjjInfoRepository extends ElasticsearchRepository<GjjInfo, String> {
	
}

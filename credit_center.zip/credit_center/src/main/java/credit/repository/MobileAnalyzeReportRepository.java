package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.MobileAnalyzeReport;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.repository
 * Created by bob on 18-9-14.
 * Description:  
 *******************************************************************************/
public interface MobileAnalyzeReportRepository extends ElasticsearchRepository<MobileAnalyzeReport, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CreditTaskLog;

public interface CreditTaskLogRepository extends ElasticsearchRepository<CreditTaskLog, String> {

}

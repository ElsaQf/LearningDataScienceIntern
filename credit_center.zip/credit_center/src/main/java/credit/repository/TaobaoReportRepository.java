package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.TaobaoReport;

public interface TaobaoReportRepository extends ElasticsearchRepository<TaobaoReport, String> {

}

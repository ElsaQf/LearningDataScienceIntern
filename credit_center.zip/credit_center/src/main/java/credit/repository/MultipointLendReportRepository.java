package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.MultipointLendReport;

public interface MultipointLendReportRepository  extends ElasticsearchRepository<MultipointLendReport, String> {

}

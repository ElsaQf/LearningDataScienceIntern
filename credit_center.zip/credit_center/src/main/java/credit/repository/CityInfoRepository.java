package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CityInfo;

public interface CityInfoRepository  extends ElasticsearchRepository<CityInfo, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.TaobaoData;

public interface TaobaoDataRepository extends ElasticsearchRepository<TaobaoData, String> {

}

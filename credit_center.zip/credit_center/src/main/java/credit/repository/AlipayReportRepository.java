package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.AlipayReport;

public interface AlipayReportRepository extends ElasticsearchRepository<AlipayReport, String> {

}

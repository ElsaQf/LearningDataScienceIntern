package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.StudentInfoReport;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.repository
 * Created by bob on 18-7-6.
 * Description:  学信信息
 *******************************************************************************/
public interface StudentInfoRepository extends ElasticsearchRepository<StudentInfoReport,String>{
}

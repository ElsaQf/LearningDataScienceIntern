package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CarInfoHistory;

public interface CarInfoHistoryRepository extends ElasticsearchRepository<CarInfoHistory, String> {

}

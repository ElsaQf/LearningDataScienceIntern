package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CreditWhiteList;

public interface CreditWhiteListRepository  extends ElasticsearchRepository<CreditWhiteList, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.CreditRouteConfig;

public interface CreditRouteConfigRepository extends ElasticsearchRepository<CreditRouteConfig, String> {

}

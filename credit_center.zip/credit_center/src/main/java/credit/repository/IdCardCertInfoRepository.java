package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.IdCardCertInfo;

public interface IdCardCertInfoRepository extends ElasticsearchRepository<IdCardCertInfo, String> {

}

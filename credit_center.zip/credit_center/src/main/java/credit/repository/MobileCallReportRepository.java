package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.MobileCallReport;

public interface MobileCallReportRepository extends ElasticsearchRepository<MobileCallReport, String> {

}

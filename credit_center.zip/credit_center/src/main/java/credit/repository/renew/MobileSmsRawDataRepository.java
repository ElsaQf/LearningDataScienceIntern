package credit.repository.renew;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.renew.MobileSmsRawData;

/**
 * 新版本运营商报告
 * @author YCM
 * @date 2019年5月16日 下午2:38:56
 */
public interface MobileSmsRawDataRepository extends ElasticsearchRepository<MobileSmsRawData, String> {

}

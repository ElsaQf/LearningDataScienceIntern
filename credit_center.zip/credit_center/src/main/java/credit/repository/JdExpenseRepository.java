package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.JdExpenseReport;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.repository
 * Created by bob on 18-7-6.
 * Description:   电商月度消费分析
 *******************************************************************************/
public interface JdExpenseRepository extends ElasticsearchRepository<JdExpenseReport, String> {
}

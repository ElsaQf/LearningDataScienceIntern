package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.FaceVerify;

public interface FaceVerifyRepository  extends ElasticsearchRepository<FaceVerify, String> {

}

package credit.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import credit.entity.PersonReport;

public interface PersonReportRepository extends ElasticsearchRepository<PersonReport, String> {

}
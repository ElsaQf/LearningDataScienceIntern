package credit.common;

public class Const {
	
	/**
	 * 授信时长30天
	 */
    public static int credit_valid_day = 30;//授信时长(天)
    
    /**
     * 运营商授权的有效时间为10分钟
     */
    public static int credit_token_exp = 600;
    
    public static final String redis_credit_city_info = "credit_city_info"; 	// 社保公积金授权的
    public static final int sjmh_credit_CityInfo_captcha_exp = 172800; 	// 社保公积金授权的有效时间为48小时
    
    public static final String redis_print_log_interface = "print_log_interface"; //打印日志的接口
    /**
     *第三方通道类型 
     *
     */
    public static class credit_path_list {
		public static final String sjmh_credit = "sjmh";				// 数聚魔盒通道
		public static final String tcxy_credit = "tcxy";				// 天创信用通道
		public static final String jxl_credit = "jxl";				// 聚信立信用通道
		public static final String xinde_credit = "xinde";				// 信德信息通道
		public static final String sxb_credit = "sxb";					// 授信宝通道
		public static final String gxb_credit = "gxb";		           //公信宝
		public static final String faceid_credit = "faceid";			// face++人脸通道
		public static final String webank_credit = "webank";		// 微众人脸通道
	}
    
    /**
     *抓取任务失败类型（包括用户和非用户）
     *
     */
  	public static class fail_type_list {
  		public static final int user_fail =0;//用户操作错误（例如服务密码错误）
  		public static final int route_fail = 1;//第三方信用错误
  	}
    
    /**
     *第三方通道类型 
     *
     */
    public static class credit_redis_pre_list {
		public static final String mobile_token = "mobile_token:";//运营商token前缀
		public static final String mobile_params = "mobile_params_";//运营商参数信息前缀
		public static final String JINGDONG_TOKEN = "jingdong_token_";//运营商token前缀
		public static final String SB_TOKEN = "sb_token:";//社保token前缀
		public static final String GJJ_TOKEN = "gjj_token:";//公积金token前缀
		public static final String CHSI_TOKEN = "chsi_token:";//学信token前缀
		public static final String ALIPAY_TOKEN = "alipay_token_";//支付宝token前缀
		public static final String TAOBAO_TOKEN = "taobao_token_";//淘宝token前缀
		public static final String DISHONEST_TOKEN = "dishonest_token_";//失信token前缀

	}
    
    /**
     * 
     * 第三方通道认证项
     *
     */
    public static class credit_type_list{
		public static final String MOBILE="mobile";		// 移动运营商
		public static final String TAO_BAO="taobao";	// 淘宝
		public static final String JING_DONG="jingdong";// 京东
		public static final String DISCREDIT="discredit";// 法院失信
		public static final String ALIPAY="alipay";// 支付宝
	}
    
    /**
     *
     * 第三方授信任务状态
     *
     */
	public static class credit_auth_task_status {
		public static final int getTask_fail = 0;		// 获取task失败(人脸获取任务失败)
		public static final int getTask_success = 1;	// 获取task成功(人脸获取任务成功)
		public static final int request_fail = 2;		// 请求验证失败（人脸身份证验证失败）
		public static final int request_success = 3;	// 请求验证成功（人脸身份证验证成功）
		public static final int verify_fail = 4;		// 验证失败
		public static final int verify_success = 5;		// 验证成功 ;
		public static final int done_fail = 6;			// 抓取失败 ;（活体验证失败）
		public static final int done_success = 7;		// 抓取成功 ;（活体验证成功）
	
	}
	
	 /**
     * 
     * 第三方通道认证验证方式
     *
     */
    public static class verify_type_list{
		public static final int MESSAGE = 0;//短信
		public static final int AMAGE = 1;	//图片
		public static final int MESSAGE_AND_AMAGE = 2;//短信和图片
	}
    
    /**
     * 授权项
     * @author yuan
     *
     */
    public static class CREDIT_ITEMS {
    	
    	/*****0.必选项全部认证结束（也可能成功，也可能失败，会给微信推送报告是否生成的消息）*/
    	public final static int CREDIT_END = 0 ;
    	/*****1.基础信息*****/
    	public final static int BASE_INFO = 1 ;
    	/*****2.芝麻信用*****/
    	public final static int ZHIMA_CREDIT = 2 ;
    	/*****3.运营商*****/
    	public final static int MOBILE_INRO = 3 ;
    	/*****4.学信数据*****/
    	public final static int XUEXI_INFO = 4 ;
    	/*****5.征信数据*****/
    	public final static int ZHENGXI_INFO = 5 ;
    	/*****6.工作数据*****/
    	public final static int JOB_INFO = 6 ;
    	/*****7.收入数据*****/
    	public final static int EARN_INFO = 7 ;
    	/*****8.车产数据*****/
    	public final static int CAR_INFO = 8 ;
    	/*****9.房产数据*****/
    	public final static int HOUSE_INFO = 9 ;
    	/*****10.淘宝数据*****/
    	public final static int TAOBAO_INFO = 10 ;
    	/*****11.京东数据*****/
    	public final static int JINGDONG_INFO = 11 ;
    	/*****12.社保数据*****/
    	public final static int SHEBAO_INFO = 12;
    	/*****13.公积金数据*******/
    	public final static int GJJ_INFO = 13 ;
    	/*****14.通话记录分析结果****/
    	public final static int MOBILE_ANALYSIS_INFO = 14 ;
    	/*****15.获取定位信息*****/
    	public final static int LOCATION_INFO = 15 ;
    	/*****16.人脸信息*****/
    	public final static int FACE_INFO = 16 ;
    	/*****17.多头借贷*****/
    	public final static int MULTIPOINT = 17 ;
    	/*****18.支付宝*****/
    	public final static int ALIPAY_INFO = 18 ;
		/*****19.二要素认证*****/
		public final static int TWO_ELEMENT_INFO = 19;
		/*****20.高法失信认证*****/
    	public final static int DISHONEST_INFO = 20 ;
    	/*****21.阿里电商（支付宝和淘宝--天创认证支付宝成功，淘宝也会成功）*****/
    	public final static int ALIDATA_INFO = 21;
    	/*****22.四要素认证*****/
    	public final static int FOUR_ELEMENT_INFO = 22;
    	/*****23.借贷宝照片*****/
    	public final static int JDB_IMAGE_INFO = 23;
    	/*****24.身份证照片*****/
    	public final static int IDCARD_IMAGE_INFO = 24;
    	/*****25.紧急联系人*****/
    	public final static int URGENT_INFO = 25;
    	/*****26.网贷黑名单*****/
    	public final static int NETBLACK_INFO = 26;
    	/*****27.米房*****/
    	public final static int MF_INFO = 27;
    	/*****28无忧借条*****/
    	public final static int WYJT_INFO = 28;
    	/*****29百融黑名单*****/
    	public final static int BR_NETBLACK_INFO = 29;
    }
     
    /**
     * 各认证项的认证状态
     * @author yuan
     *
     */
    public static class CREDIT_STATUS {
    	
    	/*****0.信用报告中不包含此认证项(今借到：未认证)*/
    	public final static int NO_CREDIT = 0 ;
    	/*****1.待完善*****/
    	public final static int TO_FINISH = 1 ;
    	/*****2.认证中*****/
    	public final static int IN_CREDITING = 2 ;
    	/*****3.认证成功*****/
    	public final static int IS_SUCCESS = 3 ;
    	/*****4.认证失败*****/
    	public final static int IS_FAIL = 4 ;
    	/*****5.已过期*****/
    	public final static int IN_EXPIRE = 5 ;
    	/*****6.已完成（用于高法认证成功后的临时状态，当运营商成功后，把高法状态改为3）*****/
    	public final static int IS_DONE = 6 ;
    }
    
    
	//人脸识别通道标识（0 小视 1 face++ 2 微众）
	public static class N_face_verify_type {
		public static final int n_xiaoshi_0 =0;//0.小视
		public static final int n_faceId_1 = 1;//1.face++
		public static final int n_weizhong_2 = 2;//2.微众
	}
	
	//人脸入口来源（今借到有两个人脸入口（1：认证页面  2：极速借条实名页面））
	public static class N_face_source_type {
		public static final int n_credit_1 = 1;//1：认证页面
		public static final int n_realName_2 = 2;//2：极速借条实名页面
	}
	
	//人脸
	public static final String redis_face_verify = "jjd_redis_face_verify";// faceId验证在5分钟内重复发生次数
	public static final String redis_face_verify_today = "jjd_redis_face_verify_today";// 人脸验证在当天内重复发生次数
	public static final String redis_face_verify_faceId_today = "redis_face_verify_faceId_today";// face++验证在当天内重复发生次数
	public static final String redis_face_verify_webank_today = "redis_face_verify_webank_today";// 微众验证在当天内重复发生次数
	public static final String redis_face_verify_switch = "redis_face_verify_switch";//人脸识别接口切换数值

	/**
	 * 业务系统认证接口分类
	 * @author YCM
	 * @date 2018年7月10日 下午9:00:27
	 */
    public static class Content_type{
		public static final String CAR="car";		// 车产
		public static final String INCOME="income";	// 收入
		public static final String JOB="job";	// 工作
		public static final String HOUSE="house";	// 房产
		public static final String LOCATION="location";	// 定位
		public static final String JBXX="baseinfo";	//基本信息
		public static final String IDCARD="idcard";	//身份证信息 风控
		public static final String ALIPAY="alipay";	//支付宝 借贷宝 信息 风控
		public static final String URGENT="urgent";	//紧急联系人信息 风控
		public static final String D1FK_URGENT="d1fk_urgent";//紧急联系人信息(第一风控)
		public static final String JDB="jdb";	//借贷宝信息 风控
		public static final String TAOBAO="taobao";	//淘宝
		public static final String ALIDATA="alidata";//支付宝/淘宝
		
		public static final String JD="jd";		// 京东
		public static final String SB="sb";	// 社保
		public static final String GJJ="gjj";	// 公积金
		public static final String YYS="yys";	// 运营商
		public static final String XUEXIN="xuexin"; // 学信
		public static final String MULTIPOINT="multipoint"; // 学信专科
		public static final String DISHONEST="dishonest"; // 高法失信
		public static final String MIFANG="mifang"; //米房
		public static final String ZZC_BLACKLIST="blacklist"; //（中智诚）黑名单
		public static final String BR_BLACKLIST="br_blacklist"; //（百融）黑名单
	}

    /**
     *ES查询返回数据条数（默认10条，需要特别设置）
     *
     */
    public static class query_count {
		public static final int min = 1;
		public static final int max = 10000;//索引设置最大size
	}

	// face++ 调用统计 redis key
	public static final String FACE_FEE = "face_invoke_count";
	
	public static final int XCC_ALL_CONTACT_TEN = 10;	 //仅展示联系人排行前十
	
	/**
	 * 应用类型
	 * @author YCM
	 * @date 2019年2月22日 下午4:47:19
	 */
	public static class app_type {
		public static final int app = 1;
		public static final int wechat = 2;
		public static final int pc = 3;
	}
	
	//百融贷前风险策略编号
	public static class br_strategy_id {
		public static final String ApplyLoan_d = "DTA0000001";//借贷意向验证-当日版
		public static final String SpecialList_c = "DTA0000002";//特殊名单验证
		public static final String ApplyLoanStr = "DTA0000003";//借贷意向验证
		public static final String ApplyLoanMon = "DTA0000004";//借贷意向验证-月度版
	}
	
	 /**
     * MQ操作类型的key名称
     * @author YCM
     * @date 2019年1月15日 下午2:49:16
     */
    public static class MQ {
    	public static final String MQ_HANDLER_TYPE_KEY = "mqHandleTypeKey";
    }
}
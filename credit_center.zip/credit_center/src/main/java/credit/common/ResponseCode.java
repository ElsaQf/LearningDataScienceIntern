package credit.common;

/**
 * Title: ResponseCode.java
 * Description
 * 
 * @date 2015年5月26日
 * @version 1.0
 */
public class ResponseCode {
	public static final int GXB_RETURN_SUCCESS = 1;				//通知公信宝成功
	public static final int GXB_RETURN_FAIL = 2;				//通知公信宝 失败
	public static final String GXB_NOTIFY_SUCCESS = "1";		//公信宝通知成功
	public static final String GXB_NOTIFY_FAIL = "0";			//通知公信宝通知失败
	public static final int SUCCESS = 200;				// 成功
	public static final int FAIL = 201;					// 失败
	public static final int NO_MATCH = 202;				// 二要素不匹配
	public static final int NO_REGISTER = 401;			// 未在信用中心注册
	
	/*运营商 25开头*/
	public static final int CONTINUE_QUERY = 2501;		// 继续查询
	public static final int PATH_UNSUPPORTED= 2502;		// 通道不支持
	public static final int INPUT_CAPTCHA = 2503;	   //等待输入短信验证码
	public static final int INPUT_IMAGE_CAPTCHA = 2504;//等待输入图片验证码
	public static final int INPUT_CAPTCHA_AND_IAMGE = 2505;//等待输入短信验证码和图片验证码
	public static final int INPUT_QUERY_PAD = 2506;//等待输入查询密码（只有北京移动偶发）
	
	/* 电商 26开头 */
	public static final int INPUT_LOGIN_SCAN_QRCODE = 2601;//请登录扫码二维码
	public static final int INPUT_LOGIN_CONFIRM_QRCODE = 2602;//请登录确认二维码
	public static final int INPUT_BILL_SCAN_QRCODE = 2603;//请账单扫码二维码
	public static final int INPUT_BILL_CONFIRM_QRCODE = 2704;//请账单确认二维码
	
	/* 无忧借条返回码 6开头*/
	public static final int WYJT_NO_REGISTER= 6001;		// 用户未注册
	public static final int WYJT_LOGIN_ERROR= 6002;		// 登录失败
}

/**
 * @(#)Resp.java.
 */
package credit.common;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author jayson
 */
@Data
public class JsonResult<T> {
	public static final int SUCCESS = 200;// 成功
	public static final int FAIL = 201;// 失败
	
 	private int status;

    private String msg;

    private T data;
    
	public JsonResult() {

	}
	
	public JsonResult(Integer status,String message, T t){
		this.status = status;
		this.msg = message;
		this.data = t;
	}
    
	public JsonResult(int status, String message){
		this.status = status;
		this.msg = message;
	}
	
    public static <T> JsonResult<T> ok(T data) {
        JsonResult<T> result = new JsonResult<T>();
        result.setStatus(SUCCESS);
        result.setData(data);
        return result;
    }

    public static <T> JsonResult<T> ok() {
        return ok(null);
    }

    @SuppressWarnings("rawtypes")
	public static JsonResult fail(int status, String msg) {
        if (status==SUCCESS) {
            throw new RuntimeException("ok is not fail");
        }
        JsonResult result = new JsonResult();
        result.setStatus(status);
        result.setMsg(msg);
        return result;
    }

    @SuppressWarnings("rawtypes")
	public static JsonResult badRequest(String msg) {
        return fail(FAIL, msg);
    }

    @JsonIgnore
    public boolean isOk() {
        return SUCCESS==status;
    }

    @JsonGetter
    public long getTimestamp() {
        return System.currentTimeMillis();
    }

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}

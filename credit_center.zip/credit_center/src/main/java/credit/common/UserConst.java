package credit.common;

public class UserConst {
    /**
     * 
     * @author YCM
     * @date 2019年1月24日 下午5:39:23
     */
    public static class MIFANG_STATUS {
    	
    	public final static int ALL_0 = 0;//所有状态
    	public final static int PAID_1 = 1;//已还清
    	public final static int PAYING_2 = 2;//还款中
    	public final static int OVERDUE_3 = 3;//已逾期
    	public final static int DISPUTED_4 = 4;//争议
    	public final static int ILLEGAL_5 = 5;//违规
    }
    
    public static class REDIS_PREFIX { 
        public static final String REDIS_FACE_RANDOM_NUM_TOKEN = "raw_face:random_num_token:";
        public static final String REDIS_FACE_VIDEO_TOKEN = "raw_face:video_token:";
        
        public static int EXPIRE_TEMP_TOKEN = 600;
    }
}
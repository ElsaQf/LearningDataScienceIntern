package credit.service.impl;

import java.util.List;

import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Service;

import credit.entity.UserInfo;
import credit.repository.UserInfoRepository;
import credit.service.IUserInfoService;

@Service
public class UserInfoServiceImpl implements IUserInfoService {

    @Autowired
    UserInfoRepository userInfoRepository;

    @Override
    public UserInfo save(UserInfo userCreditInfo) throws Exception {
        UserInfo userReport = userInfoRepository.save(userCreditInfo);
        return userReport;
    }
    
    @Override
    public UserInfo getUserCreditInfoByRid(String report_id) throws Exception {
        if (userInfoRepository.findById(report_id).isPresent()) {
            return userInfoRepository.findById(report_id).get();
        }
        return null;

    }

    @Override
    public UserInfo getUserCreditInfoByPuid(String puid, String system_type) throws Exception {
        // 创建搜索 DSL 查询
        SearchQuery searchQuery = new NativeSearchQueryBuilder().withQuery(QueryBuilders.boolQuery()
                .must(QueryBuilders.matchQuery("puid", puid))
                .must(QueryBuilders.matchQuery("system_name", system_type))).build();
        Page<UserInfo> searchPageResults = userInfoRepository.search(searchQuery);
        List<UserInfo> baseList = searchPageResults.getContent();
        if (baseList != null && baseList.size() > 0) {
            return baseList.get(0);
        }
        return null;
    }

}

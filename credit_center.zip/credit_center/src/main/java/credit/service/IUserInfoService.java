package credit.service;

import credit.entity.UserInfo;

public interface IUserInfoService {
	
	UserInfo save(UserInfo vo) throws Exception;
	
	UserInfo getUserCreditInfoByRid(String report_id) throws Exception;
	
	UserInfo getUserCreditInfoByPuid(String puid, String system_type) throws Exception;
}

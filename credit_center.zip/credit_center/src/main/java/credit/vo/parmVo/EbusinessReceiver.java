package credit.vo.parmVo;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.elasticsearch.annotations.Document;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo.parmVo
 * Created by bob on 18-7-5.
 * Description:   电商收货人
 *******************************************************************************/
public class EbusinessReceiver implements Serializable {

    private static final long serialVersionUID = 7489079617020029884L;

    public Float amount; // 收获金额
    public Integer count; // 收获次数
    public String name; // 收货人名称
    public List<String> phone_num_list = new ArrayList<>(); // 收货人手机列表


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getPhone_num_list() {
        return phone_num_list;
    }

    public void setPhone_num_list(List<String> phone_num_list) {
        this.phone_num_list = phone_num_list;
    }
}

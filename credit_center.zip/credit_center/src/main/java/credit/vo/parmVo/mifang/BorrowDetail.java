package credit.vo.parmVo.mifang;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@SuppressWarnings("serial")
public class BorrowDetail implements Serializable{
	
	@Field(type = FieldType.Text)
	private String iou_no;  //借条编号
	@Field(type = FieldType.Integer)
	private Integer loanState; //借条状态
	@Field(type = FieldType.Integer)
	private Integer type;  //0,
	@Field(type = FieldType.Integer)
	private Integer borrower_id;  //60666,
	@Field(type = FieldType.Text)
	private String borrower_name;  // 高媛媛,
	@Field(type = FieldType.Integer)
	private Integer lender_id;  //3352259,
	@Field(type = FieldType.Text)
	private String lender_name;  //田亚文,
	@Field(type = FieldType.Integer)
	private Integer money;  //1000,
	@Field(type = FieldType.Date)
	private Date create_time;  //2019-01-17T08;  //56;  //18Z,
	@Field(type = FieldType.Date)
	private Date trade_time;  //2019-01-17T08;  //56;  //48Z,
	@Field(type = FieldType.Date)
	private Date start_time;  //2019-01-06T00;  //00;  //00Z,
	@Field(type = FieldType.Date)
	private Date end_time;  //2019-01-11T00;  //00;  //00Z,
	@Field(type = FieldType.Float)
	private Float interest_rate;  // 0,
	@Field(type = FieldType.Text)
	private String use_target_type;  // 10009,
	@Field(type = FieldType.Text)
	private String use_target_desc;  // ,
	@Field(type = FieldType.Integer)
	private Integer state;  // 1,
	@Field(type = FieldType.Integer)
	private Integer is_report;  // 0,
	@Field(type = FieldType.Integer)
	private Integer days;  // 5,
	@Field(type = FieldType.Float)
	private Float interest;  // 0,
	@Field(type = FieldType.Float)
	private Float overtime_interest;  // 7,
	@Field(type = FieldType.Integer)
	private Integer paid_money;  // 0,
	@Field(type = FieldType.Integer)
	private Integer confirm_money;  // 0,
	@Field(type = FieldType.Boolean)
	private Boolean borrow_is_overdue;  // false,
	@Field(type = FieldType.Boolean)
	private Boolean payenable;  // false
	@Field(type = FieldType.Integer)
	private Integer overtime_day;  //逾期天数
	public String getIou_no() {
		return iou_no;
	}
	public void setIou_no(String iou_no) {
		this.iou_no = iou_no;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getBorrower_id() {
		return borrower_id;
	}
	public void setBorrower_id(Integer borrower_id) {
		this.borrower_id = borrower_id;
	}
	public String getBorrower_name() {
		return borrower_name;
	}
	public void setBorrower_name(String borrower_name) {
		this.borrower_name = borrower_name;
	}
	public Integer getLender_id() {
		return lender_id;
	}
	public void setLender_id(Integer lender_id) {
		this.lender_id = lender_id;
	}
	public String getLender_name() {
		return lender_name;
	}
	public void setLender_name(String lender_name) {
		this.lender_name = lender_name;
	}
	public Integer getMoney() {
		return money;
	}
	public void setMoney(Integer money) {
		this.money = money;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Date getTrade_time() {
		return trade_time;
	}
	public void setTrade_time(Date trade_time) {
		this.trade_time = trade_time;
	}
	public Date getStart_time() {
		return start_time;
	}
	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}
	public Date getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}
	public Float getInterest_rate() {
		return interest_rate;
	}
	public void setInterest_rate(Float interest_rate) {
		this.interest_rate = interest_rate;
	}
	public String getUse_target_type() {
		return use_target_type;
	}
	public void setUse_target_type(String use_target_type) {
		this.use_target_type = use_target_type;
	}
	public String getUse_target_desc() {
		return use_target_desc;
	}
	public void setUse_target_desc(String use_target_desc) {
		this.use_target_desc = use_target_desc;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Integer getIs_report() {
		return is_report;
	}
	public void setIs_report(Integer is_report) {
		this.is_report = is_report;
	}
	public Integer getDays() {
		return days;
	}
	public void setDays(Integer days) {
		this.days = days;
	}
	public Float getInterest() {
		return interest;
	}
	public void setInterest(Float interest) {
		this.interest = interest;
	}
	public Float getOvertime_interest() {
		return overtime_interest;
	}
	public void setOvertime_interest(Float overtime_interest) {
		this.overtime_interest = overtime_interest;
	}
	public Integer getPaid_money() {
		return paid_money;
	}
	public void setPaid_money(Integer paid_money) {
		this.paid_money = paid_money;
	}
	public Integer getConfirm_money() {
		return confirm_money;
	}
	public void setConfirm_money(Integer confirm_money) {
		this.confirm_money = confirm_money;
	}
	public Boolean getBorrow_is_overdue() {
		return borrow_is_overdue;
	}
	public void setBorrow_is_overdue(Boolean borrow_is_overdue) {
		this.borrow_is_overdue = borrow_is_overdue;
	}
	public Boolean getPayenable() {
		return payenable;
	}
	public void setPayenable(Boolean payenable) {
		this.payenable = payenable;
	}
	public Integer getLoanState() {
		return loanState;
	}
	public void setLoanState(Integer loanState) {
		this.loanState = loanState;
	}
	public Integer getOvertime_day() {
		return overtime_day;
	}
	public void setOvertime_day(Integer overtime_day) {
		this.overtime_day = overtime_day;
	}
	
}

package credit.vo.parmVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo.parmVo
 * Created by bob on 18-7-5.
 * Description:  单信息
 *******************************************************************************/

public class EbusinessOrder implements Serializable {
    private static final long serialVersionUID = -8757037192154315222L;
    
    @Field(type = FieldType.Text)
    public String zipcode;// 邮政编码
    
    @Field(type = FieldType.Text)
    public String order_id;// 交易id
    
    @Field(type = FieldType.Float)
    public Float total_price;// 商品总价格
    
    @Field(type = FieldType.Text)
    public String trans_time;// 交易时间
    
    @Field(type = FieldType.Boolean)
    public Boolean is_success;//是否交易成功
    
    @Field(type = FieldType.Text)
    public String order_status;//交易状态
    	
    @Field(type = FieldType.Text)
    public String receiver_cell_phone;// 收货人手机
    
    @Field(type = FieldType.Float)
    public Float delivery_fee;// 收送货费用
    
    @Field(type = FieldType.Text)
    public String update_time;// 数据获取时间
    
    @Field(type = FieldType.Text)
    public String payment_type;// 付款方式
    
    @Field(type = FieldType.Text)
    public String delivery_type;// 送货方式
    
    @Field(type = FieldType.Text)
    public String receiver_name;// 收货人姓名
    
    @Field(type = FieldType.Text)
    public String bill_title;// 发票抬头
    
    @Field(type = FieldType.Text)
    public String receiver_addr;// 收货人地址
    
    @Field(type = FieldType.Object)
    public List<EbusinessProduct> items = new ArrayList<EbusinessProduct>();// 单价商品明细

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public Float getTotal_price() {
        return total_price;
    }

    public void setTotal_price(Float total_price) {
        this.total_price = total_price;
    }

    public String getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(String trans_time) {
        this.trans_time = trans_time;
    }

    public Boolean getIs_success() {
        return is_success;
    }

    public void setIs_success(Boolean is_success) {
        this.is_success = is_success;
    }

    public String getReceiver_cell_phone() {
        return receiver_cell_phone;
    }

    public void setReceiver_cell_phone(String receiver_cell_phone) {
        this.receiver_cell_phone = receiver_cell_phone;
    }

    public Float getDelivery_fee() {
        return delivery_fee;
    }

    public void setDelivery_fee(Float delivery_fee) {
        this.delivery_fee = delivery_fee;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getDelivery_type() {
        return delivery_type;
    }

    public void setDelivery_type(String delivery_type) {
        this.delivery_type = delivery_type;
    }

    public String getReceiver_name() {
        return receiver_name;
    }

    public void setReceiver_name(String receiver_name) {
        this.receiver_name = receiver_name;
    }

    public String getBill_title() {
        return bill_title;
    }

    public void setBill_title(String bill_title) {
        this.bill_title = bill_title;
    }

    public String getReceiver_addr() {
        return receiver_addr;
    }

    public void setReceiver_addr(String receiver_addr) {
        this.receiver_addr = receiver_addr;
    }

    public List<EbusinessProduct> getItems() {
        return items;
    }

    public void setItems(List<EbusinessProduct> items) {
        this.items = items;
    }

	public String getOrder_status() {
		return order_status;
	}

	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
}

package credit.vo.parmVo.mifang;

import java.util.Date;

public class MiFangInfo {
	private String phone; //手机号
	private String nickname; //昵称
	private String id_no; //身份证
	private String real_name; //真实姓名
	private Boolean wechat_binding; //是否绑定微信
	private Boolean bank_card_binded; //是否绑卡
	private String state; //账户状态
	private Date create_time; //创建时间

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Boolean getWechat_binding() {
		return wechat_binding;
	}

	public void setWechat_binding(Boolean wechat_binding) {
		this.wechat_binding = wechat_binding;
	}

	public Boolean getBank_card_binded() {
		return bank_card_binded;
	}

	public void setBank_card_binded(Boolean bank_card_binded) {
		this.bank_card_binded = bank_card_binded;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}

	public String getId_no() {
		return id_no;
	}

	public void setId_no(String id_no) {
		this.id_no = id_no;
	}

	public String getReal_name() {
		return real_name;
	}

	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}

}

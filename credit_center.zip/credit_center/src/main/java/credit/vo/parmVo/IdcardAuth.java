package credit.vo.parmVo;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.vo.parmVo
 * Created by bob on 18-8-21.
 * Description:  
 *******************************************************************************/
@SuppressWarnings("serial")
public class IdcardAuth implements Serializable{

    private String front; // 正面身份证图片
    private String back; // 背面身份证图片
    private String hand; // 手持身份证图片

    public String getFront() {
        return front;
    }

    public void setFront(String front) {
        this.front = front;
    }

    public String getBack() {
        return back;
    }

    public void setBack(String back) {
        this.back = back;
    }

    public String getHand() {
        return hand;
    }

    public void setHand(String hand) {
        this.hand = hand;
    }

    @Override
    public String toString() {
        return "IdcardAuth{" +
                "front='" + front + '\'' +
                ", back='" + back + '\'' +
                ", hand='" + hand + '\'' +
                '}';
    }
}

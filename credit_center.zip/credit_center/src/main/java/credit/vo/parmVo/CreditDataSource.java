package credit.vo.parmVo;

import java.io.Serializable;

/**
 * 认证数据源报告
 * @author YCM
 * @date 2018年7月6日 下午7:19:01
 */
@SuppressWarnings("serial")
public class CreditDataSource implements Serializable{
	private String name; // 数据源名称
	private int binding_time; // 绑定时间
	private int use_time; // 使用时间(月)
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBinding_time() {
		return binding_time;
	}
	public void setBinding_time(int binding_time) {
		this.binding_time = binding_time;
	}
	public int getUse_time() {
		return use_time;
	}
	public void setUse_time(int use_time) {
		this.use_time = use_time;
	}
}

package credit.vo.parmVo.mifang;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@SuppressWarnings("serial")
public class ReportDetail implements Serializable {
	
	@Field(type = FieldType.Integer)
	private Integer loanState;  //借条状态
	@Field(type = FieldType.Integer)
	private Integer loanCount; //借条数量
	@Field(type = FieldType.Integer)
	private Integer personCount;  //人数
	@Field(type = FieldType.Integer)
	private Integer loanAmount;  //借条金额
	public Integer getLoanState() {
		return loanState;
	}
	public void setLoanState(Integer loanState) {
		this.loanState = loanState;
	}
	public Integer getLoanCount() {
		return loanCount;
	}
	public void setLoanCount(Integer loanCount) {
		this.loanCount = loanCount;
	}
	public Integer getPersonCount() {
		return personCount;
	}
	public void setPersonCount(Integer personCount) {
		this.personCount = personCount;
	}
	public Integer getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}
}

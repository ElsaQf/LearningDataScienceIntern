package credit.vo.parmVo;

import java.io.Serializable;
import java.util.List;

import credit.entity.PersonReport;
import credit.entity.UserInfo;
import credit.vo.fieldVo.GjjBaseInfo;
import credit.vo.fieldVo.ShebaoBaseInfo;
import credit.vo.fieldVo.UrgentContactDetail;

/**
 * 【简版】信用报告
 * 
 * @author YCM
 * @date 2018年7月6日 下午7:19:01
 */
@SuppressWarnings("serial")
public class SimpleReport implements Serializable{
	// 报告人的信息统计
	private PersonReport personReport;
	//信用认证信息
	private UserInfo creditBaseInfo; 
	//社保信息
	private ShebaoBaseInfo shebaoInfo;
	//公积金信息
	private GjjBaseInfo gjjInfo;
	//紧急联系人分析
	private List<UrgentContactDetail> urgentContactList;

	public PersonReport getPersonReport() {
		return personReport;
	}

	public void setPersonReport(PersonReport personReport) {
		this.personReport = personReport;
	}

	public UserInfo getCreditBaseInfo() {
		return creditBaseInfo;
	}

	public void setCreditBaseInfo(UserInfo creditBaseInfo) {
		this.creditBaseInfo = creditBaseInfo;
	}

	public List<UrgentContactDetail> getUrgentContactList() {
		return urgentContactList;
	}

	public void setUrgentContactList(List<UrgentContactDetail> urgentContactList) {
		this.urgentContactList = urgentContactList;
	}

	public ShebaoBaseInfo getShebaoInfo() {
		return shebaoInfo;
	}

	public void setShebaoInfo(ShebaoBaseInfo shebaoInfo) {
		this.shebaoInfo = shebaoInfo;
	}

	public GjjBaseInfo getGjjInfo() {
		return gjjInfo;
	}

	public void setGjjInfo(GjjBaseInfo gjjInfo) {
		this.gjjInfo = gjjInfo;
	}
 
}

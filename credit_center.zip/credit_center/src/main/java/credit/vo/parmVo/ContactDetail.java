package credit.vo.parmVo;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo.parmVo
 * Created by bob on 18-7-5.
 * Description:  
 *******************************************************************************/
public class ContactDetail implements Serializable, Comparable<ContactDetail> {

    private static final long serialVersionUID = -7171725379447545932L;

    public String phone_num; // 号码
    public String phone_num_loc; // 号码归属地
    public String contact_name; // 号码标注
    public String needs_type; // 需求类别
    public int call_cnt = 0; // 通话次数
    public float call_len = 0F; // 通话时长
    public int call_out_cnt = 0; // 呼出次数
    public float call_out_len = 0F; // 呼出时间
    public int call_in_cnt = 0; // 呼入次数
    public float call_in_len = 0F; // 呼入时间
    public int sms_cnt = 0; // 短信次数


    @Override
    public int compareTo(ContactDetail o) {
        if(this.call_cnt>o.call_cnt){
            return -1;
        }else{
            return 1;
        }
    }
}

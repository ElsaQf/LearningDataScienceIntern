package credit.vo.parmVo.mifang;

import java.util.List;

public class MiFangDataVo {
	
	private String userName;//姓名
	private String phone; //手机号
	private String idNo; //身份证
	private Integer totalToPayAmount;// 待还金额
	private Integer totalPaidAmount; // 已还金额
	private List<ReportDetail> reportDetails;//借入报告
	private List<BorrowDetail> borrow_details;//借入详情 
	
	public Integer getTotalToPayAmount() {
		return totalToPayAmount;
	}
	public void setTotalToPayAmount(Integer totalToPayAmount) {
		this.totalToPayAmount = totalToPayAmount;
	}
	public Integer getTotalPaidAmount() {
		return totalPaidAmount;
	}
	public void setTotalPaidAmount(Integer totalPaidAmount) {
		this.totalPaidAmount = totalPaidAmount;
	}
	public List<ReportDetail> getReportDetails() {
		return reportDetails;
	}
	public void setReportDetails(List<ReportDetail> reportDetails) {
		this.reportDetails = reportDetails;
	}
	public List<BorrowDetail> getBorrow_details() {
		return borrow_details;
	}
	public void setBorrow_details(List<BorrowDetail> borrow_details) {
		this.borrow_details = borrow_details;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
}

package credit.vo.parmVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

public class DishonestData {
	@Field(type = FieldType.Text)
	private String no;  //案号
	@Field(type = FieldType.Text)
	private String releaseTime; //发布时间
	@Field(type = FieldType.Text)
	private String executiveArm; //法院
	@Field(type = FieldType.Text)
	private String sex;  
	@Field(type = FieldType.Text)
	private String executed; //是否执行
	@Field(type = FieldType.Text)
	private String filingTime; 
	@Field(type = FieldType.Text)
	private String caseNo;
	@Field(type = FieldType.Text)
	private String specificSituation;
	@Field(type = FieldType.Text)
	private String identityNo;
	@Field(type = FieldType.Text)
	private String unExecuted;
	@Field(type = FieldType.Text)
	private String province;
	@Field(type = FieldType.Text)
	private String executiveBaiscNo;
	@Field(type = FieldType.Text)
	private String name;
	@Field(type = FieldType.Text)
	private String executiveCase;
	@Field(type = FieldType.Text)
	private String legalObligation;
	@Field(type = FieldType.Text)
	private String corpLegalPerson;
	@Field(type = FieldType.Text)
	private String executiveCourt;
	@Field(type = FieldType.Text)
	private String age;

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getReleaseTime() {
		return releaseTime;
	}

	public void setReleaseTime(String releaseTime) {
		this.releaseTime = releaseTime;
	}

	public String getExecutiveArm() {
		return executiveArm;
	}

	public void setExecutiveArm(String executiveArm) {
		this.executiveArm = executiveArm;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getExecuted() {
		return executed;
	}

	public void setExecuted(String executed) {
		this.executed = executed;
	}

	public String getFilingTime() {
		return filingTime;
	}

	public void setFilingTime(String filingTime) {
		this.filingTime = filingTime;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getSpecificSituation() {
		return specificSituation;
	}

	public void setSpecificSituation(String specificSituation) {
		this.specificSituation = specificSituation;
	}

	public String getIdentityNo() {
		return identityNo;
	}

	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo;
	}

	public String getUnExecuted() {
		return unExecuted;
	}

	public void setUnExecuted(String unExecuted) {
		this.unExecuted = unExecuted;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getExecutiveBaiscNo() {
		return executiveBaiscNo;
	}

	public void setExecutiveBaiscNo(String executiveBaiscNo) {
		this.executiveBaiscNo = executiveBaiscNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExecutiveCase() {
		return executiveCase;
	}

	public void setExecutiveCase(String executiveCase) {
		this.executiveCase = executiveCase;
	}

	public String getLegalObligation() {
		return legalObligation;
	}

	public void setLegalObligation(String legalObligation) {
		this.legalObligation = legalObligation;
	}

	public String getCorpLegalPerson() {
		return corpLegalPerson;
	}

	public void setCorpLegalPerson(String corpLegalPerson) {
		this.corpLegalPerson = corpLegalPerson;
	}

	public String getExecutiveCourt() {
		return executiveCourt;
	}

	public void setExecutiveCourt(String executiveCourt) {
		this.executiveCourt = executiveCourt;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

}

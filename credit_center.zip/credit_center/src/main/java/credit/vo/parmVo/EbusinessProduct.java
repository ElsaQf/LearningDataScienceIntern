package credit.vo.parmVo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo.parmVo
 * Created by bob on 18-7-5.
 * Description:  电商商品信息
 *******************************************************************************/

public class EbusinessProduct implements Serializable{

    private static final long serialVersionUID = -5042112923978621477L;
    
    @Field(type = FieldType.Integer)
    private int product_amount;// 数量
    
    @Field(type = FieldType.Float)
    private Float product_price;// 单价
    
    @Field(type = FieldType.Text)
    private String product_name;// 产品名称
    
    @Field(type = FieldType.Text)
    private String trans_time;// 交易时间

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getProduct_amount() {
        return product_amount;
    }

    public void setProduct_amount(int product_amount) {
        this.product_amount = product_amount;
    }

    public Float getProduct_price() {
        return product_price;
    }

    public void setProduct_price(Float product_price) {
        this.product_price = product_price;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(String trans_time) {
        this.trans_time = trans_time;
    }
}

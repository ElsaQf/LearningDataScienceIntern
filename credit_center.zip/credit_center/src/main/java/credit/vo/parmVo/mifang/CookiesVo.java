package credit.vo.parmVo.mifang;

public class CookiesVo {
	private String respData; // 返回数据
	private String cookies;// 返回cookies

	public String getRespData() {
		return respData;
	}

	public void setRespData(String respData) {
		this.respData = respData;
	}

	public String getCookies() {
		return cookies;
	}

	public void setCookies(String cookies) {
		this.cookies = cookies;
	}
}

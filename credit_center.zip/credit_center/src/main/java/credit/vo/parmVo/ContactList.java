package credit.vo.parmVo;

import java.util.List;

public class ContactList {
	private List<String> emergencyContact; //紧急联系人
	private List<String> historyEmergencyContact; //紧急联系人历史
	private List<String> contact; //通话记录
	public List<String> getEmergencyContact() {
		return emergencyContact;
	}
	public void setEmergencyContact(List<String> emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public List<String> getHistoryEmergencyContact() {
		return historyEmergencyContact;
	}
	public void setHistoryEmergencyContact(List<String> historyEmergencyContact) {
		this.historyEmergencyContact = historyEmergencyContact;
	}
	public List<String> getContact() {
		return contact;
	}
	public void setContact(List<String> contact) {
		this.contact = contact;
	}
	
	
}

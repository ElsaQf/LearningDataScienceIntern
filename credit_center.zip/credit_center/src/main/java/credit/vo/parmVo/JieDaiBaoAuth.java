package credit.vo.parmVo;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.vo.parmVo
 * Created by bob on 18-8-21.
 * Description:  
 *******************************************************************************/
@SuppressWarnings("serial")
public class JieDaiBaoAuth implements Serializable {

    private String home; // 个人主页
    private String iouRecord; // 收还款
    private String tradeRecord; // 交易记录

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }

    public String getIouRecord() {
        return iouRecord;
    }

    public void setIouRecord(String iouRecord) {
        this.iouRecord = iouRecord;
    }

    public String getTradeRecord() {
        return tradeRecord;
    }

    public void setTradeRecord(String tradeRecord) {
        this.tradeRecord = tradeRecord;
    }

    @Override
    public String toString() {
        return "JieDaiBaoAuth{" +
                "home='" + home + '\'' +
                ", iouRecord='" + iouRecord + '\'' +
                ", tradeRecord='" + tradeRecord + '\'' +
                '}';
    }
}

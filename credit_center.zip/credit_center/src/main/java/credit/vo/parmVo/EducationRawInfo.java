package credit.vo.parmVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 学籍原始信息
 * @author YCM
 * @date 2019年6月19日 下午5:34:12
 */
@SuppressWarnings("serial")
public class EducationRawInfo implements Serializable {
	
	@Field(type = FieldType.Text)
    private String birthday;

	@Field(type = FieldType.Text)
    private String entrance_date;

	@Field(type = FieldType.Text)
    private String gender;

	@Field(type = FieldType.Text)
    private String edu_conclusion;

	@Field(type = FieldType.Text)
    private String head_img;

	@Field(type = FieldType.Text)
    private String detail_img;

	@Field(type = FieldType.Text)
    private String realname;

	@Field(type = FieldType.Text)
    private String certificate_id;

	@Field(type = FieldType.Text)
    private String major;

	@Field(type = FieldType.Text)
    private String school;

	@Field(type = FieldType.Text)
    private String edu_level;

	@Field(type = FieldType.Text)
    private String edu_form;

	@Field(type = FieldType.Text)
    private String graduate_date;

	@Field(type = FieldType.Text)
    private String edu_type;

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getEntrance_date() {
        return entrance_date;
    }

    public void setEntrance_date(String entrance_date) {
        this.entrance_date = entrance_date;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEdu_conclusion() {
        return edu_conclusion;
    }

    public void setEdu_conclusion(String edu_conclusion) {
        this.edu_conclusion = edu_conclusion;
    }

    public String getHead_img() {
        return head_img;
    }

    public void setHead_img(String head_img) {
        this.head_img = head_img;
    }

    public String getDetail_img() {
        return detail_img;
    }

    public void setDetail_img(String detail_img) {
        this.detail_img = detail_img;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getCertificate_id() {
        return certificate_id;
    }

    public void setCertificate_id(String certificate_id) {
        this.certificate_id = certificate_id;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getEdu_level() {
        return edu_level;
    }

    public void setEdu_level(String edu_level) {
        this.edu_level = edu_level;
    }

    public String getEdu_form() {
        return edu_form;
    }

    public void setEdu_form(String edu_form) {
        this.edu_form = edu_form;
    }

    public String getGraduate_date() {
        return graduate_date;
    }

    public void setGraduate_date(String graduate_date) {
        this.graduate_date = graduate_date;
    }

    public String getEdu_type() {
        return edu_type;
    }

    public void setEdu_type(String edu_type) {
        this.edu_type = edu_type;
    }
}

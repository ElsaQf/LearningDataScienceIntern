package credit.vo.parmVo.mifang;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@SuppressWarnings("serial")
public class BorrowReport implements Serializable {
	
	@Field(type = FieldType.Integer)
	private Integer totalPaidAmount;  //已还金额
	@Field(type = FieldType.Integer)
	private Integer totalToPayAmount; //待还金额
	@Field(type = FieldType.Object)
	private List<ReportDetail> reportDetails;//借入详情 
	
	public Integer getTotalPaidAmount() {
		return totalPaidAmount;
	}
	public void setTotalPaidAmount(Integer totalPaidAmount) {
		this.totalPaidAmount = totalPaidAmount;
	}
	public Integer getTotalToPayAmount() {
		return totalToPayAmount;
	}
	public void setTotalToPayAmount(Integer totalToPayAmount) {
		this.totalToPayAmount = totalToPayAmount;
	}
	public List<ReportDetail> getReportDetails() {
		return reportDetails;
	}
	public void setReportDetails(List<ReportDetail> reportDetails) {
		this.reportDetails = reportDetails;
	}
}

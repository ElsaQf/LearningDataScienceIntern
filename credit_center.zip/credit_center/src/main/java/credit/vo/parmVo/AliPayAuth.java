package credit.vo.parmVo;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.vo.parmVo
 * Created by bob on 18-8-21.
 * Description:  
 *******************************************************************************/
@SuppressWarnings("serial")
public class AliPayAuth implements Serializable{

    private String zhimaScore; //
    private String negtiveRecord; // 负面记录
    private String taobaoAddress; // 负面记录

    public String getZhimaScore() {
        return zhimaScore;
    }

    public void setZhimaScore(String zhimaScore) {
        this.zhimaScore = zhimaScore;
    }

    public String getNegtiveRecord() {
        return negtiveRecord;
    }

    public void setNegtiveRecord(String negtiveRecord) {
        this.negtiveRecord = negtiveRecord;
    }

    public String getTaobaoAddress() {
        return taobaoAddress;
    }

    public void setTaobaoAddress(String taobaoAddress) {
        this.taobaoAddress = taobaoAddress;
    }

    @Override
    public String toString() {
        return "AliPayAuth{" +
                "zhimaScore='" + zhimaScore + '\'' +
                ", negtiveRecord='" + negtiveRecord + '\'' +
                ", taobaoAddress='" + taobaoAddress + '\'' +
                '}';
    }
}

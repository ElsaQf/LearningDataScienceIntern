package credit.vo.parmVo.mifang;

import java.util.List;

public class BorrowData {
	private Integer offset;  //6987200,
	private String count;  //201901170856186987200,
	private Integer total_count;  //0,
	private List<BorrowDetail> data_list;
	public Integer getOffset() {
		return offset;
	}
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public Integer getTotal_count() {
		return total_count;
	}
	public void setTotal_count(Integer total_count) {
		this.total_count = total_count;
	}
	public List<BorrowDetail> getData_list() {
		return data_list;
	}
	public void setData_list(List<BorrowDetail> data_list) {
		this.data_list = data_list;
	}
	
	
}

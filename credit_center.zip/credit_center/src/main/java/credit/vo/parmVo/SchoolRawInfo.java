package credit.vo.parmVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 学校原始信息
 * @author YCM
 * @date 2019年6月19日 下午5:35:16
 */
@SuppressWarnings("serial")
public class SchoolRawInfo implements Serializable {
	@Field(type = FieldType.Text)
    private String birthday;

	@Field(type = FieldType.Text)
    private String college;

	@Field(type = FieldType.Text)
    private String entrance_date;

	@Field(type = FieldType.Text)
    private String gender;

	@Field(type = FieldType.Text)
    private String nation;

	@Field(type = FieldType.Text)
	private String enter_img;// 入学照片
	
	@Field(type = FieldType.Text)
    private String head_img;//毕业照片

	@Field(type = FieldType.Text)
    private String detail_img;

	@Field(type = FieldType.Text)
    private String student_id;

	@Field(type = FieldType.Text)
    private String card_id;

	@Field(type = FieldType.Text)
    private String realname;

	@Field(type = FieldType.Text)
    private String edu_system;

	@Field(type = FieldType.Text)
    private String classname;

	@Field(type = FieldType.Text)
    private String major;

	@Field(type = FieldType.Text)
    private String school;

	@Field(type = FieldType.Text)
    private String edu_level;

	@Field(type = FieldType.Text)
    private String edu_form;

	@Field(type = FieldType.Text)
    private String graduate_date;

	@Field(type = FieldType.Text)
    private String department;

	@Field(type = FieldType.Text)
    private String edu_type;

	@Field(type = FieldType.Text)
    private String status;

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public String getEntrance_date() {
        return entrance_date;
    }

    public void setEntrance_date(String entrance_date) {
        this.entrance_date = entrance_date;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getHead_img() {
        return head_img;
    }

    public void setHead_img(String head_img) {
        this.head_img = head_img;
    }

    public String getDetail_img() {
        return detail_img;
    }

    public void setDetail_img(String detail_img) {
        this.detail_img = detail_img;
    }

    public String getStudent_id() {
        return student_id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getEdu_system() {
        return edu_system;
    }

    public void setEdu_system(String edu_system) {
        this.edu_system = edu_system;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getEdu_level() {
        return edu_level;
    }

    public void setEdu_level(String edu_level) {
        this.edu_level = edu_level;
    }

    public String getEdu_form() {
        return edu_form;
    }

    public void setEdu_form(String edu_form) {
        this.edu_form = edu_form;
    }

    public String getGraduate_date() {
        return graduate_date;
    }

    public void setGraduate_date(String graduate_date) {
        this.graduate_date = graduate_date;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEdu_type() {
        return edu_type;
    }

    public void setEdu_type(String edu_type) {
        this.edu_type = edu_type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	public String getEnter_img() {
		return enter_img;
	}

	public void setEnter_img(String enter_img) {
		this.enter_img = enter_img;
	}
}

package credit.vo.parmVo.mifang;

public class LoanSumData {
	private Integer loanState;  //6987200,
	private Integer loanCount;  //6987200,
	private Integer personCount;  //201901170856186987200,
	private Integer loanAmount;  //0,
	public Integer getLoanState() {
		return loanState;
	}
	public void setLoanState(Integer loanState) {
		this.loanState = loanState;
	}
	public Integer getLoanCount() {
		return loanCount;
	}
	public void setLoanCount(Integer loanCount) {
		this.loanCount = loanCount;
	}
	public Integer getPersonCount() {
		return personCount;
	}
	public void setPersonCount(Integer personCount) {
		this.personCount = personCount;
	}
	public Integer getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}
	
}

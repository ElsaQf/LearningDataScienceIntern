package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝基础信息
 * @author zhanglle
 *
 */
public class HuabeiInfo implements Serializable{
	
	@Field(type = FieldType.Text) 
	private String amount;//花呗额度
	
	@Field(type = FieldType.Text) 
	private String balance;//花呗余额
	
	@Field(type = FieldType.Text) 
	private String originalAmount;//花呗原始信用额度
	
	@Field(type = FieldType.Text) 
	private String overdueDays;//花呗的逾期天数
	
	@Field(type = FieldType.Text) 
	private String penaltyAmount;//花呗的罚息
	
	@Field(type = FieldType.Text) 
	private String payDay;//还款日
	
	@Field(type = FieldType.Text) 
	private String overdueBillCnt;//逾期账单数
	
	@Field(type = FieldType.Text) 
	private String currentMonthPayment;//当月还款额
	
	@Field(type = FieldType.Text) 
	private String nextMonthPayment;//下月还款额
	
	@Field(type = FieldType.Text) 
	private String freeze;//花呗是否被冻结

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getOriginalAmount() {
		return originalAmount;
	}

	public void setOriginalAmount(String originalAmount) {
		this.originalAmount = originalAmount;
	}

	public String getOverdueDays() {
		return overdueDays;
	}

	public void setOverdueDays(String overdueDays) {
		this.overdueDays = overdueDays;
	}

	public String getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(String penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public String getPayDay() {
		return payDay;
	}

	public void setPayDay(String payDay) {
		this.payDay = payDay;
	}

	public String getOverdueBillCnt() {
		return overdueBillCnt;
	}

	public void setOverdueBillCnt(String overdueBillCnt) {
		this.overdueBillCnt = overdueBillCnt;
	}

	public String getCurrentMonthPayment() {
		return currentMonthPayment;
	}

	public void setCurrentMonthPayment(String currentMonthPayment) {
		this.currentMonthPayment = currentMonthPayment;
	}

	public String getNextMonthPayment() {
		return nextMonthPayment;
	}

	public void setNextMonthPayment(String nextMonthPayment) {
		this.nextMonthPayment = nextMonthPayment;
	}

	public String getFreeze() {
		return freeze;
	}

	public void setFreeze(String freeze) {
		this.freeze = freeze;
	}
}

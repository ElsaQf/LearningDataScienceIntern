package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
/**
 * 收入
 * @author zhanglle
 *
 */
public class EarnInfo  implements Serializable{
	
	@Field(type = FieldType.Text)
	private String earn_month; // 月收入

	@Field(type = FieldType.Text)
	private List<String> earn_image_list; // 月收入证明

	@Field(type = FieldType.Integer)
	public Integer update_time; // 收入数据更新时间

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public String getEarn_month() {
		return earn_month;
	}

	public void setEarn_month(String earn_month) {
		this.earn_month = earn_month;
	}

	public List<String> getEarn_image_list() {
		return earn_image_list;
	}

	public void setEarn_image_list(List<String> earn_image_list) {
		this.earn_image_list = earn_image_list;
	}

	

}

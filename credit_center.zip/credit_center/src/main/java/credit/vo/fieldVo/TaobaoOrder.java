package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝订单信息
 * @author YCM
 * @date 2018年11月13日 下午4:59:08
 */

public class TaobaoOrder implements Serializable {

	@Field(type = FieldType.Text) 
	private String orderId;//订单ID
	
	@Field(type = FieldType.Text) 
	private String totalPrice;//商品总价格
	
	@Field(type = FieldType.Text) 
	private String receiverAddr;//收货地址
	
	@Field(type = FieldType.Text) 
	private String receiverName;//收货人姓名
	
	@Field(type = FieldType.Text) 
	private String billType;//账单类型
	
	@Field(type = FieldType.Text) 
	private String zipcode;//邮编
	
	@Field(type = FieldType.Text) 
	private String receiverTitle;//收货人单位
	
	@Field(type = FieldType.Text) 
	private String deliveryFee;//收送货费用
	
	@Field(type = FieldType.Text) 
	private String receiverCellPhone;//收货人手机
	
	@Field(type = FieldType.Text) 
	private String paymentType;//付款方式
	
	@Field(type = FieldType.Text) 
	private String isSuccess;//是否交易成功
	
	@Field(type = FieldType.Text) 
	private String statusText;//订单当前状态文本
	
	@Field(type = FieldType.Text) 
	private String deliveryType;//送货方式
	
	@Field(type = FieldType.Text) 
	private String receiverPhone;//收货人电话
	
	@Field(type = FieldType.Text) 
	private String billTitle;//发票抬头--停用
	
	@Field(type = FieldType.Text) 
	private String receiptTitle;//发票抬头
	
	@Field(type = FieldType.Text) 
	private String receiptType;//发票类型
	
	@Field(type = FieldType.Text) 
	private String receiptContent;//发票内容
	
	@Field(type = FieldType.Text) 
	private String transTime;//交易时间
	 
	@Field(type = FieldType.Text) 
	private String orderShop;//商铺名称
	
	@Field(type = FieldType.Object) 
	private TaobaoOrderShopInfo shopInfo;//商家信息
	
	@Field(type = FieldType.Object) 
	private List<TaobaoOrderItem> itemList;//商品列表

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getReceiverAddr() {
		return receiverAddr;
	}

	public void setReceiverAddr(String receiverAddr) {
		this.receiverAddr = receiverAddr;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getReceiverTitle() {
		return receiverTitle;
	}

	public void setReceiverTitle(String receiverTitle) {
		this.receiverTitle = receiverTitle;
	}

	public String getDeliveryFee() {
		return deliveryFee;
	}

	public void setDeliveryFee(String deliveryFee) {
		this.deliveryFee = deliveryFee;
	}

	public String getReceiverCellPhone() {
		return receiverCellPhone;
	}

	public void setReceiverCellPhone(String receiverCellPhone) {
		this.receiverCellPhone = receiverCellPhone;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(String isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}

	public String getBillTitle() {
		return billTitle;
	}

	public void setBillTitle(String billTitle) {
		this.billTitle = billTitle;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public TaobaoOrderShopInfo getShopInfo() {
		return shopInfo;
	}

	public void setShopInfo(TaobaoOrderShopInfo shopInfo) {
		this.shopInfo = shopInfo;
	}

	public List<TaobaoOrderItem> getItemList() {
		return itemList;
	}

	public void setItemList(List<TaobaoOrderItem> itemList) {
		this.itemList = itemList;
	}

	public String getOrderShop() {
		return orderShop;
	}

	public void setOrderShop(String orderShop) {
		this.orderShop = orderShop;
	}

	public String getReceiptTitle() {
		return receiptTitle;
	}

	public void setReceiptTitle(String receiptTitle) {
		this.receiptTitle = receiptTitle;
	}

	public String getReceiptType() {
		return receiptType;
	}

	public void setReceiptType(String receiptType) {
		this.receiptType = receiptType;
	}

	public String getReceiptContent() {
		return receiptContent;
	}

	public void setReceiptContent(String receiptContent) {
		this.receiptContent = receiptContent;
	}
	
}

package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * (报告)通话记录报告
 * Title: CallRecordReport.java
 * @version 1.0
 */
@SuppressWarnings("serial")
public class MobileCallDetail implements Serializable, Comparable<MobileCallDetail>{
	private String phone_num; // 号码
	@Field(type = FieldType.Text, index = false)
	private String contact_area; // 号码归属地
	@Field(type = FieldType.Text, index = false)
	private String contact_name; // 号码标注
	private int call_cnt = 0; // 6个月通话次数
	private float call_len = 0F; // 6个月通话时长
	private int call_out_cnt = 0; // 6个月呼出次数
	private float call_out_len = 0F; // 6个月呼出时间
	private int call_in_cnt = 0; // 6个月呼入次数
	private float call_in_len = 0F; // 6个月呼入时间
	private int sms_cnt = 0; // 6个月短信次数
	@Field(type = FieldType.Text, index = false)
	private String first_time_call_6month; //近6月第一次通话时间
	@Field(type = FieldType.Text, index = false)
	private String last_time_call_6month; //近6月最后一次通话时间
	private int call_cnt_3month = 0; // 3个月通话次数
	private float call_len_3month = 0F; // 3个月通话时长
	private int call_out_cnt_3month = 0; // 3个月呼出次数
	private float call_out_len_3month = 0F; //3个月呼出时间
	private int call_in_cnt_3month = 0; //3个月呼入次数
	private float call_in_len_3month = 0F; //3个月呼入时间
	private int sms_cnt_3month = 0; //3个月短信次数
 
	@Override
	public int compareTo(MobileCallDetail o) {
		if(this.call_cnt > o.call_cnt){
			return -1;
		}else{
			return 1;
		}
	}  

	public String getPhone_num() {
		return phone_num;
	}

	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}

	public int getCall_cnt() {
		return call_cnt;
	}

	public void setCall_cnt(int call_cnt) {
		this.call_cnt = call_cnt;
	}

	public float getCall_len() {
		return call_len;
	}

	public void setCall_len(float call_len) {
		this.call_len = call_len;
	}

	public int getCall_out_cnt() {
		return call_out_cnt;
	}

	public void setCall_out_cnt(int call_out_cnt) {
		this.call_out_cnt = call_out_cnt;
	}

	public float getCall_out_len() {
		return call_out_len;
	}

	public void setCall_out_len(float call_out_len) {
		this.call_out_len = call_out_len;
	}

	public int getCall_in_cnt() {
		return call_in_cnt;
	}

	public void setCall_in_cnt(int call_in_cnt) {
		this.call_in_cnt = call_in_cnt;
	}

	public float getCall_in_len() {
		return call_in_len;
	}

	public void setCall_in_len(float call_in_len) {
		this.call_in_len = call_in_len;
	}

	public int getSms_cnt() {
		return sms_cnt;
	}

	public void setSms_cnt(int sms_cnt) {
		this.sms_cnt = sms_cnt;
	}

	public int getCall_cnt_3month() {
		return call_cnt_3month;
	}

	public void setCall_cnt_3month(int call_cnt_3month) {
		this.call_cnt_3month = call_cnt_3month;
	}

	public float getCall_len_3month() {
		return call_len_3month;
	}

	public void setCall_len_3month(float call_len_3month) {
		this.call_len_3month = call_len_3month;
	}

	public int getCall_out_cnt_3month() {
		return call_out_cnt_3month;
	}

	public void setCall_out_cnt_3month(int call_out_cnt_3month) {
		this.call_out_cnt_3month = call_out_cnt_3month;
	}

	public float getCall_out_len_3month() {
		return call_out_len_3month;
	}

	public void setCall_out_len_3month(float call_out_len_3month) {
		this.call_out_len_3month = call_out_len_3month;
	}

	public int getCall_in_cnt_3month() {
		return call_in_cnt_3month;
	}

	public void setCall_in_cnt_3month(int call_in_cnt_3month) {
		this.call_in_cnt_3month = call_in_cnt_3month;
	}

	public float getCall_in_len_3month() {
		return call_in_len_3month;
	}

	public void setCall_in_len_3month(float call_in_len_3month) {
		this.call_in_len_3month = call_in_len_3month;
	}

	public int getSms_cnt_3month() {
		return sms_cnt_3month;
	}

	public void setSms_cnt_3month(int sms_cnt_3month) {
		this.sms_cnt_3month = sms_cnt_3month;
	}

	public String getContact_area() {
		return contact_area;
	}

	public void setContact_area(String contact_area) {
		this.contact_area = contact_area;
	}

	public String getContact_name() {
		return contact_name;
	}

	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}

	public String getFirst_time_call_6month() {
		return first_time_call_6month;
	}

	public void setFirst_time_call_6month(String first_time_call_6month) {
		this.first_time_call_6month = first_time_call_6month;
	}

	public String getLast_time_call_6month() {
		return last_time_call_6month;
	}

	public void setLast_time_call_6month(String last_time_call_6month) {
		this.last_time_call_6month = last_time_call_6month;
	} 
	
}
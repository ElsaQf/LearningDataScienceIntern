package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 医疗保险消费明细
 * @author YCM
 * @date 2019年6月24日 上午11:48:20
 */
public class SbConsume implements Serializable{
 
	@Field(type = FieldType.Text, index=false)
	private String balance_date;//结算日期。YYYY-MM-DD
	@Field(type = FieldType.Text, index=false)
	private String medical_institution;//医疗机构
	@Field(type = FieldType.Text, index=false)
	private String type;//类别
	@Field(type = FieldType.Float)
	private Float personal_account_spending;//个人账户支出
	@Field(type = FieldType.Float)
	private Float overall_account_spending;//统筹账户支出
	@Field(type = FieldType.Float)
	private Float large_cost;//大额费用
	@Field(type = FieldType.Float)
	private Float cash_payment;//现金支付
	@Field(type = FieldType.Float)
	private Float other_support;//其他补助
	@Field(type = FieldType.Float)
	private Float total_amount;//总额
	public String getBalance_date() {
		return balance_date;
	}
	public void setBalance_date(String balance_date) {
		this.balance_date = balance_date;
	}
	public String getMedical_institution() {
		return medical_institution;
	}
	public void setMedical_institution(String medical_institution) {
		this.medical_institution = medical_institution;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Float getPersonal_account_spending() {
		return personal_account_spending;
	}
	public void setPersonal_account_spending(Float personal_account_spending) {
		this.personal_account_spending = personal_account_spending;
	}
	public Float getOverall_account_spending() {
		return overall_account_spending;
	}
	public void setOverall_account_spending(Float overall_account_spending) {
		this.overall_account_spending = overall_account_spending;
	}
	public Float getLarge_cost() {
		return large_cost;
	}
	public void setLarge_cost(Float large_cost) {
		this.large_cost = large_cost;
	}
	public Float getCash_payment() {
		return cash_payment;
	}
	public void setCash_payment(Float cash_payment) {
		this.cash_payment = cash_payment;
	}
	public Float getOther_support() {
		return other_support;
	}
	public void setOther_support(Float other_support) {
		this.other_support = other_support;
	}
	public Float getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(Float total_amount) {
		this.total_amount = total_amount;
	}
}

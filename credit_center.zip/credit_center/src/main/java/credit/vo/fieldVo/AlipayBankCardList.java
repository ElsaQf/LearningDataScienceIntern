package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public class AlipayBankCardList implements Serializable {
 
	@Field(type = FieldType.Text)
	private String bank_name; // 银行名称

	@Field(type = FieldType.Text)
	private String card_id; // 银行卡号

	@Field(type = FieldType.Text)
	private String card_type; // 银行卡类型

	@Field(type = FieldType.Text)
	private String cardOwnerName; // 银行卡持卡人姓名

	@Field(type = FieldType.Text)
	private String mobile;

	@Field(type = FieldType.Boolean)
	private Boolean isExpress; // 是否开通快捷支付

	@Field(type = FieldType.Text)
	private String applyTime;// 开通时间

	@Field(type = FieldType.Text)
	private String cardFullNumber;// 银行卡号
    
    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

	public String getCardOwnerName() {
		return cardOwnerName;
	}

	public void setCardOwnerName(String cardOwnerName) {
		this.cardOwnerName = cardOwnerName;
	}

	public Boolean getIsExpress() {
		return isExpress;
	}

	public void setIsExpress(Boolean isExpress) {
		this.isExpress = isExpress;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(String applyTime) {
		this.applyTime = applyTime;
	}

	public String getCardFullNumber() {
		return cardFullNumber;
	}

	public void setCardFullNumber(String cardFullNumber) {
		this.cardFullNumber = cardFullNumber;
	}
    
}

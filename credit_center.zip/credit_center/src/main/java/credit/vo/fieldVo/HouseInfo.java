package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 房产信息
 * @author yuan
 *
 */
@SuppressWarnings("serial")
public class HouseInfo   implements Serializable  {

	@Field(type = FieldType.Text)
	private String level_1_code;	// 省级编码
	
	@Field(type = FieldType.Text)
	private String level_1_name;	// 省级名称
	
	@Field(type = FieldType.Text)
	private String level_2_code;	// 地级编码
	
	@Field(type = FieldType.Text)
	private String level_2_name;	// 地级名称
	
	@Field(type = FieldType.Text)
	private String level_3_code;	// 县级编码
	
	@Field(type = FieldType.Text)
	private String level_3_name;	// 县级名称	
	
	@Field(type = FieldType.Text)
	private String house_address;	// 具体地址
	
	@Field(type = FieldType.Text)
	private String house_type;	// 房屋类型
	
	@Field(type = FieldType.Text)
	private String house_area;	// 房屋面积
	
	@Field(type = FieldType.Text)
	private String house_price;	// 购买价格
	
	@Field(type = FieldType.Text)
	private String house_pay_status;	// 付款状态
	
	@Field(type = FieldType.Text)
	private String house_paid;	//已支付
	
	@Field(type = FieldType.Text)
	private String house_age;	//房龄
	
	@Field(type = FieldType.Boolean)
	private boolean house_is_used;	// 是否为二手房
	
	@Field(type = FieldType.Boolean)
	private boolean house_is_mortgage;	//是否抵押过

	@Field(type = FieldType.Text)
	private List<String> house_image_list = new ArrayList<String>();	// 证明图片 

	@Field(type = FieldType.Integer)
    private int update_time;       //创建时间 

	public String getLevel_1_code() {
		return level_1_code;
	}

	public void setLevel_1_code(String level_1_code) {
		this.level_1_code = level_1_code;
	}

	public String getLevel_1_name() {
		return level_1_name;
	}

	public void setLevel_1_name(String level_1_name) {
		this.level_1_name = level_1_name;
	}

	public String getLevel_2_code() {
		return level_2_code;
	}

	public void setLevel_2_code(String level_2_code) {
		this.level_2_code = level_2_code;
	}

	public String getLevel_2_name() {
		return level_2_name;
	}

	public void setLevel_2_name(String level_2_name) {
		this.level_2_name = level_2_name;
	}

	public String getLevel_3_code() {
		return level_3_code;
	}

	public void setLevel_3_code(String level_3_code) {
		this.level_3_code = level_3_code;
	}

	public String getLevel_3_name() {
		return level_3_name;
	}

	public void setLevel_3_name(String level_3_name) {
		this.level_3_name = level_3_name;
	}

	public String getHouse_address() {
		return house_address;
	}

	public void setHouse_address(String house_address) {
		this.house_address = house_address;
	}

	public String getHouse_type() {
		return house_type;
	}

	public void setHouse_type(String house_type) {
		this.house_type = house_type;
	}

	public String getHouse_area() {
		return house_area;
	}

	public void setHouse_area(String house_area) {
		this.house_area = house_area;
	}

	public String getHouse_price() {
		return house_price;
	}

	public void setHouse_price(String house_price) {
		this.house_price = house_price;
	}

	public String getHouse_pay_status() {
		return house_pay_status;
	}

	public void setHouse_pay_status(String house_pay_status) {
		this.house_pay_status = house_pay_status;
	}

	public String getHouse_paid() {
		return house_paid;
	}

	public void setHouse_paid(String house_paid) {
		this.house_paid = house_paid;
	}

	public String getHouse_age() {
		return house_age;
	}

	public void setHouse_age(String house_age) {
		this.house_age = house_age;
	}

	public boolean isHouse_is_used() {
		return house_is_used;
	}

	public void setHouse_is_used(boolean house_is_used) {
		this.house_is_used = house_is_used;
	}

	public boolean isHouse_is_mortgage() {
		return house_is_mortgage;
	}

	public void setHouse_is_mortgage(boolean house_is_mortgage) {
		this.house_is_mortgage = house_is_mortgage;
	}

	public List<String> getHouse_image_list() {
		return house_image_list;
	}

	public void setHouse_image_list(List<String> house_image_list) {
		this.house_image_list = house_image_list;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}  
 
}

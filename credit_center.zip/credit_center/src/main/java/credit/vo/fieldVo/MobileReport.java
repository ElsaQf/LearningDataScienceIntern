package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商数据(简版和详版报告使用)
 * @author YCM
 * @date 2018年7月6日 下午7:21:15
 */
@SuppressWarnings("serial")
public class MobileReport implements Serializable{
	/*运营商数据*/
	@Field(type = FieldType.Text)
	private String mobilePhone; // 认证手机号
	@Field(type = FieldType.Integer)
	private int telUseTm; // 手机号使用时间>6月(-1不存在数据 >0月份)由于运营商只提供6个月的账单，因此目前最大数为6
	@Field(type = FieldType.Integer)
	private int telExchange; // 手机互通联系人个数(-1不存在数据 >0 数据条数)

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public int getTelUseTm() {
		return telUseTm;
	}

	public void setTelUseTm(int telUseTm) {
		this.telUseTm = telUseTm;
	}

	public int getTelExchange() {
		return telExchange;
	}

	public void setTelExchange(int telExchange) {
		this.telExchange = telExchange;
	}
	
}
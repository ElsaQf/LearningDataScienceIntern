package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 保险缴费记录
 * @author YCM
 * @date 2019年6月24日 上午11:48:20
 */
public class SbInsurance implements Serializable{
 
	@Field(type = FieldType.Text, index=false)
	private String month;//月份。YYYYMM
	@Field(type = FieldType.Integer)
	private Integer month_count;//月数
	@Field(type = FieldType.Text, index=false)
	private String company_name;//公司名称
	@Field(type = FieldType.Float)
	private Float base_number;//缴费基数
	@Field(type = FieldType.Float)
	private Float monthly_company_income;//单位缴存
	@Field(type = FieldType.Float)
	private Float monthly_personal_income;//个人缴存
	@Field(type = FieldType.Text, index=false)
	private String type;//缴费状态
	@Field(type = FieldType.Float)
	private Float company_percentage;//单位缴存比例
	@Field(type = FieldType.Float)
	private Float personal_percentage;//个人缴存比例
	@Field(type = FieldType.Text, index=false)
	private String last_pay_date;//缴存日期。YYYY-MM-DD
	
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Integer getMonth_count() {
		return month_count;
	}
	public void setMonth_count(Integer month_count) {
		this.month_count = month_count;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public Float getBase_number() {
		return base_number;
	}
	public void setBase_number(Float base_number) {
		this.base_number = base_number;
	}
	public Float getMonthly_company_income() {
		return monthly_company_income;
	}
	public void setMonthly_company_income(Float monthly_company_income) {
		this.monthly_company_income = monthly_company_income;
	}
	public Float getMonthly_personal_income() {
		return monthly_personal_income;
	}
	public void setMonthly_personal_income(Float monthly_personal_income) {
		this.monthly_personal_income = monthly_personal_income;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Float getCompany_percentage() {
		return company_percentage;
	}
	public void setCompany_percentage(Float company_percentage) {
		this.company_percentage = company_percentage;
	}
	public Float getPersonal_percentage() {
		return personal_percentage;
	}
	public void setPersonal_percentage(Float personal_percentage) {
		this.personal_percentage = personal_percentage;
	}
	public String getLast_pay_date() {
		return last_pay_date;
	}
	public void setLast_pay_date(String last_pay_date) {
		this.last_pay_date = last_pay_date;
	}
}

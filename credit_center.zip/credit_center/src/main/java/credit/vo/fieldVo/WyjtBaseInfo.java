package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 	无忧借条基本信息
 * @author YCM
 * @date 2019年7月3日 下午7:51:42
 */
public class WyjtBaseInfo implements Serializable{
	@Field(type = FieldType.Text, index = false) 
	private String phone;//手机号
	@Field(type = FieldType.Text, index = false) 
	private String addr;//地址
	@Field(type = FieldType.Text, index = false) 
	private String email;//邮箱
	@Field(type = FieldType.Text, index = false) 
	private String id_no;//身份证
	@Field(type = FieldType.Text, index = false) 
	private String name;//姓名
	@Field(type = FieldType.Text, index = false) 
	private String rank_name;//信用等级
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRank_name() {
		return rank_name;
	}
	public void setRank_name(String rank_name) {
		this.rank_name = rank_name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
}

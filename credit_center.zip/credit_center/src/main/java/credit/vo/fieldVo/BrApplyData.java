package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 百融标签数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrApplyData implements Serializable {

    @Field(type = FieldType.Text)
    private String allnum; //次数
    @Field(type = FieldType.Text)
	private String orgnum;//机构数
	public String getAllnum() {
		return allnum;
	}
	public void setAllnum(String allnum) {
		this.allnum = allnum;
	}
	public String getOrgnum() {
		return orgnum;
	}
	public void setOrgnum(String orgnum) {
		this.orgnum = orgnum;
	}
    
    
}

package credit.vo.fieldVo;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public class AlipayBillRecord implements Serializable {

    private String consumeTitle;

    private String consumeDate;

    private String consumeFee;
    
    private String tradeStatusName; // 交易状态
    
    public String getConsumeTitle() {
        return consumeTitle;
    }

    public void setConsumeTitle(String consumeTitle) {
        this.consumeTitle = consumeTitle;
    }

    public String getConsumeDate() {
        return consumeDate;
    }

    public void setConsumeDate(String consumeDate) {
        this.consumeDate = consumeDate;
    }

    public String getConsumeFee() {
        return consumeFee;
    }

    public void setConsumeFee(String consumeFee) {
        this.consumeFee = consumeFee;
    }

	public String getTradeStatusName() {
		return tradeStatusName;
	}

	public void setTradeStatusName(String tradeStatusName) {
		this.tradeStatusName = tradeStatusName;
	}
    
}

package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商通话归属地分析
 * @author YCM
 * @date 2019年7月1日 下午6:17:13
 */
@SuppressWarnings("serial")
public class CallAreaStats implements Serializable, Comparable<CallAreaStats>{
	@Field(type = FieldType.Text, index = false)
	private	String call_area_city;//通话地城市
	@Field(type = FieldType.Integer)
	private	Integer	call_count_6month;//联系人的通话总次数
	@Field(type = FieldType.Integer)
	private	Integer	call_count_active_6month;//电话呼出次数
	@Field(type = FieldType.Integer)
	private	Integer	call_count_passive_6month;//电话呼入次数
	@Field(type = FieldType.Float)
	private	Float call_time_6month;//联系人的通话总时长
	@Field(type = FieldType.Float)
	private	Float call_time_active_6month;//电话呼出总时间（分）
	@Field(type = FieldType.Float)
	private	Float call_time_passive_6month;//电话呼入总时间（分）
	
	@Override
	public int compareTo(CallAreaStats o) {
		if(this.call_time_6month > o.call_time_6month){
			return -1;
		}else{
			return 1;
		}
	}

	public String getCall_area_city() {
		return call_area_city;
	}

	public void setCall_area_city(String call_area_city) {
		this.call_area_city = call_area_city;
	}

	public Integer getCall_count_6month() {
		return call_count_6month;
	}

	public void setCall_count_6month(Integer call_count_6month) {
		this.call_count_6month = call_count_6month;
	}

	public Integer getCall_count_active_6month() {
		return call_count_active_6month;
	}

	public void setCall_count_active_6month(Integer call_count_active_6month) {
		this.call_count_active_6month = call_count_active_6month;
	}

	public Integer getCall_count_passive_6month() {
		return call_count_passive_6month;
	}

	public void setCall_count_passive_6month(Integer call_count_passive_6month) {
		this.call_count_passive_6month = call_count_passive_6month;
	}

	public Float getCall_time_6month() {
		return call_time_6month;
	}

	public void setCall_time_6month(Float call_time_6month) {
		this.call_time_6month = call_time_6month;
	}

	public Float getCall_time_active_6month() {
		return call_time_active_6month;
	}

	public void setCall_time_active_6month(Float call_time_active_6month) {
		this.call_time_active_6month = call_time_active_6month;
	}

	public Float getCall_time_passive_6month() {
		return call_time_passive_6month;
	}

	public void setCall_time_passive_6month(Float call_time_passive_6month) {
		this.call_time_passive_6month = call_time_passive_6month;
	}
}

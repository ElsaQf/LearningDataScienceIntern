package credit.vo.fieldVo;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo.parmVo
 * Created by bob on 18-7-5.
 * Description:   (报告)电商月消费
 *******************************************************************************/

public class JdExpense implements Serializable, Comparable<JdExpense> {

    private static final long serialVersionUID = -5663330677942905951L;

    public String trans_mth; // 月份

    public Float all_amount; // 全部消费金额

    public Integer all_count; // 全部消费次数

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public String getTrans_mth() {
        return trans_mth;
    }

    public void setTrans_mth(String trans_mth) {
        this.trans_mth = trans_mth;
    }

    public Float getAll_amount() {
        return all_amount;
    }

    public void setAll_amount(Float all_amount) {
        this.all_amount = all_amount;
    }

    public Integer getAll_count() {
        return all_count;
    }

    public void setAll_count(Integer all_count) {
        this.all_count = all_count;
    }

    @Override
    public int compareTo(JdExpense o) {
        if (this.trans_mth.compareToIgnoreCase(o.trans_mth) > 0) {
            return -1;
        } else {
            return 1;
        }
    }
}
package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
     *  运营商静默统计
 * @author YCM
 * @date 2019年7月1日 下午6:16:51
 */
@SuppressWarnings("serial")
public class ActiveSilentStats implements Serializable {
	@Field(type = FieldType.Integer)
	private Integer	six_month_silent_days	;//	近6个月静默天数
	@Field(type = FieldType.Integer)
	private Integer	six_month_max_silent_days	;//	近6个月最长静默天数
	@Field(type = FieldType.Integer)
	private Integer	six_month_continue_silence_over3day_cnt	;//	近6月连续静默>=3天的次数
	@Field(type = FieldType.Integer)
	private Integer	three_month_silent_days	;//	近3个月静默天数
	@Field(type = FieldType.Integer)
	private Integer	three_month_max_silent_days	;//	近3个月最长静默天数
	@Field(type = FieldType.Integer)
	private Integer	three_month_continue_silence_over3day_cnt	;//	近3个月连续静默>=3天的次数
	@Field(type = FieldType.Integer)
	private Integer	one_month_silent_days	;//	近1个月静默天数
	@Field(type = FieldType.Integer)
	private Integer	one_month_max_silent_days	;//	近1个月最长静默天数
	@Field(type = FieldType.Integer)
	private Integer	one_month_continue_silence_over3day_cnt	;//	近1个月连续静默>=3天的次数
	@Field(type = FieldType.Integer)
	private Integer	one_week_silent_days	;//	近1周静默天数
	@Field(type = FieldType.Integer)
	private Integer	one_week_max_silent_days	;//	近1周最长静默天数
	@Field(type = FieldType.Integer)
	private Integer	one_week_continue_silence_over3day_cnt	;//	近1周连续静默>=3天的次数
	
	public Integer getSix_month_silent_days() {
		return six_month_silent_days;
	}
	public void setSix_month_silent_days(Integer six_month_silent_days) {
		this.six_month_silent_days = six_month_silent_days;
	}
	public Integer getSix_month_max_silent_days() {
		return six_month_max_silent_days;
	}
	public void setSix_month_max_silent_days(Integer six_month_max_silent_days) {
		this.six_month_max_silent_days = six_month_max_silent_days;
	}
	public Integer getThree_month_silent_days() {
		return three_month_silent_days;
	}
	public void setThree_month_silent_days(Integer three_month_silent_days) {
		this.three_month_silent_days = three_month_silent_days;
	}
	public Integer getThree_month_max_silent_days() {
		return three_month_max_silent_days;
	}
	public void setThree_month_max_silent_days(Integer three_month_max_silent_days) {
		this.three_month_max_silent_days = three_month_max_silent_days;
	}
	public Integer getOne_month_silent_days() {
		return one_month_silent_days;
	}
	public void setOne_month_silent_days(Integer one_month_silent_days) {
		this.one_month_silent_days = one_month_silent_days;
	}
	public Integer getOne_month_max_silent_days() {
		return one_month_max_silent_days;
	}
	public void setOne_month_max_silent_days(Integer one_month_max_silent_days) {
		this.one_month_max_silent_days = one_month_max_silent_days;
	}
	public Integer getOne_week_silent_days() {
		return one_week_silent_days;
	}
	public void setOne_week_silent_days(Integer one_week_silent_days) {
		this.one_week_silent_days = one_week_silent_days;
	}
	public Integer getOne_week_max_silent_days() {
		return one_week_max_silent_days;
	}
	public void setOne_week_max_silent_days(Integer one_week_max_silent_days) {
		this.one_week_max_silent_days = one_week_max_silent_days;
	}
	public Integer getSix_month_continue_silence_over3day_cnt() {
		return six_month_continue_silence_over3day_cnt;
	}
	public void setSix_month_continue_silence_over3day_cnt(Integer six_month_continue_silence_over3day_cnt) {
		this.six_month_continue_silence_over3day_cnt = six_month_continue_silence_over3day_cnt;
	}
	public Integer getThree_month_continue_silence_over3day_cnt() {
		return three_month_continue_silence_over3day_cnt;
	}
	public void setThree_month_continue_silence_over3day_cnt(Integer three_month_continue_silence_over3day_cnt) {
		this.three_month_continue_silence_over3day_cnt = three_month_continue_silence_over3day_cnt;
	}
	public Integer getOne_month_continue_silence_over3day_cnt() {
		return one_month_continue_silence_over3day_cnt;
	}
	public void setOne_month_continue_silence_over3day_cnt(Integer one_month_continue_silence_over3day_cnt) {
		this.one_month_continue_silence_over3day_cnt = one_month_continue_silence_over3day_cnt;
	}
	public Integer getOne_week_continue_silence_over3day_cnt() {
		return one_week_continue_silence_over3day_cnt;
	}
	public void setOne_week_continue_silence_over3day_cnt(Integer one_week_continue_silence_over3day_cnt) {
		this.one_week_continue_silence_over3day_cnt = one_week_continue_silence_over3day_cnt;
	}
	
}

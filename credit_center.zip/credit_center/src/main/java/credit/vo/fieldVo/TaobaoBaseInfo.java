package credit.vo.fieldVo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝基础信息
 * @author zhanglle
 *
 */
public class TaobaoBaseInfo implements Serializable{
	
	@Field(type = FieldType.Text) 
	private String taobaoAccount;//淘宝账号
	
	@Field(type = FieldType.Text) 
	private String taobaoScore;//淘气值
	
	@Field(type = FieldType.Text) 
	private String tmallScore;//天猫分
	
	@Field(type = FieldType.Text) 
	private String nickName;//淘宝昵称
	
	@Field(type = FieldType.Text) 
	private String userName;//用户姓名
	
	@Field(type = FieldType.Text) 
	private String tbRealName;//真实姓名（实名认证）
	
	@Field(type = FieldType.Text) 
	private String gender;//性别
	
	@Field(type = FieldType.Text) 
	private String email;//绑定邮箱
	
	@Field(type = FieldType.Text) 
	private String cellPhone;//绑定手机号
	
	@Field(type = FieldType.Text) 
	private String securityLevel;//淘宝安全等级
	
	@Field(type = FieldType.Text) 
	private String level;//会员等级（铜牌）
	
	@Field(type = FieldType.Text) 
	private String websiteId;//网站ID
	
	@Field(type = FieldType.Text) 
	private String cardCode;//身份证
	
	@Field(type = FieldType.Text) 
	private String lastLoginTime;//上次登录网站时间

	public String getTaobaoAccount() {
		return taobaoAccount;
	}

	public void setTaobaoAccount(String taobaoAccount) {
		this.taobaoAccount = taobaoAccount;
	}

	public String getTaobaoScore() {
		return taobaoScore;
	}

	public void setTaobaoScore(String taobaoScore) {
		this.taobaoScore = taobaoScore;
	}

	public String getTmallScore() {
		return tmallScore;
	}

	public void setTmallScore(String tmallScore) {
		this.tmallScore = tmallScore;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getTbRealName() {
		return tbRealName;
	}

	public void setTbRealName(String tbRealName) {
		this.tbRealName = tbRealName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getSecurityLevel() {
		return securityLevel;
	}

	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getWebsiteId() {
		return websiteId;
	}

	public void setWebsiteId(String websiteId) {
		this.websiteId = websiteId;
	}

	public String getCardCode() {
		return cardCode;
	}

	public void setCardCode(String cardCode) {
		this.cardCode = cardCode;
	}

	public String getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}

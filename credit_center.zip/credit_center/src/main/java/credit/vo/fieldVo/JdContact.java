package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-7.
 * Description:  电商收货人信息
 *******************************************************************************/

public class JdContact implements Serializable ,Comparable<JdContact>{

    private static final long serialVersionUID = 4734346787136133651L;


    public String contact_name;// 联系人姓名

    public String contact_type;// 联系人类型（"0":配偶，"1":父母，"2":兄弟姐妹,"3":子女,"4":同事,"5": 同学,"6": 朋友）;字符串类型非int

    public String begin_date; // 最早出现时间

    public String end_date; // 最晚出现时间

    public Integer total_count = 0; // 电商送货总数

    public float total_amount = 0F; // 电商送货总金额

    public Integer update_time;       //创建时间

    public List<MobileCallDetail> mobile_call_list = new ArrayList<MobileCallDetail>(); // 呼叫信息统计 contact_details

    public Date t_begin_date; // 最早出现时间

    public Date t_end_date; // 最晚出现时间


    public String getContact_name() {
        return contact_name;
    }

    public void setContact_name(String contact_name) {
        this.contact_name = contact_name;
    }

    public String getContact_type() {
        return contact_type;
    }

    public void setContact_type(String contact_type) {
        this.contact_type = contact_type;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getBegin_date() {
        return begin_date;
    }

    public void setBegin_date(String begin_date) {
        this.begin_date = begin_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public Integer getTotal_count() {
        return total_count;
    }

    public void setTotal_count(Integer total_count) {
        this.total_count = total_count;
    }

    public float getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(float total_amount) {
        this.total_amount = total_amount;
    }

    public Integer getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Integer update_time) {
        this.update_time = update_time;
    }

    public List<MobileCallDetail> getmobile_call_list() {
        return mobile_call_list;
    }

    public void setmobile_call_list(List<MobileCallDetail> mobile_call_list) {
        this.mobile_call_list = mobile_call_list;
    }

    public Date getT_begin_date() {
        return t_begin_date;
    }

    public void setT_begin_date(Date t_begin_date) {
        this.t_begin_date = t_begin_date;
    }

    public Date getT_end_date() {
        return t_end_date;
    }

    public void setT_end_date(Date t_end_date) {
        this.t_end_date = t_end_date;
    }

    public int compareTo(JdContact o) {
        if(this.t_end_date.before(o.t_end_date)){
            return 1;
        }else{
            return -1;
        }
    }
}


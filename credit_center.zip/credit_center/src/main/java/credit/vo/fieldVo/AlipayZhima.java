package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-11-30
 **/
public class AlipayZhima implements Serializable {

    @Field(type = FieldType.Text)
    private String zhima_center; // 芝麻分

    public String getZhima_center() {
        return zhima_center;
    }

    public void setZhima_center(String zhima_center) {
        this.zhima_center = zhima_center;
    }
}

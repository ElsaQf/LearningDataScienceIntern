package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 *	 无忧借条详情
 * @author YCM
 * @date 2019年7月3日 下午7:53:24
 */
public class WyjtLoan implements Serializable{
	
	@Field(type = FieldType.Text, index = false) 
	private String loan_id;//借条id
	@Field(type = FieldType.Float) 
	private Float amount;//金额
	@Field(type = FieldType.Text, index = false) 
	private String partner_name;//姓名
	@Field(type = FieldType.Text, index = false) 
	private String create_date;//借款时间
	@Field(type = FieldType.Text, index = false) 
	private String repay_date;//还款时间
	@Field(type = FieldType.Integer) 
	private Integer raw_status;//原生借条状态
	@Field(type = FieldType.Integer) 
	private Integer report_status;//报告借条状态
	
	public String getLoan_id() {
		return loan_id;
	}
	public void setLoan_id(String loan_id) {
		this.loan_id = loan_id;
	}
	public Float getAmount() {
		return amount;
	}
	public void setAmount(Float amount) {
		this.amount = amount;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}
	public String getRepay_date() {
		return repay_date;
	}
	public void setRepay_date(String repay_date) {
		this.repay_date = repay_date;
	}
	public Integer getRaw_status() {
		return raw_status;
	}
	public void setRaw_status(Integer raw_status) {
		this.raw_status = raw_status;
	}
	public Integer getReport_status() {
		return report_status;
	}
	public void setReport_status(Integer report_status) {
		this.report_status = report_status;
	}
	public String getPartner_name() {
		return partner_name;
	}
	public void setPartner_name(String partner_name) {
		this.partner_name = partner_name;
	}
 
}

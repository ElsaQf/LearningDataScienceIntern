package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@SuppressWarnings("serial")
public class MultipointLendDetail implements Serializable{
	@Field(type = FieldType.Integer)
	private int borrow_type; //'借款类型0.未知1.个人信贷2.个人抵押3.企业信贷4.企业抵押',
	@Field(type = FieldType.Integer)
	private int borrow_state;//借款状态0.未知1.拒贷2.批贷已放款4.借款人放弃申请5.审核中6.待放款（3同6意义相同）',
	@Field(type = FieldType.Integer)
	private int borrow_amount; //'合同金额-7.[0,0.1) -6.[0.1,0.2) -5.[0.2,0.3) -4.[0.3,0.4) -3.[0.4,0.6) -2.[0.6,0.8) -1.[0.8,1) 0.未知 1.[1,2) 2.[2,4) 3.[4,6) 4.[6,8)…….(单位:万元)2万一档依次类推',
	@Field(type = FieldType.Integer)
	private int contract_date;// '合同日期(未批贷时为借款日期)',
	@Field(type = FieldType.Integer)
	private int  loan_period;// '批贷期数',
	@Field(type = FieldType.Integer)
	private int  repay_state;// '还款状态0.未知1.正常2.M1 3.M2 4.M3 5.M4 6.M5 7.M6 8.M6+9.已还清',
	@Field(type = FieldType.Long)
	private Long  arrears_amount; //欠款金额(实际金额=91返回金额/100000)',
	
	private String  company_code; //'公司编码有三种一、以（P2P）开头的例：P2P12345678不作为具体公司标识仅作为参与反馈公司的标示可以用于识别反馈公司的数量 二、（人人催）开头的这类数据是经过催收的人员名单。三、（风险名单）的这类数据是由人人催系统提供的风险预警名单表示客户存在风险',
	@Field(type = FieldType.Integer)
	private int  crt_tm; //'创建时间'


	public int getBorrow_type() {
		return borrow_type;
	}

	public void setBorrow_type(int borrow_type) {
		this.borrow_type = borrow_type;
	}

	public int getBorrow_state() {
		return borrow_state;
	}

	public void setBorrow_state(int borrow_state) {
		this.borrow_state = borrow_state;
	}

	public int getBorrow_amount() {
		return borrow_amount;
	}

	public void setBorrow_amount(int borrow_amount) {
		this.borrow_amount = borrow_amount;
	}



	public int getContract_date() {
		return contract_date;
	}

	public void setContract_date(int contract_date) {
		this.contract_date = contract_date;
	}

	public int getLoan_period() {
		return loan_period;
	}

	public void setLoan_period(int loan_period) {
		this.loan_period = loan_period;
	}

	public int getRepay_state() {
		return repay_state;
	}

	public void setRepay_state(int repay_state) {
		this.repay_state = repay_state;
	}



	public Long getArrears_amount() {
		return arrears_amount;
	}

	public void setArrears_amount(Long arrears_amount) {
		this.arrears_amount = arrears_amount;
	}

	public String getCompany_code() {
		return company_code;
	}

	public void setCompany_code(String company_code) {
		this.company_code = company_code;
	}

	public int getCrt_tm() {
		return crt_tm;
	}

	public void setCrt_tm(int crt_tm) {
		this.crt_tm = crt_tm;
	}
	
	
	
}

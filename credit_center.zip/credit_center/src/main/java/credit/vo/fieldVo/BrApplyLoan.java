package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 百融标签数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrApplyLoan implements Serializable {

    @Field(type = FieldType.Text)
    private String apply_day;//申请天数
    @Field(type = FieldType.Object)
    private List<BrApplyTypeData> apply_data;//标签数据
    
	public String getApply_day() {
		return apply_day;
	}
	public void setApply_day(String apply_day) {
		this.apply_day = apply_day;
	}
	public List<BrApplyTypeData> getApply_data() {
		return apply_data;
	}
	public void setApply_data(List<BrApplyTypeData> apply_data) {
		this.apply_data = apply_data;
	}
	 
}

package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 医疗保险缴费总览
 * @author YCM
 * @date 2019年6月24日 上午11:48:20
 */
public class SbOverview implements Serializable{
 
	@Field(type = FieldType.Text, index=false)
	private String begin_date;//参保日期。YYYYMM
	@Field(type = FieldType.Text, index=false)
	private String company;//当前参保公司名称
	@Field(type = FieldType.Text, index=false)
	private String end_date;//数据期别。YYYYMM
	@Field(type = FieldType.Integer)
	private Integer total_income_month;//总缴费月数
	@Field(type = FieldType.Integer)
	private Integer arrear_month;//总欠缴月数
	@Field(type = FieldType.Float)
	private Float base_number;//缴费基数。精确到分
	@Field(type = FieldType.Float)
	private Float total_personal_income;//个人总缴费金额。精确到分
	@Field(type = FieldType.Float)
	private Float total_company_income;//单位总缴费金额。精确到分
	@Field(type = FieldType.Float)
	private Float balance;//账户余额。精确到分
	@Field(type = FieldType.Float)
	private Float lastyear_pay_amount;////上年缴存金额
	@Field(type = FieldType.Float)
	private Float thisyear_pay_amount;//本年缴存金额
	@Field(type = FieldType.Integer)
	private Integer thisyear_deposit_month;//当年缴存月份数
	@Field(type = FieldType.Integer)
	private Integer continuous_deposit_month;//连续缴存月份数
	@Field(type = FieldType.Text, index=false)
	private String status;//当前参保状态，0未知 1正常参保 2暂停参保 3注销
	
	public String getBegin_date() {
		return begin_date;
	}
	public void setBegin_date(String begin_date) {
		this.begin_date = begin_date;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public Integer getTotal_income_month() {
		return total_income_month;
	}
	public void setTotal_income_month(Integer total_income_month) {
		this.total_income_month = total_income_month;
	}
	public Integer getArrear_month() {
		return arrear_month;
	}
	public void setArrear_month(Integer arrear_month) {
		this.arrear_month = arrear_month;
	}
	public Float getBase_number() {
		return base_number;
	}
	public void setBase_number(Float base_number) {
		this.base_number = base_number;
	}
	public Float getTotal_personal_income() {
		return total_personal_income;
	}
	public void setTotal_personal_income(Float total_personal_income) {
		this.total_personal_income = total_personal_income;
	}
	public Float getTotal_company_income() {
		return total_company_income;
	}
	public void setTotal_company_income(Float total_company_income) {
		this.total_company_income = total_company_income;
	}
	public Float getBalance() {
		return balance;
	}
	public void setBalance(Float balance) {
		this.balance = balance;
	}
	public Float getLastyear_pay_amount() {
		return lastyear_pay_amount;
	}
	public void setLastyear_pay_amount(Float lastyear_pay_amount) {
		this.lastyear_pay_amount = lastyear_pay_amount;
	}
	public Float getThisyear_pay_amount() {
		return thisyear_pay_amount;
	}
	public void setThisyear_pay_amount(Float thisyear_pay_amount) {
		this.thisyear_pay_amount = thisyear_pay_amount;
	}
	public Integer getThisyear_deposit_month() {
		return thisyear_deposit_month;
	}
	public void setThisyear_deposit_month(Integer thisyear_deposit_month) {
		this.thisyear_deposit_month = thisyear_deposit_month;
	}
	public Integer getContinuous_deposit_month() {
		return continuous_deposit_month;
	}
	public void setContinuous_deposit_month(Integer continuous_deposit_month) {
		this.continuous_deposit_month = continuous_deposit_month;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}

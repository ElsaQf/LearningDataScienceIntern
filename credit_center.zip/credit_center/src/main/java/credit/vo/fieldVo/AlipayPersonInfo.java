package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
@SuppressWarnings("serial")
public class AlipayPersonInfo implements Serializable {

	@Field(type = FieldType.Text)
	private String name; //支付宝处登记姓名
	
	@Field(type = FieldType.Text)
	private String credentials_no; //支付宝处登记身份证号

	@Field(type = FieldType.Text)
	private String mobile; //支付宝处登记手机
	
	@Field(type = FieldType.Text)
	private String alipayAccount; //支付宝账号
	
	@Field(type = FieldType.Text)
	private String email; //支付宝处登记邮箱
	
	@Field(type = FieldType.Date)
	private Date registerTime; //支付宝注册时间
	
	@Field(type = FieldType.Integer)
	private Integer antMemberScore; //蚂蚁会员
	
	@Field(type = FieldType.Boolean)
	private Boolean isVerified; //是否实名认证

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCredentials_no() {
		return credentials_no;
	}

	public void setCredentials_no(String credentials_no) {
		this.credentials_no = credentials_no;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAlipayAccount() {
		return alipayAccount;
	}

	public void setAlipayAccount(String alipayAccount) {
		this.alipayAccount = alipayAccount;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	public Boolean getIsVerified() {
		return isVerified;
	}

	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}

	public Integer getAntMemberScore() {
		return antMemberScore;
	}

	public void setAntMemberScore(Integer antMemberScore) {
		this.antMemberScore = antMemberScore;
	}
 
}

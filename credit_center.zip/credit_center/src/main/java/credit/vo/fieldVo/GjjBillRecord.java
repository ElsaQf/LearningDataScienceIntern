package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * 公积金缴存记录
 * @author YCM
 * @date 2019年6月26日 上午10:27:00
 */
public class GjjBillRecord implements Serializable {

    @Field(type = FieldType.Float)
    private Float income;//缴存金额。单位：分
    @Field(type = FieldType.Float)
    private Float corp_income;//单位缴存金额。单位：分
    @Field(type = FieldType.Float)
    private Float cust_income;//个人缴存金额。单位：分
    @Field(type = FieldType.Float)
    private Float balance;//余额。单位：分
    @Field(type = FieldType.Text, index=false)
    private String deal_time;//发生时间
    @Field(type = FieldType.Text, index=false)
    private String corp_name;//缴存单位
    @Field(type = FieldType.Float)
    private Float outcome;//取出金额。单位：分
    @Field(type = FieldType.Text, index=false)
    private String desc;//描述
	public Float getIncome() {
		return income;
	}
	public void setIncome(Float income) {
		this.income = income;
	}
	public Float getCorp_income() {
		return corp_income;
	}
	public void setCorp_income(Float corp_income) {
		this.corp_income = corp_income;
	}
	public Float getCust_income() {
		return cust_income;
	}
	public void setCust_income(Float cust_income) {
		this.cust_income = cust_income;
	}
	public Float getBalance() {
		return balance;
	}
	public void setBalance(Float balance) {
		this.balance = balance;
	}
	public String getDeal_time() {
		return deal_time;
	}
	public void setDeal_time(String deal_time) {
		this.deal_time = deal_time;
	}
	public String getCorp_name() {
		return corp_name;
	}
	public void setCorp_name(String corp_name) {
		this.corp_name = corp_name;
	}
	public Float getOutcome() {
		return outcome;
	}
	public void setOutcome(Float outcome) {
		this.outcome = outcome;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}

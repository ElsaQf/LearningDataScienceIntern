package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 定位信息
 * @author YCM
 *
 */
@SuppressWarnings("serial")
public class LocationInfo  implements Serializable  {
	
	@Field(type = FieldType.Text)
	private String province_name;	// 定位省级名称
	
	@Field(type = FieldType.Text)
	private String city_name;		// 定位地级名称
	
	@Field(type = FieldType.Text)
	private String district_name;	// 定位县级名称
	
	@Field(type = FieldType.Text)
	private String address;	// 定位地址 
	
	@Field(type = FieldType.Integer)
    private Integer location_tm;       //定位时间
	
	@Field(type = FieldType.Integer)
	public int location_count; 	// 定位次数
	
	@Field(type = FieldType.Integer)
    private Integer update_time;       //创建时间
	 
	public String getProvince_name() {
		return province_name;
	}

	public void setProvince_name(String province_name) {
		this.province_name = province_name;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getDistrict_name() {
		return district_name;
	}

	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getLocation_count() {
		return location_count;
	}

	public void setLocation_count(int location_count) {
		this.location_count = location_count;
	}

	public Integer getLocation_tm() {
		return location_tm;
	}

	public void setLocation_tm(Integer location_tm) {
		this.location_tm = location_tm;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
 
}

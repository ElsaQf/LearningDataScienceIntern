package credit.vo.fieldVo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝基础信息
 * @author zhanglle
 *
 */
public class AlipayBaseInfo implements Serializable{
	@Field(type = FieldType.Text) 
	private String alipayAcc;//支付宝账号
	
	@Field(type = FieldType.Text) 
	private String alipayAccType;//支付宝账户类型
	
	@Field(type = FieldType.Text) 
	private String alipayBalance;//支付宝余额
	
	@Field(type = FieldType.Text) 
	private String alipayRegDate;//支付宝注册日期
	
	@Field(type = FieldType.Text) 
	private String antMemberScore;//芝麻分 (已不支持)
	
	@Field(type = FieldType.Text) 
	private String balancePaymentEnable;//是否开启余额支付
	
	@Field(type = FieldType.Text) 
	private String creditLevelAsBuyer;//作为买家信用额度
	
	@Field(type = FieldType.Text) 
	private String creditLevelAsSeller;//作为卖家信用额度
	
	@Field(type = FieldType.Boolean) 
	private Boolean isVerified;//是否实名认证
	
	@Field(type = FieldType.Text) 
	private String yuebaoBalance;//余额宝余额
	
	@Field(type = FieldType.Text) 
	private String yuebaoIncome;//余额宝累计收益
	
	@Field(type = FieldType.Text) 
	private String aliRealName;//支付宝真实姓名
	
	@Field(type = FieldType.Text) 
	private String email;//绑定邮箱
	
	@Field(type = FieldType.Text) 
	private String cellPhone;//绑定手机号
	
	@Field(type = FieldType.Text) 
	private String cardCode;//身份证
	
	@Field(type = FieldType.Text) 
	private String lastLoginTime;//上次登录网站时间
	
	@Field(type = FieldType.Text) 
	private String zhaoCaiBaoTotal;//招财宝理财总金额
	
	@Field(type = FieldType.Text) 
	private String zhaoCaiBaoYesterdayInCome;//招财宝昨日收益
	
	@Field(type = FieldType.Text) 
	private String zhaoCaiBaoIncome;//招财宝历史累计收益
	
	@Field(type = FieldType.Text) 
	private String zhaoCaiBaoExpectedIncome;//招财宝预估到期可获得收益

	public String getAlipayAcc() {
		return alipayAcc;
	}

	public void setAlipayAcc(String alipayAcc) {
		this.alipayAcc = alipayAcc;
	}

	public String getAlipayAccType() {
		return alipayAccType;
	}

	public void setAlipayAccType(String alipayAccType) {
		this.alipayAccType = alipayAccType;
	}

	public String getAlipayBalance() {
		return alipayBalance;
	}

	public void setAlipayBalance(String alipayBalance) {
		this.alipayBalance = alipayBalance;
	}

	public String getAlipayRegDate() {
		return alipayRegDate;
	}

	public void setAlipayRegDate(String alipayRegDate) {
		this.alipayRegDate = alipayRegDate;
	}

	public String getAntMemberScore() {
		return antMemberScore;
	}

	public void setAntMemberScore(String antMemberScore) {
		this.antMemberScore = antMemberScore;
	}

	public String getBalancePaymentEnable() {
		return balancePaymentEnable;
	}

	public void setBalancePaymentEnable(String balancePaymentEnable) {
		this.balancePaymentEnable = balancePaymentEnable;
	}

	public String getCreditLevelAsBuyer() {
		return creditLevelAsBuyer;
	}

	public void setCreditLevelAsBuyer(String creditLevelAsBuyer) {
		this.creditLevelAsBuyer = creditLevelAsBuyer;
	}

	public String getCreditLevelAsSeller() {
		return creditLevelAsSeller;
	}

	public void setCreditLevelAsSeller(String creditLevelAsSeller) {
		this.creditLevelAsSeller = creditLevelAsSeller;
	}

	public Boolean getIsVerified() {
		return isVerified;
	}

	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}

	public String getYuebaoBalance() {
		return yuebaoBalance;
	}

	public void setYuebaoBalance(String yuebaoBalance) {
		this.yuebaoBalance = yuebaoBalance;
	}

	public String getYuebaoIncome() {
		return yuebaoIncome;
	}

	public void setYuebaoIncome(String yuebaoIncome) {
		this.yuebaoIncome = yuebaoIncome;
	}

	public String getAliRealName() {
		return aliRealName;
	}

	public void setAliRealName(String aliRealName) {
		this.aliRealName = aliRealName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getCardCode() {
		return cardCode;
	}

	public void setCardCode(String cardCode) {
		this.cardCode = cardCode;
	}

	public String getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getZhaoCaiBaoTotal() {
		return zhaoCaiBaoTotal;
	}

	public void setZhaoCaiBaoTotal(String zhaoCaiBaoTotal) {
		this.zhaoCaiBaoTotal = zhaoCaiBaoTotal;
	}

	public String getZhaoCaiBaoYesterdayInCome() {
		return zhaoCaiBaoYesterdayInCome;
	}

	public void setZhaoCaiBaoYesterdayInCome(String zhaoCaiBaoYesterdayInCome) {
		this.zhaoCaiBaoYesterdayInCome = zhaoCaiBaoYesterdayInCome;
	}

	public String getZhaoCaiBaoIncome() {
		return zhaoCaiBaoIncome;
	}

	public void setZhaoCaiBaoIncome(String zhaoCaiBaoIncome) {
		this.zhaoCaiBaoIncome = zhaoCaiBaoIncome;
	}

	public String getZhaoCaiBaoExpectedIncome() {
		return zhaoCaiBaoExpectedIncome;
	}

	public void setZhaoCaiBaoExpectedIncome(String zhaoCaiBaoExpectedIncome) {
		this.zhaoCaiBaoExpectedIncome = zhaoCaiBaoExpectedIncome;
	}
	
}

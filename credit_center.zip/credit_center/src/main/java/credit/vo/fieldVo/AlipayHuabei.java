package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-11-30
 **/
public class AlipayHuabei implements Serializable {

    @Field(type = FieldType.Text)
    private String amount; // 花呗额度(元)
    
    @Field(type = FieldType.Double)
    private Double huabeiOriginalAmount; //花呗原始信用额度

    @Field(type = FieldType.Text)
    private String freeze; // 花呗冻结额

    @Field(type = FieldType.Text)
    private String balance; // 花呗可用额

    @Field(type = FieldType.Text)
    private String bill; // 花呗已使用额
    
    @Field(type = FieldType.Double)
    private Double huabeiPenaltyAmount; //花呗的罚息
    
    @Field(type = FieldType.Integer)
    private Integer huabeiStatus; //花呗状态，0：未冻结，-1：冻结（花呗严重逾期，套现，欺诈会被冻结），1:逾期
    
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFreeze() {
        return freeze;
    }

    public void setFreeze(String freeze) {
        this.freeze = freeze;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getBill() {
        return bill;
    }

    public void setBill(String bill) {
        this.bill = bill;
    }

	public Double getHuabeiOriginalAmount() {
		return huabeiOriginalAmount;
	}

	public void setHuabeiOriginalAmount(Double huabeiOriginalAmount) {
		this.huabeiOriginalAmount = huabeiOriginalAmount;
	}

	public Double getHuabeiPenaltyAmount() {
		return huabeiPenaltyAmount;
	}

	public void setHuabeiPenaltyAmount(Double huabeiPenaltyAmount) {
		this.huabeiPenaltyAmount = huabeiPenaltyAmount;
	}

	public Integer getHuabeiStatus() {
		return huabeiStatus;
	}

	public void setHuabeiStatus(Integer huabeiStatus) {
		this.huabeiStatus = huabeiStatus;
	}
}

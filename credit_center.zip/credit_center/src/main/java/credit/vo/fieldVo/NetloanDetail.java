package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 网贷明细
 * @author YCM
 * @date 2019年3月11日 下午5:45:45
 */
public class NetloanDetail implements Serializable {

	@Field(type = FieldType.Text)
	private String statistic_days;//统计天数
	@Field(type = FieldType.Integer)
	private int query_count;//报告查询次数
	@Field(type = FieldType.Integer)
    private int loan_count;//贷款笔数
	@Field(type = FieldType.Integer)
    private int loan_tenant_count;//贷款机构数
	@Field(type = FieldType.Integer)
    private int average_loan_gapdays;//平均申请间隔时长
	@Field(type = FieldType.Integer)
    private int average_tenant_gapdays;//平均换新机构间隔时长
	@Field(type = FieldType.Integer)
    private int max_loan_amount;//最大贷款金额
	@Field(type = FieldType.Integer)
    private int max_loan_days;//最大贷款天数
	@Field(type = FieldType.Integer)
    private int average_loan_amount;//平均贷款额度
	@Field(type = FieldType.Integer)
    private int max_overdue_days;//最大逾期天数
	@Field(type = FieldType.Integer)
    private int curr_overdue_loan_count;//当前逾期的贷款笔数
	@Field(type = FieldType.Integer)
    private int curr_overdue_tenant_count;//当前逾期的贷款机构数
	@Field(type = FieldType.Integer)
    private int overdue_2week_tenant_count;//逾期2周期以上的机构数 （除小额拖欠）
	@Field(type = FieldType.Integer)
    private int days_from_last_loan;//最后一次贷款距今天数
	@Field(type = FieldType.Integer)
    private int months_from_first_loan;//最早贷款距今月数
	@Field(type = FieldType.Integer)
    private int months_from_last_overdue;//最后一次逾期距今月数
	@Field(type = FieldType.Integer)
    private int months_for_normal_repay;//连续正常还款月数 
	@Field(type = FieldType.Integer)
    private int remaining_amount;//未还款总余额
	@Field(type = FieldType.Integer)
    private int remaining_loan_count;//未结清贷款笔数
	@Field(type = FieldType.Integer)
    private int curr_overdue_amount;//当前逾期金额
	@Field(type = FieldType.Integer)
    private int all_overdue_count;//累计逾期次数 

	public String getStatistic_days() {
		return statistic_days;
	}
	public void setStatistic_days(String statistic_days) {
		this.statistic_days = statistic_days;
	}
	public int getQuery_count() {
		return query_count;
	}
	public void setQuery_count(int query_count) {
		this.query_count = query_count;
	}
	public int getLoan_count() {
		return loan_count;
	}
	public void setLoan_count(int loan_count) {
		this.loan_count = loan_count;
	}
	public int getLoan_tenant_count() {
		return loan_tenant_count;
	}
	public void setLoan_tenant_count(int loan_tenant_count) {
		this.loan_tenant_count = loan_tenant_count;
	}
	public int getAverage_loan_gapdays() {
		return average_loan_gapdays;
	}
	public void setAverage_loan_gapdays(int average_loan_gapdays) {
		this.average_loan_gapdays = average_loan_gapdays;
	}
	public int getAverage_tenant_gapdays() {
		return average_tenant_gapdays;
	}
	public void setAverage_tenant_gapdays(int average_tenant_gapdays) {
		this.average_tenant_gapdays = average_tenant_gapdays;
	}
	public int getMax_loan_amount() {
		return max_loan_amount;
	}
	public void setMax_loan_amount(int max_loan_amount) {
		this.max_loan_amount = max_loan_amount;
	}
	public int getMax_loan_days() {
		return max_loan_days;
	}
	public void setMax_loan_days(int max_loan_days) {
		this.max_loan_days = max_loan_days;
	}
	public int getAverage_loan_amount() {
		return average_loan_amount;
	}
	public void setAverage_loan_amount(int average_loan_amount) {
		this.average_loan_amount = average_loan_amount;
	}
	public int getMax_overdue_days() {
		return max_overdue_days;
	}
	public void setMax_overdue_days(int max_overdue_days) {
		this.max_overdue_days = max_overdue_days;
	}
	public int getCurr_overdue_loan_count() {
		return curr_overdue_loan_count;
	}
	public void setCurr_overdue_loan_count(int curr_overdue_loan_count) {
		this.curr_overdue_loan_count = curr_overdue_loan_count;
	}
	public int getCurr_overdue_tenant_count() {
		return curr_overdue_tenant_count;
	}
	public void setCurr_overdue_tenant_count(int curr_overdue_tenant_count) {
		this.curr_overdue_tenant_count = curr_overdue_tenant_count;
	}
	public int getOverdue_2week_tenant_count() {
		return overdue_2week_tenant_count;
	}
	public void setOverdue_2week_tenant_count(int overdue_2week_tenant_count) {
		this.overdue_2week_tenant_count = overdue_2week_tenant_count;
	}
	public int getDays_from_last_loan() {
		return days_from_last_loan;
	}
	public void setDays_from_last_loan(int days_from_last_loan) {
		this.days_from_last_loan = days_from_last_loan;
	}
	public int getMonths_from_first_loan() {
		return months_from_first_loan;
	}
	public void setMonths_from_first_loan(int months_from_first_loan) {
		this.months_from_first_loan = months_from_first_loan;
	}
	public int getMonths_from_last_overdue() {
		return months_from_last_overdue;
	}
	public void setMonths_from_last_overdue(int months_from_last_overdue) {
		this.months_from_last_overdue = months_from_last_overdue;
	}
	public int getMonths_for_normal_repay() {
		return months_for_normal_repay;
	}
	public void setMonths_for_normal_repay(int months_for_normal_repay) {
		this.months_for_normal_repay = months_for_normal_repay;
	}
	public int getRemaining_amount() {
		return remaining_amount;
	}
	public void setRemaining_amount(int remaining_amount) {
		this.remaining_amount = remaining_amount;
	}
	public int getRemaining_loan_count() {
		return remaining_loan_count;
	}
	public void setRemaining_loan_count(int remaining_loan_count) {
		this.remaining_loan_count = remaining_loan_count;
	}
	public int getCurr_overdue_amount() {
		return curr_overdue_amount;
	}
	public void setCurr_overdue_amount(int curr_overdue_amount) {
		this.curr_overdue_amount = curr_overdue_amount;
	}
	public int getAll_overdue_count() {
		return all_overdue_count;
	}
	public void setAll_overdue_count(int all_overdue_count) {
		this.all_overdue_count = all_overdue_count;
	}
	
}

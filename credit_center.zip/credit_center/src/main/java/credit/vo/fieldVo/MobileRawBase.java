package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商原生数据的基础字段
 * @author YCM
 * @date 2019年6月5日 上午10:51:01
 */
@SuppressWarnings("serial")
public class MobileRawBase implements Serializable{
	
	@Id
	@Field(type = FieldType.Keyword)
	private String id;
	@Field(type = FieldType.Keyword)
	private String user_report_id;//报告ID
	@Field(type = FieldType.Keyword)
    private String system_name;
	@Field(type = FieldType.Keyword)
	private String cell_phone; // 本机号码
	@Field(type = FieldType.Keyword)
	private String month; //月份
	@Field(type = FieldType.Text)
	private String month_str; //月份
	@Field(type = FieldType.Integer)
	private Integer update_time; // 数据获取时间
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUser_report_id() {
		return user_report_id;
	}
	public void setUser_report_id(String user_report_id) {
		this.user_report_id = user_report_id;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public String getCell_phone() {
		return cell_phone;
	}
	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getMonth_str() {
		return month_str;
	}
	public void setMonth_str(String month_str) {
		this.month_str = month_str;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
	
}
package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-7.
 * Description:  电商基础信息
 *******************************************************************************/
public class JdBasiceInfo implements Serializable {

    private static final long serialVersionUID = -719592434990140088L;

    @Field(type = FieldType.Long)
    private int update_time; // 据获取时间
    
    @Field(type = FieldType.Text)
    private String level; // 账号等级(银牌账户)

    @Field(type = FieldType.Text)
    private String nickname; // 昵称

    @Field(type = FieldType.Text)
    private String real_name; // 真实姓名

    @Field(type = FieldType.Text)
    private String website_id; // 网站id

    @Field(type = FieldType.Text)
    private String email; // 用户绑定邮箱

    @Field(type = FieldType.Text)
    private String cell_phone; // 用户手机号

    @Field(type = FieldType.Long)
    private int receiveIsOwn; //收货手机号是本人手机号的个数

    @Field(type = FieldType.Long)
    private int use_time; // 使用时间
    
    @Field(type = FieldType.Text)
    private String identity_code;//身份证

    /*********账户相关信息***********/
    @Field(type = FieldType.Integer)
    private Integer account_balance;//账户余额。单位分
    
    @Field(type = FieldType.Integer)
    private Integer financial_account_balance;//金融帐户余额。单位分
    
    @Field(type = FieldType.Double)
    private Double credit_point;//信用分数。可能有小数
    
    @Field(type = FieldType.Integer)
    private Integer credit_quota;//信用额度（白条额度）
    
    @Field(type = FieldType.Integer)
    private Integer bt_blance;//白条余额
    
    @Field(type = FieldType.Integer)
    private Integer consume_quota;//消费额度（白条欠款）
    
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }

    public String getWebsite_id() {
        return website_id;
    }

    public void setWebsite_id(String website_id) {
        this.website_id = website_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCell_phone() {
        return cell_phone;
    }

    public void setCell_phone(String cell_phone) {
        this.cell_phone = cell_phone;
    }

    public int getUse_time() {
        return use_time;
    }

    public void setUse_time(int use_time) {
        this.use_time = use_time;
    }

    public int getReceiveIsOwn() {
        return receiveIsOwn;
    }

    public void setReceiveIsOwn(int receiveIsOwn) {
        this.receiveIsOwn = receiveIsOwn;
    }

	public String getIdentity_code() {
		return identity_code;
	}

	public void setIdentity_code(String identity_code) {
		this.identity_code = identity_code;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getAccount_balance() {
		return account_balance;
	}

	public void setAccount_balance(Integer account_balance) {
		this.account_balance = account_balance;
	}

	public Integer getFinancial_account_balance() {
		return financial_account_balance;
	}

	public void setFinancial_account_balance(Integer financial_account_balance) {
		this.financial_account_balance = financial_account_balance;
	}

	public Integer getCredit_quota() {
		return credit_quota;
	}

	public void setCredit_quota(Integer credit_quota) {
		this.credit_quota = credit_quota;
	}

	public Integer getConsume_quota() {
		return consume_quota;
	}

	public void setConsume_quota(Integer consume_quota) {
		this.consume_quota = consume_quota;
	}

	public Double getCredit_point() {
		return credit_point;
	}

	public void setCredit_point(Double credit_point) {
		this.credit_point = credit_point;
	}

	public Integer getBt_blance() {
		return bt_blance;
	}

	public void setBt_blance(Integer bt_blance) {
		this.bt_blance = bt_blance;
	}
    
}

package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 百融标签数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrQueryData implements Serializable {

    @Field(type = FieldType.Text)
    private String label_type;//标签类型
    @Field(type = FieldType.Object)
    private List<BrLabelData> label_data;//标签数据
	public String getLabel_type() {
		return label_type;
	}
	public void setLabel_type(String label_type) {
		this.label_type = label_type;
	}
	public List<BrLabelData> getLabel_data() {
		return label_data;
	}
	public void setLabel_data(List<BrLabelData> label_data) {
		this.label_data = label_data;
	}
}

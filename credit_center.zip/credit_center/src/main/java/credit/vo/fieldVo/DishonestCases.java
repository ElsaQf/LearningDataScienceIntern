package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 失信案件详情
 * 
 * @author YCM
 *
 */
@SuppressWarnings("serial")
public class DishonestCases  implements Serializable{

	@Field(type = FieldType.Integer)
	private Integer type; // 失信类型，0：被执行人；1：限制消费人员；2：失信被执行人
	
	@Field(type = FieldType.Text)
	private String caseID; // 案件号
	
	@Field(type = FieldType.Text)
	private String caseCreateTime; //立案时间
	
	@Field(type = FieldType.Text)
	private String courtName; //法院名称
	 
	@Field(type = FieldType.Text)
	private String province; //法院所在省份
	
	@Field(type = FieldType.Text)
	private String caseDocumentID; //执行依据文件号
	
	@Field(type = FieldType.Text)
	private String discreditPublishTime; //如为失信被执行人，则此字段为失信发布日期
	
	@Field(type = FieldType.Text)
	private String executionTarget; //执行标的
	
	@Field(type = FieldType.Text)
	private String leftTarget; //未履行标的
	
	@Field(type = FieldType.Text)
	private String executionDescription; //执行情况描述
	
	@Field(type = FieldType.Text)
	private String caseEndTime; //如为终本案件，则此字段为终本时间；否则无此字段

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}

	public String getCaseCreateTime() {
		return caseCreateTime;
	}

	public void setCaseCreateTime(String caseCreateTime) {
		this.caseCreateTime = caseCreateTime;
	}

	public String getCourtName() {
		return courtName;
	}

	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCaseDocumentID() {
		return caseDocumentID;
	}

	public void setCaseDocumentID(String caseDocumentID) {
		this.caseDocumentID = caseDocumentID;
	}

	public String getDiscreditPublishTime() {
		return discreditPublishTime;
	}

	public void setDiscreditPublishTime(String discreditPublishTime) {
		this.discreditPublishTime = discreditPublishTime;
	}

	public String getExecutionTarget() {
		return executionTarget;
	}

	public void setExecutionTarget(String executionTarget) {
		this.executionTarget = executionTarget;
	}

	public String getLeftTarget() {
		return leftTarget;
	}

	public void setLeftTarget(String leftTarget) {
		this.leftTarget = leftTarget;
	}

	public String getExecutionDescription() {
		return executionDescription;
	}

	public void setExecutionDescription(String executionDescription) {
		this.executionDescription = executionDescription;
	}

	public String getCaseEndTime() {
		return caseEndTime;
	}

	public void setCaseEndTime(String caseEndTime) {
		this.caseEndTime = caseEndTime;
	}
	
	
}

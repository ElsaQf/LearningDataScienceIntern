package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;
import java.util.List;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public class AlipayBillList implements Serializable {

    @Field(type = FieldType.Object)
    private List<AlipayDataList> datalist; // 消费记录
    
    @Field(type = FieldType.Object)
    private List<BillMonthSummary> month_summary; // 消费记录统计

    public List<AlipayDataList> getDatalist() {
        return datalist;
    }

    public void setDatalist(List<AlipayDataList> datalist) {
        this.datalist = datalist;
    }

	public List<BillMonthSummary> getMonth_summary() {
		return month_summary;
	}

	public void setMonth_summary(List<BillMonthSummary> month_summary) {
		this.month_summary = month_summary;
	}
    
}

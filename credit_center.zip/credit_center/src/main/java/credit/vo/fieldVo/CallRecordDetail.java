package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 通话记录详情
 * Title: CallRecordDetail.java
 * @version 1.0
 */
@SuppressWarnings("serial")
public class CallRecordDetail implements Serializable{
	
	@Field(type = FieldType.Text, index=false)
	private String call_start_time; // String 起始时间。YYYY-MM-DD HH:mm:SS或未知
	
	@Field(type = FieldType.Text, index=false)
	private String call_address; // String 通话地点。如：浙江省.杭州市、海外.美国、未知
	
	@Field(type = FieldType.Text, index=false)
	private String call_type_name; // String 呼叫类型。主叫、被叫、呼转、未知
	
	@Field(type = FieldType.Text, index=false)
	private String call_other_number; // String 对方号码
	
	@Field(type = FieldType.Text, index=false)
	private String call_time; // String 通话时长。时长精确到秒
	
	@Field(type = FieldType.Text, index=false)
	private String call_land_type; // String 通话类型。本地通话、国内长途、国际长途、港澳台通话、未知
	
	@Field(type = FieldType.Text, index=false)
	private String call_cost; // String 费用小计。整形数字精确到分

	@Field(type = FieldType.Text, index=false)
	private String contact_type;//号码分类 如银行、保险、快递、律师、汽车、特殊等
	
	@Field(type = FieldType.Text, index=false)
	private String contact_name;//号码标签 如号码互联网标签，若有多个标签，用”;”分割。如：王经理;某房产中介
	
	@Field(type = FieldType.Text, index=false)
	private String contact_area;//号码归属地 即联系人号码的归属地，如：浙江省.杭州市
	
	public String getCall_start_time() {
		return call_start_time;
	}

	public void setCall_start_time(String call_start_time) {
		this.call_start_time = call_start_time;
	}

	public String getCall_address() {
		return call_address;
	}

	public void setCall_address(String call_address) {
		this.call_address = call_address;
	}

	public String getCall_type_name() {
		return call_type_name;
	}

	public void setCall_type_name(String call_type_name) {
		this.call_type_name = call_type_name;
	}

	public String getCall_other_number() {
		return call_other_number;
	}

	public void setCall_other_number(String call_other_number) {
		this.call_other_number = call_other_number;
	}

	public String getCall_time() {
		return call_time;
	}

	public void setCall_time(String call_time) {
		this.call_time = call_time;
	}

	public String getCall_land_type() {
		return call_land_type;
	}

	public void setCall_land_type(String call_land_type) {
		this.call_land_type = call_land_type;
	}

	public String getCall_cost() {
		return call_cost;
	}

	public void setCall_cost(String call_cost) {
		this.call_cost = call_cost;
	}

	public String getContact_type() {
		return contact_type;
	}

	public void setContact_type(String contact_type) {
		this.contact_type = contact_type;
	}

	public String getContact_name() {
		return contact_name;
	}

	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}

	public String getContact_area() {
		return contact_area;
	}

	public void setContact_area(String contact_area) {
		this.contact_area = contact_area;
	}
	
	
}
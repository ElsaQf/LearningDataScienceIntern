package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 车产
 * 
 * @author zhanglle
 *
 */
@SuppressWarnings("serial")
public class CarInfo  implements Serializable{

	@Field(type = FieldType.Text)
	private String car_brand; // 汽车品牌
	
	@Field(type = FieldType.Text)
	private String car_mileage; // 行驶里程
	
	@Field(type = FieldType.Text)
	private String car_price; // 汽车价格
	
	@Field(type = FieldType.Text)
	private String car_pay_status; // 付款状态

	@Field(type = FieldType.Text)
	private String car_paid; // 已支付
	
	@Field(type = FieldType.Text)
	private String level_1_code; // 省级编码
	
	@Field(type = FieldType.Text)
	private String level_1_name; // 省级名称
	
	@Field(type = FieldType.Text)
	private String level_2_code; // 地级编码
	
	@Field(type = FieldType.Text)
	private String level_2_name; // 地级名称
	
	@Field(type = FieldType.Text)
	private String level_3_code; // 县级编码
	
	@Field(type = FieldType.Text)
	private String level_3_name; // 县级名称
	
	@Field(type = FieldType.Text)
	private String car_age; // 车龄
	
	@Field(type = FieldType.Boolean)
	private boolean car_is_used; // 是否二手车
	
	@Field(type = FieldType.Boolean)
	private boolean car_is_mortgage; // 是否抵押过

	@Field(type = FieldType.Text)
	private List<String> car_image_list = new ArrayList<String>(); // 证明图片

	@Field(type = FieldType.Integer)
	private Integer update_time; // 车产数据更新时间

	public String getCar_brand() {
		return car_brand;
	}

	public void setCar_brand(String car_brand) {
		this.car_brand = car_brand;
	}

	public String getCar_mileage() {
		return car_mileage;
	}

	public void setCar_mileage(String car_mileage) {
		this.car_mileage = car_mileage;
	}

	public String getCar_price() {
		return car_price;
	}

	public void setCar_price(String car_price) {
		this.car_price = car_price;
	}

	public String getCar_pay_status() {
		return car_pay_status;
	}

	public void setCar_pay_status(String car_pay_status) {
		this.car_pay_status = car_pay_status;
	}

	public String getCar_paid() {
		return car_paid;
	}

	public void setCar_paid(String car_paid) {
		this.car_paid = car_paid;
	}

	public String getLevel_1_code() {
		return level_1_code;
	}

	public void setLevel_1_code(String level_1_code) {
		this.level_1_code = level_1_code;
	}

	public String getLevel_1_name() {
		return level_1_name;
	}

	public void setLevel_1_name(String level_1_name) {
		this.level_1_name = level_1_name;
	}

	public String getLevel_2_code() {
		return level_2_code;
	}

	public void setLevel_2_code(String level_2_code) {
		this.level_2_code = level_2_code;
	}

	public String getLevel_2_name() {
		return level_2_name;
	}

	public void setLevel_2_name(String level_2_name) {
		this.level_2_name = level_2_name;
	}

	public String getLevel_3_code() {
		return level_3_code;
	}

	public void setLevel_3_code(String level_3_code) {
		this.level_3_code = level_3_code;
	}

	public String getLevel_3_name() {
		return level_3_name;
	}

	public void setLevel_3_name(String level_3_name) {
		this.level_3_name = level_3_name;
	}

	public String getCar_age() {
		return car_age;
	}

	public void setCar_age(String car_age) {
		this.car_age = car_age;
	}

	public boolean isCar_is_used() {
		return car_is_used;
	}

	public void setCar_is_used(boolean car_is_used) {
		this.car_is_used = car_is_used;
	}

	public boolean isCar_is_mortgage() {
		return car_is_mortgage;
	}

	public void setCar_is_mortgage(boolean car_is_mortgage) {
		this.car_is_mortgage = car_is_mortgage;
	}

	public List<String> getCar_image_list() {
		return car_image_list;
	}

	public void setCar_image_list(List<String> car_image_list) {
		this.car_image_list = car_image_list;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
}

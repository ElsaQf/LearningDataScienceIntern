package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 用户基础信息表
 * @author yuan
 *
 */
@SuppressWarnings("serial")
public class UserBaseInfo implements Serializable  { 
	@Field(type = FieldType.Text)
	private String telephone;
	
	@Field(type = FieldType.Text)
    private String level_1_code;  	// 省级编码
	
	@Field(type = FieldType.Text)
    private String level_1_name;  	// 省级编码
	
	@Field(type = FieldType.Text)
    private String level_2_code;  	// 地级编码
	
	@Field(type = FieldType.Text)
    private String level_2_name;  	// 地级名称
	
	@Field(type = FieldType.Text)
    private String level_3_code;  	// 县级编码
	
	@Field(type = FieldType.Text)
    private String level_3_name;  	// 县级名称
	
	@Field(type = FieldType.Text)
    private String home_addr; 	// 我的家庭地址(与购物信息关联)
	
	@Field(type = FieldType.Text)
	private String homeRegistAddr;//户籍地址

	@Field(type = FieldType.Text)
	private String email;//电子邮箱

	@Field(type = FieldType.Text)
    private String wechat_id; 	// 微信号码，用于和对方聊天

	@Field(type = FieldType.Integer)
	private Integer zhima_score;		// 芝麻信用得分

	@Field(type = FieldType.Text)
	private List<String> idcard_imgs;		// 身份证认证图片

	@Field(type = FieldType.Text)
	private List<String> zhifubao_imgs;		// 支付宝认证图片

	@Field(type = FieldType.Text)
	private List<String> jiedaibao_imgs;		// 借贷宝认证图片

	@Field(type = FieldType.Integer)
	private Integer update_time;       //创建时间

	
	public String getLevel_1_code() {
		return level_1_code;
	}

	public void setLevel_1_code(String level_1_code) {
		this.level_1_code = level_1_code;
	}

	public String getLevel_1_name() {
		return level_1_name;
	}

	public void setLevel_1_name(String level_1_name) {
		this.level_1_name = level_1_name;
	}

	public String getLevel_2_code() {
		return level_2_code;
	}

	public void setLevel_2_code(String level_2_code) {
		this.level_2_code = level_2_code;
	}

	public String getLevel_2_name() {
		return level_2_name;
	}

	public void setLevel_2_name(String level_2_name) {
		this.level_2_name = level_2_name;
	}

	public String getLevel_3_code() {
		return level_3_code;
	}

	public void setLevel_3_code(String level_3_code) {
		this.level_3_code = level_3_code;
	}

	public String getLevel_3_name() {
		return level_3_name;
	}

	public void setLevel_3_name(String level_3_name) {
		this.level_3_name = level_3_name;
	}

	public String getHome_addr() {
		return home_addr;
	}

	public void setHome_addr(String home_addr) {
		this.home_addr = home_addr;
	}

	public String getWechat_id() {
		return wechat_id;
	}

	public void setWechat_id(String wechat_id) {
		this.wechat_id = wechat_id;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Integer getZhima_score() {
		return zhima_score;
	}

	public void setZhima_score(Integer zhima_score) {
		this.zhima_score = zhima_score;
	}

	public List<String> getIdcard_imgs() {
		return idcard_imgs;
	}

	public void setIdcard_imgs(List<String> idcard_imgs) {
		this.idcard_imgs = idcard_imgs;
	}

	public List<String> getZhifubao_imgs() {
		return zhifubao_imgs;
	}

	public void setZhifubao_imgs(List<String> zhifubao_imgs) {
		this.zhifubao_imgs = zhifubao_imgs;
	}

	public List<String> getJiedaibao_imgs() {
		return jiedaibao_imgs;
	}

	public void setJiedaibao_imgs(List<String> jiedaibao_imgs) {
		this.jiedaibao_imgs = jiedaibao_imgs;
	}

	public String getHomeRegistAddr() {
		return homeRegistAddr;
	}

	public void setHomeRegistAddr(String homeRegistAddr) {
		this.homeRegistAddr = homeRegistAddr;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}

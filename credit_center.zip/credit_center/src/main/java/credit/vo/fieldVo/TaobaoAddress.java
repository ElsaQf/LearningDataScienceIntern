package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝地址信息
 * @author YCM
 * @date 2018年11月13日 下午4:59:08
 */

public class TaobaoAddress implements Serializable {

	@Field(type = FieldType.Text) 
	private String province;//收货省份
	
	@Field(type = FieldType.Text) 
	private String city;//收货城市
	
	@Field(type = FieldType.Text) 
	private String receiverTitle;//收货人单位/名称
	
	@Field(type = FieldType.Text) 
	private String receiverAddr;//收货人具体地址
	
	@Field(type = FieldType.Text) 
	private String receiverRegion;//收货人大致地区
	
	@Field(type = FieldType.Text) 
	private String receiverCellPhone;//收货人手机
	
	@Field(type = FieldType.Text) 
	private String zipcode;//邮编
	
	@Field(type = FieldType.Text) 
	private String paymentType;//付款方式
	
	@Field(type = FieldType.Boolean) 
	private Boolean isDefaultAddress;//是否默认地址
	
	@Field(type = FieldType.Text) 
	private String receiverName;//收货人姓名
	
	@Field(type = FieldType.Text) 
	private String receiverPhone;//收货人电话

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getReceiverTitle() {
		return receiverTitle;
	}

	public void setReceiverTitle(String receiverTitle) {
		this.receiverTitle = receiverTitle;
	}

	public String getReceiverAddr() {
		return receiverAddr;
	}

	public void setReceiverAddr(String receiverAddr) {
		this.receiverAddr = receiverAddr;
	}

	public String getReceiverRegion() {
		return receiverRegion;
	}

	public void setReceiverRegion(String receiverRegion) {
		this.receiverRegion = receiverRegion;
	}

	public String getReceiverCellPhone() {
		return receiverCellPhone;
	}

	public void setReceiverCellPhone(String receiverCellPhone) {
		this.receiverCellPhone = receiverCellPhone;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public Boolean getIsDefaultAddress() {
		return isDefaultAddress;
	}

	public void setIsDefaultAddress(Boolean isDefaultAddress) {
		this.isDefaultAddress = isDefaultAddress;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverPhone() {
		return receiverPhone;
	}

	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}
	
}

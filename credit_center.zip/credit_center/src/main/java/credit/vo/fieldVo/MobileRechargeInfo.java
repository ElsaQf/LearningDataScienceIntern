package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商充值信息
 * @author YCM
 * @date 2019年6月5日 上午10:51:01
 */
@SuppressWarnings("serial")
public class MobileRechargeInfo implements Serializable{
	
	@Field(type = FieldType.Integer)
	private Integer pay_fee; //金额 精确到分
	@Field(type = FieldType.Text, index=false)
	private String pay_channel; //缴费渠道
	@Field(type = FieldType.Text, index=false)
	private String pay_type; //缴费方式。线上充值、线下充值、现金充值、银行充值、第三方支付、其他充值、未知

	public Integer getPay_fee() {
		return pay_fee;
	}

	public void setPay_fee(Integer pay_fee) {
		this.pay_fee = pay_fee;
	}

	public String getPay_channel() {
		return pay_channel;
	}

	public void setPay_channel(String pay_channel) {
		this.pay_channel = pay_channel;
	}

	public String getPay_type() {
		return pay_type;
	}

	public void setPay_type(String pay_type) {
		this.pay_type = pay_type;
	}
	
}
package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 工作信息
 * @author yuan
 *
 */
@SuppressWarnings("serial")
public class JobInfo implements Serializable  {
	
	@Field(type = FieldType.Text)
	public String company_name;	// 公司名
	
	@Field(type = FieldType.Text)
	public String position;	// 职位
	
	@Field(type = FieldType.Integer)
	public int employment_date;	// 入职时间
	
	@Field(type = FieldType.Text)
	public String company_tel;	// 联系电话
	
	@Field(type = FieldType.Text)
	public String level_1_code;	// 省级编码
	
	@Field(type = FieldType.Text)
	public String level_1_name;	// 省级名称
	
	@Field(type = FieldType.Text)
	public String level_2_code;	// 地级编码
	
	@Field(type = FieldType.Text)
	public String level_2_name;	// 地级名称
	
	@Field(type = FieldType.Text)
	public String level_3_code;	// 县级编码
	
	@Field(type = FieldType.Text)
	public String level_3_name;	// 县级名称
	
	@Field(type = FieldType.Text)
	public String company_address;	// 公司所在地址

	@Field(type = FieldType.Text)
	public String earn_month;	// 月收入

	@Field(type = FieldType.Text)
	public List<String> company_image_list = new ArrayList<String>(); 	//	工作证明图片ID

	@Field(type = FieldType.Integer)
    private int update_time;       //创建时间 
	
	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public int getEmployment_date() {
		return employment_date;
	}

	public void setEmployment_date(int employment_date) {
		this.employment_date = employment_date;
	}

	public String getCompany_tel() {
		return company_tel;
	}

	public void setCompany_tel(String company_tel) {
		this.company_tel = company_tel;
	}

	public String getLevel_1_code() {
		return level_1_code;
	}

	public void setLevel_1_code(String level_1_code) {
		this.level_1_code = level_1_code;
	}

	public String getLevel_1_name() {
		return level_1_name;
	}

	public void setLevel_1_name(String level_1_name) {
		this.level_1_name = level_1_name;
	}

	public String getLevel_2_code() {
		return level_2_code;
	}

	public void setLevel_2_code(String level_2_code) {
		this.level_2_code = level_2_code;
	}

	public String getLevel_2_name() {
		return level_2_name;
	}

	public void setLevel_2_name(String level_2_name) {
		this.level_2_name = level_2_name;
	}

	public String getLevel_3_code() {
		return level_3_code;
	}

	public void setLevel_3_code(String level_3_code) {
		this.level_3_code = level_3_code;
	}

	public String getLevel_3_name() {
		return level_3_name;
	}

	public void setLevel_3_name(String level_3_name) {
		this.level_3_name = level_3_name;
	}

	public String getCompany_address() {
		return company_address;
	}

	public void setCompany_address(String company_address) {
		this.company_address = company_address;
	}

	public List<String> getCompany_image_list() {
		return company_image_list;
	}

	public void setCompany_image_list(List<String> company_image_list) {
		this.company_image_list = company_image_list;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public String getEarn_month() {
		return earn_month;
	}

	public void setEarn_month(String earn_month) {
		this.earn_month = earn_month;
	}
}

package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * 百融标签数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrLabelData implements Serializable {

    @Field(type = FieldType.Text)
    private String risk_level; //风险等级（level_1:中风险、 level_2:一般风险、 level_3:资信不佳、 level_4:高风险、 level_5:拒绝）
    @Field(type = FieldType.Text)
    private String risk_hit_type; //风险命中类型（取“空/0/1/2”；0：本人直接命中，1：一度关系命中，2：二度关系命中）
    @Field(type = FieldType.Text)
    private String risk_hit_count; //取“1-N”；返回命中次数
    @Field(type = FieldType.Text)
    private String risk_hit_time; //取“0-N”，单位：年；返回最近一次命中距查询时间
	public String getRisk_level() {
		return risk_level;
	}
	public void setRisk_level(String risk_level) {
		this.risk_level = risk_level;
	}
	public String getRisk_hit_type() {
		return risk_hit_type;
	}
	public void setRisk_hit_type(String risk_hit_type) {
		this.risk_hit_type = risk_hit_type;
	}
	public String getRisk_hit_count() {
		return risk_hit_count;
	}
	public void setRisk_hit_count(String risk_hit_count) {
		this.risk_hit_count = risk_hit_count;
	}
	public String getRisk_hit_time() {
		return risk_hit_time;
	}
	public void setRisk_hit_time(String risk_hit_time) {
		this.risk_hit_time = risk_hit_time;
	}
    
}

package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 	无忧借条汇总信息
 * @author YCM
 * @date 2019年7月3日 下午7:51:42
 */
public class WyjtSumData implements Serializable{
	@Field(type = FieldType.Integer) 
	private int report_status;//状态
	@Field(type = FieldType.Integer) 
	private int loan_cnt;//条数
	@Field(type = FieldType.Float) 
	private float loan_amount;//金额
	@Field(type = FieldType.Integer)
	private int partner_cnt;//人数
	
	public int getReport_status() {
		return report_status;
	}
	public void setReport_status(int report_status) {
		this.report_status = report_status;
	}
	public int getLoan_cnt() {
		return loan_cnt;
	}
	public void setLoan_cnt(int loan_cnt) {
		this.loan_cnt = loan_cnt;
	}
	public float getLoan_amount() {
		return loan_amount;
	}
	public void setLoan_amount(float loan_amount) {
		this.loan_amount = loan_amount;
	}
	public int getPartner_cnt() {
		return partner_cnt;
	}
	public void setPartner_cnt(int partner_cnt) {
		this.partner_cnt = partner_cnt;
	}
	
}

package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 百融报告数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrApplyLoanReport implements Serializable {

    @Field(type = FieldType.Text)
    private String query_dimension;//查询维度
    @Field(type = FieldType.Object)
    private List<BrApplyLoan> query_data;//查询数据
    
	public String getQuery_dimension() {
		return query_dimension;
	}
	public void setQuery_dimension(String query_dimension) {
		this.query_dimension = query_dimension;
	}
	public List<BrApplyLoan> getQuery_data() {
		return query_data;
	}
	public void setQuery_data(List<BrApplyLoan> query_data) {
		this.query_data = query_data;
	}
 
    
}

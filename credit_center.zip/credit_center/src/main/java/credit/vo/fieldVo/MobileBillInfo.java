package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 账单信息
 * @author YCM
 * @date 2019年6月5日 上午10:51:01
 */
@SuppressWarnings("serial")
public class MobileBillInfo implements Serializable{
	
	@Field(type = FieldType.Integer)
	private Integer plan_fee; // 月固定费用（分）
	@Field(type = FieldType.Integer)
	private Integer total_fee; // 账单总费用（分）
	@Field(type = FieldType.Integer)
	private Integer bill_discount; // 减免
	@Field(type = FieldType.Integer)
	private Integer actual_fee; // 实际费用 
	
	public Integer getTotal_fee() {
		return total_fee;
	}
	public void setTotal_fee(Integer total_fee) {
		this.total_fee = total_fee;
	}
	public Integer getBill_discount() {
		return bill_discount;
	}
	public void setBill_discount(Integer bill_discount) {
		this.bill_discount = bill_discount;
	}
	public Integer getActual_fee() {
		return actual_fee;
	}
	public void setActual_fee(Integer actual_fee) {
		this.actual_fee = actual_fee;
	}
	public Integer getPlan_fee() {
		return plan_fee;
	}
	public void setPlan_fee(Integer plan_fee) {
		this.plan_fee = plan_fee;
	}
	 
}
package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 移动运营商账单信息
 * Title: EBasicInfo.java 
 * @version 1.0
 */
@SuppressWarnings("serial")
public class MobileBillDetail implements Serializable {
	
	@Field(type = FieldType.Text)
	private String cell_phone;//本机号码
	@Field(type = FieldType.Text)
	private String bill_cycle;//账单月份
	@Field(type = FieldType.Integer)
	private Integer total_amt;//总费用（分）
	@Field(type = FieldType.Integer)
	private	Integer	recharge_cnt;//按月份对充值记录进行统计的次数
	@Field(type = FieldType.Integer)
	private	Integer recharge_amount;//按月份对充值记录进行统计的总金额
	@Field(type = FieldType.Integer)
	private Integer total_call_count;//通话次数,用于判断后来获取的和之前已经取到的对比
	@Field(type = FieldType.Float)
	private Float total_call_len = 0F;//通话时长
	@Field(type = FieldType.Integer)
	private	Integer	call_out_cnt;//主叫次数
	@Field(type = FieldType.Float)
	private	Float call_out_len;//主叫时间（分）
	@Field(type = FieldType.Integer)
	private	Integer	call_in_cnt;//被叫次数
	@Field(type = FieldType.Float)
	private	Float call_in_len;//被叫时间（分）
	@Field(type = FieldType.Integer)
	private	Integer	sms_cnt;//短信数量
	public String getCell_phone() {
		return cell_phone;
	}
	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}
	public String getBill_cycle() {
		return bill_cycle;
	}
	public void setBill_cycle(String bill_cycle) {
		this.bill_cycle = bill_cycle;
	}
	public Integer getTotal_amt() {
		return total_amt;
	}
	public void setTotal_amt(Integer total_amt) {
		this.total_amt = total_amt;
	}
	public Integer getRecharge_cnt() {
		return recharge_cnt;
	}
	public void setRecharge_cnt(Integer recharge_cnt) {
		this.recharge_cnt = recharge_cnt;
	}
	public Integer getRecharge_amount() {
		return recharge_amount;
	}
	public void setRecharge_amount(Integer recharge_amount) {
		this.recharge_amount = recharge_amount;
	}
	public Integer getTotal_call_count() {
		return total_call_count;
	}
	public void setTotal_call_count(Integer total_call_count) {
		this.total_call_count = total_call_count;
	}
	public Float getTotal_call_len() {
		return total_call_len;
	}
	public void setTotal_call_len(Float total_call_len) {
		this.total_call_len = total_call_len;
	}
	public Integer getCall_out_cnt() {
		return call_out_cnt;
	}
	public void setCall_out_cnt(Integer call_out_cnt) {
		this.call_out_cnt = call_out_cnt;
	}
	public Float getCall_out_len() {
		return call_out_len;
	}
	public void setCall_out_len(Float call_out_len) {
		this.call_out_len = call_out_len;
	}
	public Integer getCall_in_cnt() {
		return call_in_cnt;
	}
	public void setCall_in_cnt(Integer call_in_cnt) {
		this.call_in_cnt = call_in_cnt;
	}
	public Float getCall_in_len() {
		return call_in_len;
	}
	public void setCall_in_len(Float call_in_len) {
		this.call_in_len = call_in_len;
	}
	public Integer getSms_cnt() {
		return sms_cnt;
	}
	public void setSms_cnt(Integer sms_cnt) {
		this.sms_cnt = sms_cnt;
	}
	 
}
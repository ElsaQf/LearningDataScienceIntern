package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 网贷明细
 * @author YCM
 * @date 2019年3月11日 下午5:45:45
 */
public class NetloanData implements Serializable {

	@Field(type = FieldType.Text)
	private String query_dimension;//查询维度---手机号：mobile、身份证：pid
	
	@Field(type = FieldType.Object)
	private List<NetloanDetail> netloan_list;//网贷详情

	public String getQuery_dimension() {
		return query_dimension;
	}

	public void setQuery_dimension(String query_dimension) {
		this.query_dimension = query_dimension;
	}

	public List<NetloanDetail> getNetloan_list() {
		return netloan_list;
	}

	public void setNetloan_list(List<NetloanDetail> netloan_list) {
		this.netloan_list = netloan_list;
	}
	
}

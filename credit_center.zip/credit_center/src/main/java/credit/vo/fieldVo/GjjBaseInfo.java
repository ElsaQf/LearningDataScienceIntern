package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 公积金基本信息
 * @author zhanglle
 *
 */

public class GjjBaseInfo implements Serializable{
	@Field(type = FieldType.Text)
	private String cust_no; //客户号
	
	@Field(type = FieldType.Text)
	private String pay_status; //公积金缴存状态码。0：未缴纳，1：正常，2：停 缴，3：注销
	
	@Field(type = FieldType.Text)
	private String pay_status_desc; //公积金缴存状态。未缴纳，正常，停缴，注销
	
	@Field(type = FieldType.Text)
	private String name;            //姓名
	
	@Field(type = FieldType.Text)
	private String cert_no;         //证件号码
	
	@Field(type = FieldType.Text)
	private String cert_type;       //证件类型。1：身份证，2：护照
	
	@Field(type = FieldType.Text)
	private String home_address;    //家庭地址
	
	@Field(type = FieldType.Text)
	private String post_no;         //邮政编码
	
	@Field(type = FieldType.Text)
	private String mobile;          //手机号码
	
	@Field(type = FieldType.Text)
	private String email;           //电子邮箱
	
	@Field(type = FieldType.Text)
	private String corp_name;       //单位名称
	
	@Field(type = FieldType.Text)
	private String monthly_corp_income;  //单位缴存。单位：分
	
	@Field(type = FieldType.Text)
	private String monthly_corp_proportion; //单位缴存比例
	
	@Field(type = FieldType.Text)
	private String monthly_cust_income;     //个人缴存。单位：分
	
	@Field(type = FieldType.Text)
	private String monthly_cust_proportion; //个人缴存比例
	
	@Field(type = FieldType.Text)
	private String monthly_total_income;    //月缴额度。单位：分
	
	@Field(type = FieldType.Text)
	private String base_number;     //基数。单位：分
	
	@Field(type = FieldType.Text)
	private String balance;         //公积金余额。单位：分
	
	@Field(type = FieldType.Text)
	private String last_pay_date;   //最后缴费日期。YYYY-MM-DD
	
	@Field(type = FieldType.Text)
	private String begin_date;      //开户日期。YYYY-MM-DD
	
	@Field(type = FieldType.Text)
	private String corp_no;         //单位账号
	
	@Field(type = FieldType.Text)
	private String education;       //学历
	
	@Field(type = FieldType.Text)
	private String registed;        //户籍
	
	@Field(type = FieldType.Text)
	private String name_of_spouse;  //配偶姓名
	
	@Field(type = FieldType.Text)
	private String cert_no_of_spouse;  //配偶身份证
	
	@Field(type = FieldType.Text)
	private String marital_status;     //婚姻状态

	
	public String getCust_no() {
		return cust_no;
	}
	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}
	public String getPay_status() {
		return pay_status;
	}
	public void setPay_status(String pay_status) {
		this.pay_status = pay_status;
	}
	public String getPay_status_desc() {
		return pay_status_desc;
	}
	public void setPay_status_desc(String pay_status_desc) {
		this.pay_status_desc = pay_status_desc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCert_no() {
		return cert_no;
	}
	public void setCert_no(String cert_no) {
		this.cert_no = cert_no;
	}
	public String getCert_type() {
		return cert_type;
	}
	public void setCert_type(String cert_type) {
		this.cert_type = cert_type;
	}
	public String getHome_address() {
		return home_address;
	}
	public void setHome_address(String home_address) {
		this.home_address = home_address;
	}
	public String getPost_no() {
		return post_no;
	}
	public void setPost_no(String post_no) {
		this.post_no = post_no;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCorp_name() {
		return corp_name;
	}
	public void setCorp_name(String corp_name) {
		this.corp_name = corp_name;
	}
	public String getMonthly_corp_income() {
		return monthly_corp_income;
	}
	public void setMonthly_corp_income(String monthly_corp_income) {
		this.monthly_corp_income = monthly_corp_income;
	}
	public String getMonthly_corp_proportion() {
		return monthly_corp_proportion;
	}
	public void setMonthly_corp_proportion(String monthly_corp_proportion) {
		this.monthly_corp_proportion = monthly_corp_proportion;
	}
	public String getMonthly_cust_income() {
		return monthly_cust_income;
	}
	public void setMonthly_cust_income(String monthly_cust_income) {
		this.monthly_cust_income = monthly_cust_income;
	}
	public String getMonthly_cust_proportion() {
		return monthly_cust_proportion;
	}
	public void setMonthly_cust_proportion(String monthly_cust_proportion) {
		this.monthly_cust_proportion = monthly_cust_proportion;
	}
	public String getMonthly_total_income() {
		return monthly_total_income;
	}
	public void setMonthly_total_income(String monthly_total_income) {
		this.monthly_total_income = monthly_total_income;
	}
	public String getBase_number() {
		return base_number;
	}
	public void setBase_number(String base_number) {
		this.base_number = base_number;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getLast_pay_date() {
		return last_pay_date;
	}
	public void setLast_pay_date(String last_pay_date) {
		this.last_pay_date = last_pay_date;
	}
	public String getBegin_date() {
		return begin_date;
	}
	public void setBegin_date(String begin_date) {
		this.begin_date = begin_date;
	}
	public String getCorp_no() {
		return corp_no;
	}
	public void setCorp_no(String corp_no) {
		this.corp_no = corp_no;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getRegisted() {
		return registed;
	}
	public void setRegisted(String registed) {
		this.registed = registed;
	}
	public String getName_of_spouse() {
		return name_of_spouse;
	}
	public void setName_of_spouse(String name_of_spouse) {
		this.name_of_spouse = name_of_spouse;
	}
	public String getCert_no_of_spouse() {
		return cert_no_of_spouse;
	}
	public void setCert_no_of_spouse(String cert_no_of_spouse) {
		this.cert_no_of_spouse = cert_no_of_spouse;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	
	
	
	
	
}

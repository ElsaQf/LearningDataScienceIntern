package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 电商数据(简版和详版报告使用)
 * @author YCM
 * @date 2018年7月6日 下午7:21:15
 */
@SuppressWarnings("serial")
public class JdAnalyzeReport implements Serializable{
	/*电商数据*/
	@Field(type = FieldType.Float)
	private float ebusynessTotalAmount; // 购物总金额(收货人为自己)(-1不存在数据 >0月份)
	@Field(type = FieldType.Integer)
	private int ebusynessTotalTm; // 淘宝使用时间(收货人为自己)(-1不存在数据 购房贷款数>0月份)
	@Field(type = FieldType.Integer)
	private int ebusynessTotalCount; // 收货人包含自己名字(-1不存在数据 >0 数据条数)
	@Field(type = FieldType.Integer)
	private int telEbusynessCount; // 收货人包含自己手机号(-1不存在数据 >0 数据条数)
	
	public float getEbusynessTotalAmount() {
		return ebusynessTotalAmount;
	}

	public void setEbusynessTotalAmount(float ebusynessTotalAmount) {
		this.ebusynessTotalAmount = ebusynessTotalAmount;
	}

	public int getEbusynessTotalTm() {
		return ebusynessTotalTm;
	}

	public void setEbusynessTotalTm(int ebusynessTotalTm) {
		this.ebusynessTotalTm = ebusynessTotalTm;
	}

	public int getEbusynessTotalCount() {
		return ebusynessTotalCount;
	}

	public void setEbusynessTotalCount(int ebusynessTotalCount) {
		this.ebusynessTotalCount = ebusynessTotalCount;
	}

	public int getTelEbusynessCount() {
		return telEbusynessCount;
	}

	public void setTelEbusynessCount(int telEbusynessCount) {
		this.telEbusynessCount = telEbusynessCount;
	}
	
	
}
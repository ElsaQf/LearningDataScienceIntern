package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝订单商家信息
 * @author YCM
 * @date 2018年11月13日 下午4:59:08
 */

public class TaobaoOrderShopInfo implements Serializable {

	@Field(type = FieldType.Text) 
	private String shopId;//店铺ID
	
	@Field(type = FieldType.Text) 
	private String shopName;//店铺名称
	
	@Field(type = FieldType.Text) 
	private String shopUrl;//店铺链接
	
	@Field(type = FieldType.Text) 
	private String nick;//店铺昵称
	
	@Field(type = FieldType.Text) 
	private String imgUrl;//店铺图片链接

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopUrl() {
		return shopUrl;
	}

	public void setShopUrl(String shopUrl) {
		this.shopUrl = shopUrl;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
}

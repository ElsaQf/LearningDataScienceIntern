package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * 公积金缴存记录
 * @author YCM
 * @date 2019年6月26日 上午10:27:00
 */
public class GjjUserInfo implements Serializable {

    @Field(type = FieldType.Text, index=false)
    private String name;//姓名
    @Field(type = FieldType.Integer)
    private Integer gender;//性别 男1女0
    @Field(type = FieldType.Text, index=false)
    private String birthday;//出生日期
    @Field(type = FieldType.Text, index=false)
    private String mobile;//手机号
    @Field(type = FieldType.Text, index=false)
    private String home_address;//家庭住址
    @Field(type = FieldType.Text, index=false)
    private String card_number;//证件号(身份证号，护照号)
    @Field(type = FieldType.Text, index=false)
    private String card_type;//证件类型(idCard, passport)
    @Field(type = FieldType.Text, index=false)
    private String city;//城市名称
    @Field(type = FieldType.Text, index=false)
    private String person_number;//客户号
    @Field(type = FieldType.Text, index=false)
    private String gjj_number;//公积金资金账号
    @Field(type = FieldType.Integer)
    private Integer account_type;//账户类型(1、普通账号 2、补充账号)
    @Field(type = FieldType.Float)
    private Float balance;//包含公积金余额跟补贴余额
    @Field(type = FieldType.Float)
    private Float gjj_balance;//公积金余额
    @Field(type = FieldType.Float)
    private Float subsidy_balance;//补贴公积金余额
    @Field(type = FieldType.Text, index=false)
    private String corp_name;//当前缴存企业名称
    @Field(type = FieldType.Float)
    private Float monthly_corp_income;//企业月度缴存
    @Field(type = FieldType.Float)
    private Float monthly_person_income;//个人月度缴存
    @Field(type = FieldType.Float)
    private Float subsidy_income;//补贴月缴存
    @Field(type = FieldType.Float)
    private Float monthly_total_income;//月度总缴存
    @Field(type = FieldType.Float)
    private Float corp_rat;//企业缴存比例
    @Field(type = FieldType.Float)
    private Float person_rat;//个人缴存比例
    @Field(type = FieldType.Float)
    private Float subsidy_corp_rat;//补贴公积金公司缴存比例
    @Field(type = FieldType.Float)
    private Float subsidy_person_rat;//补贴公积金个人缴存比例
    @Field(type = FieldType.Float)
    private Float base_number;//缴存基数
    @Field(type = FieldType.Text, index=false)
    private String begin_date;//开户日期
    @Field(type = FieldType.Text, index=false)
    private String last_bill_date;//最近一次缴存日期
    @Field(type = FieldType.Text, index=false)
    private String status;//账号状态
    @Field(type = FieldType.Integer)
    private Integer has_supply;//是否有补充公积金账号 1是0否
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getHome_address() {
		return home_address;
	}
	public void setHome_address(String home_address) {
		this.home_address = home_address;
	}
	public String getCard_number() {
		return card_number;
	}
	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	public String getCard_type() {
		return card_type;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPerson_number() {
		return person_number;
	}
	public void setPerson_number(String person_number) {
		this.person_number = person_number;
	}
	public String getGjj_number() {
		return gjj_number;
	}
	public void setGjj_number(String gjj_number) {
		this.gjj_number = gjj_number;
	}
	public Integer getAccount_type() {
		return account_type;
	}
	public void setAccount_type(Integer account_type) {
		this.account_type = account_type;
	}
	public Float getBalance() {
		return balance;
	}
	public void setBalance(Float balance) {
		this.balance = balance;
	}
	public Float getGjj_balance() {
		return gjj_balance;
	}
	public void setGjj_balance(Float gjj_balance) {
		this.gjj_balance = gjj_balance;
	}
	public Float getSubsidy_balance() {
		return subsidy_balance;
	}
	public void setSubsidy_balance(Float subsidy_balance) {
		this.subsidy_balance = subsidy_balance;
	}
	public String getCorp_name() {
		return corp_name;
	}
	public void setCorp_name(String corp_name) {
		this.corp_name = corp_name;
	}
	public Float getMonthly_corp_income() {
		return monthly_corp_income;
	}
	public void setMonthly_corp_income(Float monthly_corp_income) {
		this.monthly_corp_income = monthly_corp_income;
	}
	public Float getMonthly_person_income() {
		return monthly_person_income;
	}
	public void setMonthly_person_income(Float monthly_person_income) {
		this.monthly_person_income = monthly_person_income;
	}
	public Float getSubsidy_income() {
		return subsidy_income;
	}
	public void setSubsidy_income(Float subsidy_income) {
		this.subsidy_income = subsidy_income;
	}
	public Float getMonthly_total_income() {
		return monthly_total_income;
	}
	public void setMonthly_total_income(Float monthly_total_income) {
		this.monthly_total_income = monthly_total_income;
	}
	public Float getCorp_rat() {
		return corp_rat;
	}
	public void setCorp_rat(Float corp_rat) {
		this.corp_rat = corp_rat;
	}
	public Float getPerson_rat() {
		return person_rat;
	}
	public void setPerson_rat(Float person_rat) {
		this.person_rat = person_rat;
	}
	public Float getSubsidy_corp_rat() {
		return subsidy_corp_rat;
	}
	public void setSubsidy_corp_rat(Float subsidy_corp_rat) {
		this.subsidy_corp_rat = subsidy_corp_rat;
	}
	public Float getSubsidy_person_rat() {
		return subsidy_person_rat;
	}
	public void setSubsidy_person_rat(Float subsidy_person_rat) {
		this.subsidy_person_rat = subsidy_person_rat;
	}
	public Float getBase_number() {
		return base_number;
	}
	public void setBase_number(Float base_number) {
		this.base_number = base_number;
	}
	public String getBegin_date() {
		return begin_date;
	}
	public void setBegin_date(String begin_date) {
		this.begin_date = begin_date;
	}
	public String getLast_bill_date() {
		return last_bill_date;
	}
	public void setLast_bill_date(String last_bill_date) {
		this.last_bill_date = last_bill_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getHas_supply() {
		return has_supply;
	}
	public void setHas_supply(Integer has_supply) {
		this.has_supply = has_supply;
	}
}

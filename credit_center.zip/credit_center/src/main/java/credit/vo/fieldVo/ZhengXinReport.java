package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 征信数据(简版和详版报告使用)
 * @author YCM
 * @date 2018年7月6日 下午7:21:15
 */
@SuppressWarnings("serial")
public class ZhengXinReport implements Serializable{
	/*征信数据*/
	@Field(type = FieldType.Integer)
    private int courtAccept = -1; // 是否在法院的黑名单中(-1不存在数据 0.不在1.在)
	@Field(type = FieldType.Integer)
	private int tongdunAccept;//同盾是否通过(-1不存在数据 0.不通过 1.通过)
	@Field(type = FieldType.Integer)
	private int nameEqualsZhengxin; // 手工输入的名字是否与征信一致(-1不存在数据 0.不通过 1.通过)
	@Field(type = FieldType.Integer)
	private int zhengxinOverudeCounts_90day; // 人行征信≥90天逾期记录的条数(-1不存在数据 >0 数据条数)
	@Field(type = FieldType.Integer)
	private int nameEqualsXueXin; // 手工输入的名字是否与学信一致(-1不存在数据 0.不通过 1.通过)
	@Field(type = FieldType.Integer)
	private int idcardEqualsXueXin; // 手工输入的身份证号是否与学信一致(-1不存在数据 0.不通过 1.通过)
	@Field(type = FieldType.Integer)
	private int zhengxinAccountCount; // 人行征信信用卡账户数(-1不存在数据 >0 数据条数),
	@Field(type = FieldType.Integer)
	private int zhengxinHouseCount; // 人行征信购房贷款数 (-1不存在数据 >0 数据条数),
	@Field(type = FieldType.Integer)
	private int zhengxinOtherCount; // 人行征信其它贷款数 (-1不存在数据 >0 数据条数),
	@Field(type = FieldType.Integer)
	private int zhengxinOverdueCount; // 人行征信逾期总次数 (-1不存在数据 >0 数据条数),

	@Field(type = FieldType.Text)
	public List<String> watchListDetails = new ArrayList<>();//记录在不同行业的不良记录
	
	@Field(type = FieldType.Text)
	public String antifraudScore;//欺诈风险评级
	
	@Field(type = FieldType.Text)
	public List<String> antifraudVerify = new ArrayList<>();//用户资料真实性验证
	
	@Field(type = FieldType.Text)
	public List<String> antifraudRisk = new ArrayList<>();
	
	public int getCourtAccept() {
		return courtAccept;
	}

	public void setCourtAccept(int courtAccept) {
		this.courtAccept = courtAccept;
	}

	public int getNameEqualsZhengxin() {
		return nameEqualsZhengxin;
	}

	public void setNameEqualsZhengxin(int nameEqualsZhengxin) {
		this.nameEqualsZhengxin = nameEqualsZhengxin;
	}

	public int getZhengxinOverudeCounts_90day() {
		return zhengxinOverudeCounts_90day;
	}

	public void setZhengxinOverudeCounts_90day(int zhengxinOverudeCounts_90day) {
		this.zhengxinOverudeCounts_90day = zhengxinOverudeCounts_90day;
	}

	public int getNameEqualsXueXin() {
		return nameEqualsXueXin;
	}

	public void setNameEqualsXueXin(int nameEqualsXueXin) {
		this.nameEqualsXueXin = nameEqualsXueXin;
	}

	public int getIdcardEqualsXueXin() {
		return idcardEqualsXueXin;
	}

	public void setIdcardEqualsXueXin(int idcardEqualsXueXin) {
		this.idcardEqualsXueXin = idcardEqualsXueXin;
	}

	public List<String> getWatchListDetails() {
		return watchListDetails;
	}

	public void setWatchListDetails(List<String> watchListDetails) {
		this.watchListDetails = watchListDetails;
	}

	public String getAntifraudScore() {
		return antifraudScore;
	}

	public void setAntifraudScore(String antifraudScore) {
		this.antifraudScore = antifraudScore;
	}

	public List<String> getAntifraudVerify() {
		return antifraudVerify;
	}

	public void setAntifraudVerify(List<String> antifraudVerify) {
		this.antifraudVerify = antifraudVerify;
	}

	public List<String> getAntifraudRisk() {
		return antifraudRisk;
	}

	public void setAntifraudRisk(List<String> antifraudRisk) {
		this.antifraudRisk = antifraudRisk;
	}

	public int getTongdunAccept() {
		return tongdunAccept;
	}

	public void setTongdunAccept(int tongdunAccept) {
		this.tongdunAccept = tongdunAccept;
	}

	public int getZhengxinAccountCount() {
		return zhengxinAccountCount;
	}

	public void setZhengxinAccountCount(int zhengxinAccountCount) {
		this.zhengxinAccountCount = zhengxinAccountCount;
	}

	public int getZhengxinHouseCount() {
		return zhengxinHouseCount;
	}

	public void setZhengxinHouseCount(int zhengxinHouseCount) {
		this.zhengxinHouseCount = zhengxinHouseCount;
	}

	public int getZhengxinOtherCount() {
		return zhengxinOtherCount;
	}

	public void setZhengxinOtherCount(int zhengxinOtherCount) {
		this.zhengxinOtherCount = zhengxinOtherCount;
	}

	public int getZhengxinOverdueCount() {
		return zhengxinOverdueCount;
	}

	public void setZhengxinOverdueCount(int zhengxinOverdueCount) {
		this.zhengxinOverdueCount = zhengxinOverdueCount;
	}
	 
}
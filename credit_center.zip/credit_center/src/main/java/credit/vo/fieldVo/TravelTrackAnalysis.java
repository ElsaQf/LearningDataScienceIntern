package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
    * 运营商通话漫游记录
 * @author YCM
 * @date 2019年7月1日 下午6:16:23
 */
@SuppressWarnings("serial")
public class TravelTrackAnalysis implements Serializable {
	@Field(type = FieldType.Text, index = false)
	private	String leave_city;//出发地
	@Field(type = FieldType.Text, index = false)
	private	String leave_day;//出行开始时间
	@Field(type = FieldType.Text, index = false)
	private	String leave_day_type;//出行时间类型
	@Field(type = FieldType.Text, index = false)
	private	String arrive_city;//目的地
	@Field(type = FieldType.Text, index = false)
	private	String arrive_day;//出行结束时间
	public String getLeave_city() {
		return leave_city;
	}
	public void setLeave_city(String leave_city) {
		this.leave_city = leave_city;
	}
	public String getLeave_day() {
		return leave_day;
	}
	public void setLeave_day(String leave_day) {
		this.leave_day = leave_day;
	}
	public String getLeave_day_type() {
		return leave_day_type;
	}
	public void setLeave_day_type(String leave_day_type) {
		this.leave_day_type = leave_day_type;
	}
	public String getArrive_city() {
		return arrive_city;
	}
	public void setArrive_city(String arrive_city) {
		this.arrive_city = arrive_city;
	}
	public String getArrive_day() {
		return arrive_day;
	}
	public void setArrive_day(String arrive_day) {
		this.arrive_day = arrive_day;
	}
}

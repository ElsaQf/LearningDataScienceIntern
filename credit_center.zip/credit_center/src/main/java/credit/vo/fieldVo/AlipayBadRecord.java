package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-11-30
 **/
public class AlipayBadRecord implements Serializable {

    @Field(type = FieldType.Text)
    private String bad_credit_reason; // 负面记录原因

    @Field(type = FieldType.Text)
    private String bad_credit_handle; // 负面记录状态

    @Field(type = FieldType.Text)
    private String bad_credit_name; // 负面记录来源

    public String getBad_credit_reason() {
        return bad_credit_reason;
    }

    public void setBad_credit_reason(String bad_credit_reason) {
        this.bad_credit_reason = bad_credit_reason;
    }

    public String getBad_credit_handle() {
        return bad_credit_handle;
    }

    public void setBad_credit_handle(String bad_credit_handle) {
        this.bad_credit_handle = bad_credit_handle;
    }

    public String getBad_credit_name() {
        return bad_credit_name;
    }

    public void setBad_credit_name(String bad_credit_name) {
        this.bad_credit_name = bad_credit_name;
    }
}

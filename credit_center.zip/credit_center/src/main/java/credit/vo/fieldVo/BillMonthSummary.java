package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 收货地址月度汇总
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class BillMonthSummary implements Serializable {
	@Field(type = FieldType.Text)
	private String bill_month;//月份
	@Field(type = FieldType.Integer) 
	private	int income_amount;//收入
	@Field(type = FieldType.Integer) 
	private int pay_amount;//支出
	@Field(type = FieldType.Integer) 
	private int refund_amount;//退款
	@Field(type = FieldType.Integer) 
	private int success_count;//成功次数
	public String getBill_month() {
		return bill_month;
	}
	public void setBill_month(String bill_month) {
		this.bill_month = bill_month;
	}
	public int getIncome_amount() {
		return income_amount;
	}
	public void setIncome_amount(int income_amount) {
		this.income_amount = income_amount;
	}
	public int getPay_amount() {
		return pay_amount;
	}
	public void setPay_amount(int pay_amount) {
		this.pay_amount = pay_amount;
	}
	public int getRefund_amount() {
		return refund_amount;
	}
	public void setRefund_amount(int refund_amount) {
		this.refund_amount = refund_amount;
	}
	public int getSuccess_count() {
		return success_count;
	}
	public void setSuccess_count(int success_count) {
		this.success_count = success_count;
	}
	
}

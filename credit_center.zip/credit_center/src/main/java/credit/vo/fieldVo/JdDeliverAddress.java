package credit.vo.fieldVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import credit.vo.parmVo.EbusinessReceiver;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-5.
 * Description:   (报告)电商地址分析
 *******************************************************************************/

public class JdDeliverAddress implements Serializable, Comparable<JdDeliverAddress> {

    public static final long serialVersionUID = 3793643435778264829L;


    public String address;// 收货地址

    public Float lng;// 经度

    public String lat;// 纬度

    public String predict_addr_type;// 地址类型

    public String begin_date;// 开始送货时间

    public String end_date;// 结束送货时间

    public Float total_amount;// 总送货金额

    public Integer total_count;// 总送货次数

    public Date t_begin_date;// 开始送货时间

    public Date t_end_date;// 结束送货时间

    public List<EbusinessReceiver> ebusiness_receiver_list = new ArrayList<>(); // 收货人列表


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Float getLng() {
        return lng;
    }

    public void setLng(Float lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getPredict_addr_type() {
        return predict_addr_type;
    }

    public void setPredict_addr_type(String predict_addr_type) {
        this.predict_addr_type = predict_addr_type;
    }

    public String getBegin_date() {
        return begin_date;
    }

    public void setBegin_date(String begin_date) {
        this.begin_date = begin_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public Float getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(Float total_amount) {
        this.total_amount = total_amount;
    }

    public Integer getTotal_count() {
        return total_count;
    }

    public void setTotal_count(Integer total_count) {
        this.total_count = total_count;
    }

//    public List<EbusinessReceiver> getReceiver() {
//        return ebusiness_receiver_list;
//    }


    public List<EbusinessReceiver> getEbusiness_receiver_list() {
        return ebusiness_receiver_list;
    }

    public void setEbusiness_receiver_list(List<EbusinessReceiver> ebusiness_receiver_list) {
        this.ebusiness_receiver_list = ebusiness_receiver_list;
    }

//    public void setReceiver(List<EbusinessReceiver> ebusiness_receiver_list) {
//        this.ebusiness_receiver_list = ebusiness_receiver_list;
//    }

    public Date getT_begin_date() {
        return t_begin_date;
    }

    public void setT_begin_date(Date t_begin_date) {
        this.t_begin_date = t_begin_date;
    }

    public Date getT_end_date() {
        return t_end_date;
    }

    public void setT_end_date(Date t_end_date) {
        this.t_end_date = t_end_date;
    }

    @Override
    public int compareTo(JdDeliverAddress o) {

        if (this.t_end_date.before(o.t_end_date)) {
            return 1;
        } else {
            return -1;
        }
    }
}

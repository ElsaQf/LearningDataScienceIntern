package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public class AlipayBalanceData implements Serializable {

    @Field(type = FieldType.Text)
    private String yuebaoBaleance; //余额宝余额
    
    @Field(type = FieldType.Text)
    private String ye; //支付宝余额

    @Field(type = FieldType.Text)
    private String jijin; // 基金

    @Field(type = FieldType.Text)
    private String dingqi; // 定期理财

    @Field(type = FieldType.Text)
    private String allBalance; // 总资产

    @Field(type = FieldType.Text)
    private String risk_test; // 风险类型
    
    @Field(type = FieldType.Text)
    private String huangjin; // 黄金
    
    @Field(type = FieldType.Integer)
    private Integer balancePaymentEnable; //支付宝余额支付开关 1是0否
    
    @Field(type = FieldType.Double)
    private Double yuebaoIncome; //余额宝累计收益

    
    public String getHuangjin() {
        return huangjin;
    }

    public void setHuangjin(String huangjin) {
        this.huangjin = huangjin;
    }

    public String getYuebaoBaleance() {
        return yuebaoBaleance;
    }

    public void setYuebaoBaleance(String yuebaoBaleance) {
        this.yuebaoBaleance = yuebaoBaleance;
    }

    public String getJijin() {
        return jijin;
    }

    public void setJijin(String jijin) {
        this.jijin = jijin;
    }

    public String getDingqi() {
        return dingqi;
    }

    public void setDingqi(String dingqi) {
        this.dingqi = dingqi;
    }

    public String getAllBalance() {
        return allBalance;
    }

    public void setAllBalance(String allBalance) {
        this.allBalance = allBalance;
    }

    public String getRisk_test() {
        return risk_test;
    }

    public void setRisk_test(String risk_test) {
        this.risk_test = risk_test;
    }

    public String getYe() {
        return ye;
    }

    public void setYe(String ye) {
        this.ye = ye;
    }

	public Integer getBalancePaymentEnable() {
		return balancePaymentEnable;
	}

	public void setBalancePaymentEnable(Integer balancePaymentEnable) {
		this.balancePaymentEnable = balancePaymentEnable;
	}

	public Double getYuebaoIncome() {
		return yuebaoIncome;
	}

	public void setYuebaoIncome(Double yuebaoIncome) {
		this.yuebaoIncome = yuebaoIncome;
	}
    
}

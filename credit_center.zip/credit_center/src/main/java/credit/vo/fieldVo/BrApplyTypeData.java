package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 百融标签数据
 * @author YCM
 * @date 2019年3月29日 下午3:45:45
 */
public class BrApplyTypeData implements Serializable {

    @Field(type = FieldType.Text)
    private String apply_type;//申请类型
    @Field(type = FieldType.Object)
    private BrApplyData detail_data;//标签数据
	public String getApply_type() {
		return apply_type;
	}
	public void setApply_type(String apply_type) {
		this.apply_type = apply_type;
	}
	public BrApplyData getDetail_data() {
		return detail_data;
	}
	public void setDetail_data(BrApplyData detail_data) {
		this.detail_data = detail_data;
	}
}

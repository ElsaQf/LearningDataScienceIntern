package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 黑名单明细
 * @author YCM
 * @date 2019年3月11日 下午5:45:45
 */
public class BlacklistDetail implements Serializable {

	@Field(type = FieldType.Text)
	private String query_dimension;//统计维度---手机号：mobile、身份证：pid
	
	@Field(type = FieldType.Text)
	private String black_level;//黑名单类型
	
	@Field(type = FieldType.Integer)
	private int last6month_tenant_count;//最近6个月确认为黑名单的机构数
	
	@Field(type = FieldType.Integer)
	private int last6month_query_count;//最近6个月申请查询数
	
	@Field(type = FieldType.Integer)
	private int last_confirm_atdays;//最新入库距离天数(如没有记录，则为：-1)
	
	@Field(type = FieldType.Text)
	private String last_confirm_status;//最新欺诈／逾期状态(欺诈／逾期状态标签。如没有记录，则为"")
	
	@Field(type = FieldType.Text)
	private String last12month_max_confirm_status;//最近12个月最严重的欺诈／逾期状态(欺诈／逾期状态标签。欺诈／逾期状态标签定义见下表。如没有记录，则为"")

	public String getQuery_dimension() {
		return query_dimension;
	}

	public void setQuery_dimension(String query_dimension) {
		this.query_dimension = query_dimension;
	}

	public String getBlack_level() {
		return black_level;
	}

	public void setBlack_level(String black_level) {
		this.black_level = black_level;
	}

	public int getLast6month_tenant_count() {
		return last6month_tenant_count;
	}

	public void setLast6month_tenant_count(int last6month_tenant_count) {
		this.last6month_tenant_count = last6month_tenant_count;
	}

	public int getLast6month_query_count() {
		return last6month_query_count;
	}

	public void setLast6month_query_count(int last6month_query_count) {
		this.last6month_query_count = last6month_query_count;
	}

	public int getLast_confirm_atdays() {
		return last_confirm_atdays;
	}

	public void setLast_confirm_atdays(int last_confirm_atdays) {
		this.last_confirm_atdays = last_confirm_atdays;
	}

	public String getLast_confirm_status() {
		return last_confirm_status;
	}

	public void setLast_confirm_status(String last_confirm_status) {
		this.last_confirm_status = last_confirm_status;
	}

	public String getLast12month_max_confirm_status() {
		return last12month_max_confirm_status;
	}

	public void setLast12month_max_confirm_status(String last12month_max_confirm_status) {
		this.last12month_max_confirm_status = last12month_max_confirm_status;
	}

}

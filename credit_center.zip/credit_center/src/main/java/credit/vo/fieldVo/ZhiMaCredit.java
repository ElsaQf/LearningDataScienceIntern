package credit.vo.fieldVo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ZhiMaCredit implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	public String zhima_open_id;	// 芝麻信用openId
	public String zhima_score;	// 芝麻分数
	public String is_matched;
	public List<String> watchListDetails = new ArrayList<>();
	public String antifraudScore;
	public List<String> antifraudVerify = new ArrayList<>();
	public List<String> antifraudRisk = new ArrayList<>();
	
	/*芝麻信用评级 ： 5.信用极好，互联网信用分 700 到 950 之间  
	 *         4.信用优秀，互联网信用分 650 到 699 之间
	 *         3.信用良好，互联网信用分 600 到 649 之间
	 *         2.信用中等，互联网信用分 550 到 599 之间
	 *         1.信用较差，互联网信用分 350 到 549 之间
	 *         0.无法评估, 有可能是没互联网信用或姓名与身份证不对应
	 *        -1.评级失败         
	 **/
	public String zhima_rank;//天创运营商返回的芝麻等级
	public int zhima_rank_upd_tm; //芝麻等级更新时间
	
	public String getZhima_open_id() {
		return zhima_open_id;
	}
	public void setZhima_open_id(String zhima_open_id) {
		this.zhima_open_id = zhima_open_id;
	}
	public String getZhima_score() {
		return zhima_score;
	}
	public void setZhima_score(String zhima_score) {
		this.zhima_score = zhima_score;
	}
	public String getIs_matched() {
		return is_matched;
	}
	public void setIs_matched(String is_matched) {
		this.is_matched = is_matched;
	}
	public List<String> getWatchListDetails() {
		return watchListDetails;
	}
	public void setWatchListDetails(List<String> watchListDetails) {
		this.watchListDetails = watchListDetails;
	}
	public String getAntifraudScore() {
		return antifraudScore;
	}
	public void setAntifraudScore(String antifraudScore) {
		this.antifraudScore = antifraudScore;
	}
	public List<String> getAntifraudVerify() {
		return antifraudVerify;
	}
	public void setAntifraudVerify(List<String> antifraudVerify) {
		this.antifraudVerify = antifraudVerify;
	}
	public List<String> getAntifraudRisk() {
		return antifraudRisk;
	}
	public void setAntifraudRisk(List<String> antifraudRisk) {
		this.antifraudRisk = antifraudRisk;
	}
	public String getZhima_rank() {
		return zhima_rank;
	}
	public void setZhima_rank(String zhima_rank) {
		this.zhima_rank = zhima_rank;
	}
	public int getZhima_rank_upd_tm() {
		return zhima_rank_upd_tm;
	}
	public void setZhima_rank_upd_tm(int zhima_rank_upd_tm) {
		this.zhima_rank_upd_tm = zhima_rank_upd_tm;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
 
}	

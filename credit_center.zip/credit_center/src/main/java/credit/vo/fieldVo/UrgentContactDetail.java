package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
 
/**
 * 紧急联系人详细分析
 * @author YCM
 * @date 2018年7月11日 上午11:46:10
 */
@SuppressWarnings("serial")
public class UrgentContactDetail implements Serializable{
	
	@Field(type = FieldType.Text)
	private String contact_tel;	// 联系人电话
	
	@Field(type = FieldType.Text)
	private String contact_name;// 联系人姓名
	
	@Field(type = FieldType.Text)
	private String contact_type;// 联系人类型（"0":配偶，"1":父母，"2":兄弟姐妹,"3":子女,"4":同事,"5": 同学,"6": 朋友）;字符串类型非int 
	
	@Field(type = FieldType.Integer)
	private Integer call_cnt; 	// 半年内联系次数
	
	@Field(type = FieldType.Float)
	private Float call_len;// 半年内通话时长
	
	@Field(type = FieldType.Integer)
	private Integer sms_cnt; 	// 半年内短信数量	
	
	@Field(type = FieldType.Integer)
	private Integer call_cnt_3month; // 3个月通话次数
	
	@Field(type = FieldType.Float)
	private Float call_len_3month; // 3个月通话时长
	
	@Field(type = FieldType.Integer)
	private Integer sms_cnt_3month; //3个月短信次数
	
	@Field(type = FieldType.Text)
	private String begin_date; 	// 最早出现时间
	
	@Field(type = FieldType.Text)
	private String end_date; 	// 最晚出现时间
	
	@Field(type = FieldType.Integer)
	private Integer total_count; // 电商送货总数
	
	@Field(type = FieldType.Float)
	private Float total_amount; // 电商送货总金额

	public String getContact_tel() {
		return contact_tel;
	}

	public void setContact_tel(String contact_tel) {
		this.contact_tel = contact_tel;
	}

	public String getContact_name() {
		return contact_name;
	}

	public void setContact_name(String contact_name) {
		this.contact_name = contact_name;
	}

	public String getContact_type() {
		return contact_type;
	}

	public void setContact_type(String contact_type) {
		this.contact_type = contact_type;
	}

	public Integer getCall_cnt() {
		return call_cnt;
	}

	public void setCall_cnt(Integer call_cnt) {
		this.call_cnt = call_cnt;
	}

	public Float getCall_len() {
		return call_len;
	}

	public void setCall_len(Float call_len) {
		this.call_len = call_len;
	}

	public Integer getSms_cnt() {
		return sms_cnt;
	}

	public void setSms_cnt(Integer sms_cnt) {
		this.sms_cnt = sms_cnt;
	}

	public Integer getCall_cnt_3month() {
		return call_cnt_3month;
	}

	public void setCall_cnt_3month(Integer call_cnt_3month) {
		this.call_cnt_3month = call_cnt_3month;
	}

	public Float getCall_len_3month() {
		return call_len_3month;
	}

	public void setCall_len_3month(Float call_len_3month) {
		this.call_len_3month = call_len_3month;
	}

	public Integer getSms_cnt_3month() {
		return sms_cnt_3month;
	}

	public void setSms_cnt_3month(Integer sms_cnt_3month) {
		this.sms_cnt_3month = sms_cnt_3month;
	}

	public String getBegin_date() {
		return begin_date;
	}

	public void setBegin_date(String begin_date) {
		this.begin_date = begin_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public Integer getTotal_count() {
		return total_count;
	}

	public void setTotal_count(Integer total_count) {
		this.total_count = total_count;
	}

	public Float getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(Float total_amount) {
		this.total_amount = total_amount;
	}
}

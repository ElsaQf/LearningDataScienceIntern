package credit.vo.fieldVo;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 社保用户信息信息
 * @author zhanglle
 *
 */
public class SbUserInfo implements Serializable{

	@Field(type = FieldType.Text, index=false) 
	private String name ;           //姓名
	@Field(type = FieldType.Text, index=false)
	private String nation ;         //民族
	@Field(type = FieldType.Text, index=false)
	private String gender ;         //性别
	@Field(type = FieldType.Text, index=false)
	private String hukou_type ;     //户口性质
	@Field(type = FieldType.Text, index=false)
	private String certificate_number ; //身份证
	@Field(type = FieldType.Text, index=false)
	private String home_address ;    //家庭住址
	@Field(type = FieldType.Text, index=false)
	private String company_name ;    //单位名称
	@Field(type = FieldType.Text, index=false)
	private String mobile ;          //手机号码
	@Field(type = FieldType.Text, index=false)
	private String begin_date="" ;//起缴日YYYY-MM-DD
	@Field(type = FieldType.Text, index=false)
	private String end_date;      //最近缴费日期	YYYY-MM-DD
	@Field(type = FieldType.Text, index=false)
	private String time_to_work ;    //参加工作日期YYYY-MM-DD
	@Field(type = FieldType.Text, index=false)
	private String status ;    //社保状态 0未知 1正常参保 2停止参保
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getHukou_type() {
		return hukou_type;
	}
	public void setHukou_type(String hukou_type) {
		this.hukou_type = hukou_type;
	}
	public String getCertificate_number() {
		return certificate_number;
	}
	public void setCertificate_number(String certificate_number) {
		this.certificate_number = certificate_number;
	}
	public String getHome_address() {
		return home_address;
	}
	public void setHome_address(String home_address) {
		this.home_address = home_address;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		if(StringUtils.isBlank(company_name)){
			this.company_name = "--";
		}else{
			this.company_name = company_name;
		}
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getBegin_date() {
		return begin_date;
	}
	public void setBegin_date(String begin_date) {
		this.begin_date = begin_date;
	}
	public String getTime_to_work() {
		return time_to_work;
	}
	public void setTime_to_work(String time_to_work) {
		this.time_to_work = time_to_work;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
}

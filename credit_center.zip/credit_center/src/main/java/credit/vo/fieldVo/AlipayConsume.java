package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 支付宝消费信息
 * @author zhanglle
 *
 */
public class AlipayConsume implements Serializable{
	
	@Field(type = FieldType.Text) 
	private String name;//对方名称
	
	@Field(type = FieldType.Text) 
	private String amount;//交易金额
	
	@Field(type = FieldType.Text) 
	private String time;//交易时间
	
	@Field(type = FieldType.Text) 
	private String type;//交易类型
	
	@Field(type = FieldType.Text) 
	private String status;//状态
	
	@Field(type = FieldType.Text) 
	private String payment;//付款方式
	
	@Field(type = FieldType.Text) 
	private String desc;//备注描述信息

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}

package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 淘宝订单货物信息
 * @author YCM
 * @date 2018年11月13日 下午4:59:08
 */

public class TaobaoOrderItem implements Serializable {

	@Field(type = FieldType.Text) 
	private String productId;//物品ID、物品编号
	
	@Field(type = FieldType.Text) 
	private String transTime;//物品交易时间
	
	@Field(type = FieldType.Text) 
	private String productPrice;//物品交易单价
	
	@Field(type = FieldType.Integer) 
	private Integer productCnt;//物品交易数量
	
	@Field(type = FieldType.Text) 
	private String productName;//物品名称

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public Integer getProductCnt() {
		return productCnt;
	}

	public void setProductCnt(Integer productCnt) {
		this.productCnt = productCnt;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}

package credit.vo.fieldVo;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-6.
 * Description:  学信信息
 *******************************************************************************/

public class ChsiReportInfo implements Serializable {

    private static final long serialVersionUID = -7108347093060710526L;

    private String c_enter_img;// 入学照片

    private String name;// 姓名

    private String idCardNo; // 身份证号

    private String c_graduate_img;// 毕业照片

    private String c_university;// 学校

    private String c_major;// 专业

    private String c_student_begin_time;// 入学时间

    private String c_student_end_time;// 入学时间

    private String c_student_level;// 学历

    private String c_student_status;// 学生状态

    private String c_full_time;// 全日制

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getC_enter_img() {
        return c_enter_img;
    }

    public void setC_enter_img(String c_enter_img) {
        this.c_enter_img = c_enter_img;
    }

    public String getC_graduate_img() {
        return c_graduate_img;
    }

    public void setC_graduate_img(String c_graduate_img) {
        this.c_graduate_img = c_graduate_img;
    }

    public String getC_university() {
        return c_university;
    }

    public void setC_university(String c_university) {
        this.c_university = c_university;
    }

    public String getC_major() {
        return c_major;
    }

    public void setC_major(String c_major) {
        this.c_major = c_major;
    }

    public String getC_student_begin_time() {
        return c_student_begin_time;
    }

    public void setC_student_begin_time(String c_student_begin_time) {
        this.c_student_begin_time = c_student_begin_time;
    }

    public String getC_student_end_time() {
        return c_student_end_time;
    }

    public void setC_student_end_time(String c_student_end_time) {
        this.c_student_end_time = c_student_end_time;
    }

    public String getC_student_level() {
        return c_student_level;
    }

    public void setC_student_level(String c_student_level) {
        this.c_student_level = c_student_level;
    }

    public String getC_student_status() {
        return c_student_status;
    }

    public void setC_student_status(String c_student_status) {
        this.c_student_status = c_student_status;
    }

    public String getC_full_time() {
        return c_full_time;
    }

    public void setC_full_time(String c_full_time) {
        this.c_full_time = c_full_time;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdCardNo() {
		return idCardNo;
	}

	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
}
package credit.vo.fieldVo;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商基础信息表 改为MobileUserInfo索引，这个只有今借到用
 * @author YCM
 *
 */
@SuppressWarnings("serial")
public class MobileBasicInfo implements Serializable  {
	
	@Field(type = FieldType.Text)
    private String level_1_code;  	// 省级编码
	
	@Field(type = FieldType.Text)
	private String cell_phone; // 本机号码
	
	@Field(type = FieldType.Text)
	private String idcard; // 登记身份证号
	
	@Field(type = FieldType.Text)
	private String reg_time; // 入网时间
	
	@Field(type = FieldType.Text)
	private String real_name; // 登记姓名
	
	@Field(type = FieldType.Integer)
	private Integer mobile_balance; // 账户余额
	
	@Field(type = FieldType.Text)
	private String mobile_status; //账户状态。正常、欠费、停机、销户、未激活、未知
	
	@Field(type = FieldType.Text)
	private String real_info; //实名制信息。已登记、未登记、未知
	
	@Field(type = FieldType.Text)
	private String net_age; // 网龄
	
	@Field(type = FieldType.Text)
	private String credit_point; //积分。整形数字
	
	@Field(type = FieldType.Text)
	private String credit_level;//账户星级。0-5或未知
	
	@Field(type = FieldType.Text)
	private String current_fee;//当前话费。整形数字精确到分
	
	@Field(type = FieldType.Integer)
	private int tel_use_tm = -1; // 手机号使用时间>6月(-1不存在数据 >0月份)由于运营商只提供6个月的账单，因此目前最大数为6
	
	@Field(type = FieldType.Integer)
	private int tel_exchange = -1; // 手机互通联系人个数(-1不存在数据 >0 数据条数)
	
	@Field(type = FieldType.Integer)
	private int data_change;//数据是否改变 0.未改变 1.已改变 (如果为【1.已改变】则用定时任务获取报告)
	
	@Field(type = FieldType.Integer)
	private int update_time; // 数据获取时间 

	public String getLevel_1_code() {
		return level_1_code;
	}

	public void setLevel_1_code(String level_1_code) {
		this.level_1_code = level_1_code;
	}

	public String getCell_phone() {
		return cell_phone;
	}

	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getReg_time() {
		return reg_time;
	}

	public void setReg_time(String reg_time) {
		this.reg_time = reg_time;
	}

	public String getReal_name() {
		return real_name;
	}

	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public int getData_change() {
		return data_change;
	}

	public void setData_change(int data_change) {
		this.data_change = data_change;
	}

	public int getTel_use_tm() {
		return tel_use_tm;
	}

	public void setTel_use_tm(int tel_use_tm) {
		this.tel_use_tm = tel_use_tm;
	}

	public int getTel_exchange() {
		return tel_exchange;
	}

	public void setTel_exchange(int tel_exchange) {
		this.tel_exchange = tel_exchange;
	}

	public Integer getMobile_balance() {
		return mobile_balance;
	}

	public void setMobile_balance(Integer mobile_balance) {
		this.mobile_balance = mobile_balance;
	}

	public String getMobile_status() {
		return mobile_status;
	}

	public void setMobile_status(String mobile_status) {
		this.mobile_status = mobile_status;
	}

	public String getReal_info() {
		return real_info;
	}

	public void setReal_info(String real_info) {
		this.real_info = real_info;
	}

	public String getNet_age() {
		return net_age;
	}

	public void setNet_age(String net_age) {
		this.net_age = net_age;
	}

	public String getCredit_point() {
		return credit_point;
	}

	public void setCredit_point(String credit_point) {
		this.credit_point = credit_point;
	}

	public String getCredit_level() {
		return credit_level;
	}

	public void setCredit_level(String credit_level) {
		this.credit_level = credit_level;
	}

	public String getCurrent_fee() {
		return current_fee;
	}

	public void setCurrent_fee(String current_fee) {
		this.current_fee = current_fee;
	}
}

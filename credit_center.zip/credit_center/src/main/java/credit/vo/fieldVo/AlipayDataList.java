package credit.vo.fieldVo;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;

/**
 * @author: yuetongfei
 * @date: 2018-12-03
 **/
public class AlipayDataList implements Serializable {
 
    @Field(type = FieldType.Text)
    private String gmtCreate; // 支付时间

    @Field(type = FieldType.Text)
    private String consumeTitle; // 消费名称
    
    @Field(type = FieldType.Text)
    private String consumeFee; // 消费金额
    
    @Field(type = FieldType.Text)
    private String txTypeName; // 交易类型
    
    @Field(type = FieldType.Text)
    private String tradeStatusName; // 交易状态
    
    @Field(type = FieldType.Text)
    private String otherSide; // 交易对方
    
    public String getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(String gmtCreate) {
        this.gmtCreate = gmtCreate;
    }
 
    public String getConsumeTitle() {
        return consumeTitle;
    }

    public void setConsumeTitle(String consumeTitle) {
        this.consumeTitle = consumeTitle;
    }

    public String getConsumeFee() {
        return consumeFee;
    }

    public void setConsumeFee(String consumeFee) {
        this.consumeFee = consumeFee;
    }

	public String getTxTypeName() {
		return txTypeName;
	}

	public void setTxTypeName(String txTypeName) {
		this.txTypeName = txTypeName;
	}

	public String getOtherSide() {
		return otherSide;
	}

	public void setOtherSide(String otherSide) {
		this.otherSide = otherSide;
	}

	public String getTradeStatusName() {
		return tradeStatusName;
	}

	public void setTradeStatusName(String tradeStatusName) {
		this.tradeStatusName = tradeStatusName;
	}
    
}

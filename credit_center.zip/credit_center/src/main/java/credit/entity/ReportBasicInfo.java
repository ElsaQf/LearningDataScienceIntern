package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.CarInfo;
import credit.vo.fieldVo.EarnInfo;
import credit.vo.fieldVo.GjjBaseInfo;
import credit.vo.fieldVo.HouseInfo;
import credit.vo.fieldVo.JdBasiceInfo;
import credit.vo.fieldVo.JobInfo;
import credit.vo.fieldVo.LocationInfo;
import credit.vo.fieldVo.MobileBasicInfo;
import credit.vo.fieldVo.ShebaoBaseInfo;
import credit.vo.fieldVo.UserBaseInfo;
import credit.vo.fieldVo.ZhiMaCredit;
import credit.vo.parmVo.AliPayAuth;
import credit.vo.parmVo.CreditDataSource;
import credit.vo.parmVo.IdcardAuth;
import credit.vo.parmVo.JieDaiBaoAuth;

/**
 * 主要存放各项认证基础信息
 * @author YCM
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "report_basic_info", type = "credit_data", createIndex = false)
public class ReportBasicInfo implements Serializable  {
	
	/**
	 * 报告ID
	 */
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Object)
	private UserBaseInfo user_base_info;
	
	@Field(type = FieldType.Object)
	private MobileBasicInfo mobile_basic_info;
	
	@Field(type = FieldType.Object)
    private CarInfo car_info;
    
	@Field(type = FieldType.Object)
    private EarnInfo earn_info;
    
	@Field(type = FieldType.Object)
    private HouseInfo house_info;
    
	@Field(type = FieldType.Object)
    private JobInfo job_info;
    
	@Field(type = FieldType.Object)
    private LocationInfo location_Info;
    
	@Field(type = FieldType.Object)
    private GjjBaseInfo gjj_base_info;
    
	@Field(type = FieldType.Object)
    private ShebaoBaseInfo shebao_base_info;

	@Field(type = FieldType.Object)
	private JdBasiceInfo ebusiness_basice_info;
	
	@Field(type = FieldType.Object)
	private ZhiMaCredit zhiMaCredit;
	
	@Field(type = FieldType.Object)
	private List<CreditDataSource> dataSourceList;

	@Field(type = FieldType.Object)
	private AliPayAuth aliPayAuth; // 支付宝认证信息 风控

	@Field(type = FieldType.Object)
	private IdcardAuth idcardAuth; // 身份证认证信息 风控

	@Field(type = FieldType.Object)
	private JieDaiBaoAuth jieDaiBaoAuth; // 借贷宝认证信息 风控
    
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public GjjBaseInfo getGjj_base_info() {
		return gjj_base_info;
	}

	public void setGjj_base_info(GjjBaseInfo gjj_base_info) {
		this.gjj_base_info = gjj_base_info;
	}
	public ShebaoBaseInfo getShebao_base_info() {
		return shebao_base_info;
	}
	public void setShebao_base_info(ShebaoBaseInfo shebao_base_info) {
		this.shebao_base_info = shebao_base_info;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public UserBaseInfo getUser_base_info() {
		return user_base_info;
	}
	public void setUser_base_info(UserBaseInfo user_base_info) {
		this.user_base_info = user_base_info;
	}
	public CarInfo getCar_info() {
		return car_info;
	}
	public void setCar_info(CarInfo car_info) {
		this.car_info = car_info;
	}
	public EarnInfo getEarn_info() {
		return earn_info;
	}
	public void setEarn_info(EarnInfo earn_info) {
		this.earn_info = earn_info;
	}
	public HouseInfo getHouse_info() {
		return house_info;
	}
	public void setHouse_info(HouseInfo house_info) {
		this.house_info = house_info;
	}
	public JobInfo getJob_info() {
		return job_info;
	}
	public void setJob_info(JobInfo job_info) {
		this.job_info = job_info;
	}
	public LocationInfo getLocation_Info() {
		return location_Info;
	}
	public void setLocation_Info(LocationInfo location_Info) {
		this.location_Info = location_Info;
	}
	public MobileBasicInfo getMobile_basic_info() {
		return mobile_basic_info;
	}
	public void setMobile_basic_info(MobileBasicInfo mobile_basic_info) {
		this.mobile_basic_info = mobile_basic_info;
	}

	public JdBasiceInfo getEbusiness_basice_info() {
		return ebusiness_basice_info;
	}

	public void setEbusiness_basice_info(JdBasiceInfo ebusiness_basice_info) {
		this.ebusiness_basice_info = ebusiness_basice_info;
	}

	public List<CreditDataSource> getDataSourceList() {
		return dataSourceList;
	}

	public void setDataSourceList(List<CreditDataSource> dataSourceList) {
		this.dataSourceList = dataSourceList;
	}

	public ZhiMaCredit getZhiMaCredit() {
		return zhiMaCredit;
	}

	public void setZhiMaCredit(ZhiMaCredit zhiMaCredit) {
		this.zhiMaCredit = zhiMaCredit;
	}

	public AliPayAuth getAliPayAuth() {
		return aliPayAuth;
	}

	public void setAliPayAuth(AliPayAuth aliPayAuth) {
		this.aliPayAuth = aliPayAuth;
	}

	public IdcardAuth getIdcardAuth() {
		return idcardAuth;
	}

	public void setIdcardAuth(IdcardAuth idcardAuth) {
		this.idcardAuth = idcardAuth;
	}

	public JieDaiBaoAuth getJieDaiBaoAuth() {
		return jieDaiBaoAuth;
	}

	public void setJieDaiBaoAuth(JieDaiBaoAuth jieDaiBaoAuth) {
		this.jieDaiBaoAuth = jieDaiBaoAuth;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}

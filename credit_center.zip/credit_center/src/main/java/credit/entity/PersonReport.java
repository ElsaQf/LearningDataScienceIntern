package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.JdAnalyzeReport;
import credit.vo.fieldVo.MobileReport;
import credit.vo.fieldVo.ZhengXinReport;

/**
 * 报告人的信息统计(简版和详版报告使用)
 * 
 * @author YCM
 * @date 2018年7月6日 下午7:21:15
 */
@SuppressWarnings("serial")
@Document(indexName = "person_report", type = "credit_data", createIndex = false)
public class PersonReport implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;// 报告ID
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Keyword)
	private String report_no;// 报告NO
	
	@Field(type = FieldType.Integer)
	private Integer credit_tm; // 报告时间
	
	@Field(type = FieldType.Text)
	private String real_name; // 真实姓名
	
	@Field(type = FieldType.Text)
	private String id_card_num; // 身份证号码
	
	@Field(type = FieldType.Text)
	private String home_addr; // 家庭住址
	
	@Field(type = FieldType.Text)
	private String wechat_id; // 微信号
	
	@Field(type = FieldType.Text)
	private String gender; // 性别
	
	@Field(type = FieldType.Integer)
	private Integer age; // 年龄
	
	@Field(type = FieldType.Text)
	private String head; // 头像

	@Field(type = FieldType.Object)
	private ZhengXinReport zhengXinReport;
	
	@Field(type = FieldType.Object)
	private JdAnalyzeReport ebusinessReport;
	
	@Field(type = FieldType.Object)
	private MobileReport mobileReport;
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getReal_name() {
		return real_name;
	}

	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}

	public String getId_card_num() {
		return id_card_num;
	}

	public void setId_card_num(String id_card_num) {
		this.id_card_num = id_card_num;
	}

	public String getHome_addr() {
		return home_addr;
	}

	public void setHome_addr(String home_addr) {
		this.home_addr = home_addr;
	}

	public String getWechat_id() {
		return wechat_id;
	}

	public void setWechat_id(String wechat_id) {
		this.wechat_id = wechat_id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public ZhengXinReport getZhengXinReport() {
		return zhengXinReport;
	}

	public void setZhengXinReport(ZhengXinReport zhengXinReport) {
		this.zhengXinReport = zhengXinReport;
	}

	public JdAnalyzeReport getEbusinessReport() {
		return ebusinessReport;
	}

	public void setEbusinessReport(JdAnalyzeReport ebusinessReport) {
		this.ebusinessReport = ebusinessReport;
	}

	public MobileReport getMobileReport() {
		return mobileReport;
	}

	public void setMobileReport(MobileReport mobileReport) {
		this.mobileReport = mobileReport;
	}

	public Integer getCredit_tm() {
		return credit_tm;
	}

	public void setCredit_tm(Integer credit_tm) {
		this.credit_tm = credit_tm;
	}

	public String getReport_no() {
		return report_no;
	}

	public void setReport_no(String report_no) {
		this.report_no = report_no;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	
}
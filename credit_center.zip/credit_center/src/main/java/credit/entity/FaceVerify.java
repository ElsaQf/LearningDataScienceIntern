package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 人脸识别
 * 
 * @author zhanglle
 *
 */
@Document(indexName = "face_verify", type = "credit_data", createIndex = false)
public class FaceVerify implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id; // 报告id
 
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Integer)
	private Integer n_type;//人脸通道（0 小视 1 face++ 2 微众）
	
	@Field(type = FieldType.Integer)
	private Integer source_type;//人脸入口来源（今借到有两个人脸入口（1：九宫格  2：极速借条实名））
	
	@Field(type = FieldType.Text)
	private String biz_id;// 第三方接口id
	
	@Field(type = FieldType.Keyword)
	private String biz_id_key;// 第三方接口id(keyword类型)
	
	@Field(type = FieldType.Text)
	private String name;// 姓名
	
	@Field(type = FieldType.Text)
	private String idcard_no;// 身份证
	
	@Field(type = FieldType.Text)
	private String address;// 家庭住址
	
	@Field(type = FieldType.Text)
	private String live_img;// 活体照片

	@Field(type = FieldType.Text)
	private String card_front_img; // 身份证正面照片

	@Field(type = FieldType.Text)
	private String card_back_img;// 身份证背面照片
	
	@Field(type = FieldType.Integer)
	private Integer card_verify_status;// 身份证验证状态 -1:未检测 0:失败 1:成功
	
	@Field(type = FieldType.Integer)
	private Integer live_status;// 活体验证状态 -1:未检测 0:失败 1:成功
	
	@Field(type = FieldType.Integer)
	private Integer compare_status;// 身份证和活体照片对比状态 -1:未检测 0:失败 1:成功

	@Field(type = FieldType.Integer)
	private Integer status; // 1 成功 0 人脸对比未通过 -3身份证识别未通过 -2 绑卡身份证姓名和人脸识别不是同一个人 // -1 活体验证未通过
	
	@Field(type = FieldType.Boolean)
	private boolean only_live_verify; // 是否只做活体验证

	@Field(type = FieldType.Text) // 是否是微信
	private boolean is_weixin;
	
	@Field(type = FieldType.Text) //跳转URL后缀（第一风控每次返回的url不一样，把不一样的放在这）
	private String return_url_suffix;
	
	@Field(type = FieldType.Integer)
	private Integer update_time;// 更新时间
	
	@Field(type = FieldType.Integer)
	private Integer crt_tm;// 创建时间

	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getLive_img() {
		return live_img;
	}

	public void setLive_img(String live_img) {
		this.live_img = live_img;
	}

	public Integer getLive_status() {
		return live_status;
	}

	public void setLive_status(Integer live_status) {
		this.live_status = live_status;
	}

	public String getCard_front_img() {
		return card_front_img;
	}

	public void setCard_front_img(String card_front_img) {
		this.card_front_img = card_front_img;
	}

	public String getCard_back_img() {
		return card_back_img;
	}

	public void setCard_back_img(String card_back_img) {
		this.card_back_img = card_back_img;
	}

	public Integer getCard_verify_status() {
		return card_verify_status;
	}

	public void setCard_verify_status(Integer card_verify_status) {
		this.card_verify_status = card_verify_status;
	}

	public Integer getCompare_status() {
		return compare_status;
	}

	public void setCompare_status(Integer compare_status) {
		this.compare_status = compare_status;
	}

	public String getBiz_id() {
		return biz_id;
	}

	public void setBiz_id(String biz_id) {
		this.biz_id = biz_id;
	}

	public Integer getN_type() {
		return n_type;
	}

	public void setN_type(Integer n_type) {
		this.n_type = n_type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdcard_no() {
		return idcard_no;
	}

	public void setIdcard_no(String idcard_no) {
		this.idcard_no = idcard_no;
	}
 
	public Integer getCrt_tm() {
		return crt_tm;
	}

	public void setCrt_tm(Integer crt_tm) {
		this.crt_tm = crt_tm;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public boolean isIs_weixin() {
		return is_weixin;
	}

	public void setIs_weixin(boolean is_weixin) {
		this.is_weixin = is_weixin;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBiz_id_key() {
		return biz_id_key;
	}

	public void setBiz_id_key(String biz_id_key) {
		this.biz_id_key = biz_id_key;
	}

	public Integer getSource_type() {
		return source_type;
	}

	public void setSource_type(Integer source_type) {
		this.source_type = source_type;
	}

	public String getReturn_url_suffix() {
		return return_url_suffix;
	}

	public void setReturn_url_suffix(String return_url_suffix) {
		this.return_url_suffix = return_url_suffix;
	}

	public boolean isOnly_live_verify() {
		return only_live_verify;
	}

	public void setOnly_live_verify(boolean only_live_verify) {
		this.only_live_verify = only_live_verify;
	}
	
	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}
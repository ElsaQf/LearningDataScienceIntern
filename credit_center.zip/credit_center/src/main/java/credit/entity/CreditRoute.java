package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 授信路由--运营商专用，其他认证项路由改为credit_route_config
 * @author YCM
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "credit_route", type = "credit_data", createIndex = false)
public class CreditRoute implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
    private String id;//id
	
	@Field(type = FieldType.Integer)
	private int credit_type;
	
	@Field(type = FieldType.Text)
	private String auth_name;
	
	@Field(type = FieldType.Integer)
	private int auth_order;
	
	@Field(type = FieldType.Text)
	private String desc;
	
	@Field(type = FieldType.Boolean)
	private boolean valid;

	public int getAuth_order() {
		return auth_order;
	}

	public void setAuth_order(int auth_order) {
		this.auth_order = auth_order;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAuth_name() {
		return auth_name;
	}

	public void setAuth_name(String auth_name) {
		this.auth_name = auth_name;
	}

	public int getCredit_type() {
		return credit_type;
	}

	public void setCredit_type(int credit_type) {
		this.credit_type = credit_type;
	}
	
}

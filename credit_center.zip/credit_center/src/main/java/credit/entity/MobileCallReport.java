package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.MobileCallDetail;

/**
 * (报告)通话记录报告
 * Title: MobileCallReport.java
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_call_report", type = "credit_data", createIndex = false)
public class MobileCallReport implements Serializable{
	@Id
	@Field(type = FieldType.Text)
	private String report_id;//报告ID
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Object)
	private List<MobileCallDetail>  report_detail_list;
 
	@Field(type = FieldType.Integer)
	private int update_time;
	
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public List<MobileCallDetail> getReport_detail_list() {
		return report_detail_list;
	}

	public void setReport_detail_list(List<MobileCallDetail> report_detail_list) {
		this.report_detail_list = report_detail_list;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}
package credit.entity;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.vo
 * Created by bob on 18-8-21.
 * Description:  
 *******************************************************************************/
public class RiskControlVO {

}

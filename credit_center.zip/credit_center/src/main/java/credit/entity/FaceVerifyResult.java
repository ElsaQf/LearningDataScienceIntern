package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
/**
 * 人脸识别  第三方返回结果
 * @author zhanglle
 *
 */
@Document(indexName = "face_verify_result", type = "credit_data", createIndex = false)
public class FaceVerifyResult implements Serializable{
	
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;	// 报告id
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Text)
	public String live_result;//活体返回结果
	
	@Field(type = FieldType.Text)
	public String card_verify_result;//身份证验证返回结果
	
	@Field(type = FieldType.Text)
	public String compare_result; //身份证和活体照片对比返回结果

	@Field(type = FieldType.Integer)
	private Integer crt_tm;// 创建时间

	@Field(type = FieldType.Integer)
	private Integer update_time;// 更新时间
	
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getLive_result() {
		return live_result;
	}
	public void setLive_result(String live_result) {
		this.live_result = live_result;
	}
	public String getCard_verify_result() {
		return card_verify_result;
	}
	public void setCard_verify_result(String card_verify_result) {
		this.card_verify_result = card_verify_result;
	}
	public String getCompare_result() {
		return compare_result;
	}
	public void setCompare_result(String compare_result) {
		this.compare_result = compare_result;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getCrt_tm() {
		return crt_tm;
	}
	public void setCrt_tm(Integer crt_tm) {
		this.crt_tm = crt_tm;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

}
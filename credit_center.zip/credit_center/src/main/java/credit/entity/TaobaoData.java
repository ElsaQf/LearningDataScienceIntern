package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.util.sjmh.taobao.AddressDetail;
import credit.util.sjmh.taobao.BaseInfo;
import credit.util.sjmh.taobao.OrderDetail;

/**
 * 淘宝信息
 */
@SuppressWarnings("serial")
@Document(indexName = "taobao_data", type = "credit_data", createIndex = false)
public class TaobaoData implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;	// 主键
	 
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Integer)
	private Integer update_time;
		
	@Field(type = FieldType.Object)
	private BaseInfo baseInfo; //基础信息
	
	@Field(type = FieldType.Object)
	private List<OrderDetail> orderList; //订单
	
	@Field(type = FieldType.Object)
	private List<AddressDetail> addressList; //地址

	@Field(type = FieldType.Text)
    private String route_name; // 认证通道
	
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public BaseInfo getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(BaseInfo baseInfo) {
		this.baseInfo = baseInfo;
	}

	public List<OrderDetail> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderDetail> orderList) {
		this.orderList = orderList;
	}

	public List<AddressDetail> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<AddressDetail> addressList) {
		this.addressList = addressList;
	}

	public String getRoute_name() {
		return route_name;
	}

	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}

}

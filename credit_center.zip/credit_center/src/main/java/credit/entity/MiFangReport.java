package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.parmVo.mifang.BorrowReport;

/**
 * 米房数据
 */
@SuppressWarnings("serial")
@Document(indexName = "mifang_report", type = "credit_data", createIndex = false)
public class MiFangReport implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;// 主键
	@Field(type = FieldType.Keyword)
	private String system_name;
	@Field(type = FieldType.Object)
	private BorrowReport borrowReport;//借入报告
	@Field(type = FieldType.Integer)
	private Integer update_time;
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public BorrowReport getBorrowReport() {
		return borrowReport;
	}
	public void setBorrowReport(BorrowReport borrowReport) {
		this.borrowReport = borrowReport;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
	public Integer getVerson_num() {
		return verson_num;
	}
	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	 
}

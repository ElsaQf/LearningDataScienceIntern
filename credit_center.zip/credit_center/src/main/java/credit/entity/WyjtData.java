package credit.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.WyjtBaseInfo;
import credit.vo.fieldVo.WyjtLoan;
import credit.vo.fieldVo.WyjtSumData;

/**
 * 百融黑名单
 * @author YCM
 * @date 2019年3月29日 下午1:55:27
 */
@Document(indexName = "wyjt_data", type = "credit_data", createIndex = false)
public class WyjtData {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;//主键
	 
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Integer)
	private int credit_status;//认证状态
	
	@Field(type = FieldType.Text, index = false) 
	private String phone;//认证手机号
	
	@Field(type = FieldType.Object)
	private WyjtBaseInfo base_info;//无忧借条个人信息
	@Field(type = FieldType.Object)
	private List<WyjtLoan> loan_list;//无忧借条数据
	@Field(type = FieldType.Object)
	private List<WyjtSumData> sum_list;//无忧借条汇总数据
	
	@Field(type = FieldType.Integer)
	private Integer update_time;

	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public int getCredit_status() {
		return credit_status;
	}

	public void setCredit_status(int credit_status) {
		this.credit_status = credit_status;
	}

	public WyjtBaseInfo getBase_info() {
		return base_info;
	}

	public void setBase_info(WyjtBaseInfo base_info) {
		this.base_info = base_info;
	}

	public List<WyjtLoan> getLoan_list() {
		return loan_list;
	}

	public void setLoan_list(List<WyjtLoan> loan_list) {
		this.loan_list = loan_list;
	}

	public List<WyjtSumData> getSum_list() {
		return sum_list;
	}

	public void setSum_list(List<WyjtSumData> sum_list) {
		this.sum_list = sum_list;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
}

package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.JobInfo;

/**
 * 工作信息历史表
 * @author yuan
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "job_info_history", type = "credit_data", createIndex = false)
public class JobInfoHistory implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
    private String report_id;//报告id
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Object)
	private List<JobInfo>  job_info_list;
	 
	@Field(type = FieldType.Integer)
	private int update_time;

	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public List<JobInfo> getJob_info_list() {
		return job_info_list;
	}

	public void setJob_info_list(List<JobInfo> job_info_list) {
		this.job_info_list = job_info_list;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	
	
}

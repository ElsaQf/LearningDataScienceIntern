package credit.entity.renew;

import java.util.List;

import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.CallRecordDetail;
import credit.vo.fieldVo.MobileRawBase;

/**
 * 运营商消费信息
 * Title: MobileRechargeRawData.java
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_call_raw_data", type = "credit_data", createIndex = false)
public class MobileCallRawData extends MobileRawBase{
	@Field(type = FieldType.Integer)
	private Integer month_call_count; // 月通话次数,用于判断后来获取的和之前已经取到的对比
	
	@Field(type = FieldType.Float)
	private Float month_call_len = 0F; // 月通话时长
	
	@Field(type = FieldType.Object)
	private List<CallRecordDetail>  call_detail; //通话记录

	public List<CallRecordDetail> getCall_detail() {
		return call_detail;
	}

	public void setCall_detail(List<CallRecordDetail> call_detail) {
		this.call_detail = call_detail;
	}

	public Integer getMonth_call_count() {
		return month_call_count;
	}

	public void setMonth_call_count(Integer month_call_count) {
		this.month_call_count = month_call_count;
	}

	public Float getMonth_call_len() {
		return month_call_len;
	}

	public void setMonth_call_len(Float month_call_len) {
		this.month_call_len = month_call_len;
	}
	
}
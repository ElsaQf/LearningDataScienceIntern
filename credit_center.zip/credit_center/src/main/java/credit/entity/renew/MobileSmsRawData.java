package credit.entity.renew;

import java.util.List;

import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.MobileRawBase;
import credit.vo.fieldVo.SmsRecordDetail;

/**
 * 运营商消费信息
 * Title: MobileRechargeRawData.java
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_sms_raw_data", type = "credit_data", createIndex = false)
public class MobileSmsRawData extends MobileRawBase{
	@Field(type = FieldType.Integer)
	private Integer month_msg_count;//总短信次数。整形数字
	
	@Field(type = FieldType.Object)
	private List<SmsRecordDetail> sms_detail; //短信记录

	public List<SmsRecordDetail> getSms_detail() {
		return sms_detail;
	}

	public void setSms_detail(List<SmsRecordDetail> sms_detail) {
		this.sms_detail = sms_detail;
	}

	public Integer getMonth_msg_count() {
		return month_msg_count;
	}

	public void setMonth_msg_count(Integer month_msg_count) {
		this.month_msg_count = month_msg_count;
	}
	
}
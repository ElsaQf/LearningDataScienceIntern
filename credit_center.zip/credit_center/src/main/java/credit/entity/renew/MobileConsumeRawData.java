package credit.entity.renew;

import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.MobileBillInfo;
import credit.vo.fieldVo.MobileRawBase;
import credit.vo.fieldVo.MobileRechargeInfo;

/**
 * 运营商消费信息
 * Title: MobileRechargeRawData.java
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_consume_raw_data", type = "credit_data", createIndex = false)
public class MobileConsumeRawData extends MobileRawBase{
	@Field(type = FieldType.Text)
	private String route_name; // 认证通道
	
	/* 聚信立字段start */
	@Field(type = FieldType.Integer)
	private	Integer	recharge_count;//充值次数
	@Field(type = FieldType.Integer)
	private	Integer recharge_amount;//充值金额
	@Field(type = FieldType.Integer)
	private	Integer consume_amount;//话费消费
	@Field(type = FieldType.Integer)
	private	Integer	call_count;//呼叫次数
	@Field(type = FieldType.Integer)
	private	Integer	call_count_active;//主叫次数
	@Field(type = FieldType.Float)
	private	Float call_time_active;//主叫时间
	@Field(type = FieldType.Integer)
	private	Integer	call_count_passive;//被叫次数
	@Field(type = FieldType.Float)
	private	Float call_time_passive;//被叫时间
	@Field(type = FieldType.Integer)
	private	Integer	msg_count;//短信数目
	/* 聚信立字段end */
	
	@Field(type = FieldType.Object)
	private MobileRechargeInfo recharge_innfo;//充值信息（数据魔盒）
	@Field(type = FieldType.Object)
	private MobileBillInfo bill_innfo;//账单信息（数据魔盒）
	
	public String getRoute_name() {
		return route_name;
	}
	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}
	public Integer getRecharge_count() {
		return recharge_count;
	}
	public void setRecharge_count(Integer recharge_count) {
		this.recharge_count = recharge_count;
	}
	public Integer getRecharge_amount() {
		return recharge_amount;
	}
	public void setRecharge_amount(Integer recharge_amount) {
		this.recharge_amount = recharge_amount;
	}
	public Integer getConsume_amount() {
		return consume_amount;
	}
	public void setConsume_amount(Integer consume_amount) {
		this.consume_amount = consume_amount;
	}
	public Integer getCall_count() {
		return call_count;
	}
	public void setCall_count(Integer call_count) {
		this.call_count = call_count;
	}
	public Integer getCall_count_active() {
		return call_count_active;
	}
	public void setCall_count_active(Integer call_count_active) {
		this.call_count_active = call_count_active;
	}
	public Float getCall_time_active() {
		return call_time_active;
	}
	public void setCall_time_active(Float call_time_active) {
		if(call_time_active != null) {
			call_time_active = ((float)Math.round(call_time_active*100))/100;
		}
		this.call_time_active = call_time_active;
	}
	public Integer getCall_count_passive() {
		return call_count_passive;
	}
	public void setCall_count_passive(Integer call_count_passive) {
		this.call_count_passive = call_count_passive;
	}
	public Float getCall_time_passive() {
		return call_time_passive;
	}
	public void setCall_time_passive(Float call_time_passive) {
		if(call_time_passive != null) {
			call_time_passive = ((float)Math.round(call_time_passive*100))/100;
		}
		this.call_time_passive = call_time_passive;
	}
	public Integer getMsg_count() {
		return msg_count;
	}
	public void setMsg_count(Integer msg_count) {
		this.msg_count = msg_count;
	}
	public MobileRechargeInfo getRecharge_innfo() {
		return recharge_innfo;
	}
	public void setRecharge_innfo(MobileRechargeInfo recharge_innfo) {
		this.recharge_innfo = recharge_innfo;
	}
	public MobileBillInfo getBill_innfo() {
		return bill_innfo;
	}
	public void setBill_innfo(MobileBillInfo bill_innfo) {
		this.bill_innfo = bill_innfo;
	}
}
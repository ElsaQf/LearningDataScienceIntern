package credit.entity.renew;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.util.jxl.report.ContactCheck;
import credit.util.jxl.report.ContactEachOther;
import credit.util.jxl.report.ContactNightStats;
import credit.util.jxl.report.MultipointInfoCheck;
import credit.util.jxl.report.SocialRiskCheck;
import credit.util.jxl.report.UserInfoReport;
import credit.vo.fieldVo.ActiveSilentStats;
import credit.vo.fieldVo.CallAreaStats;
import credit.vo.fieldVo.ContactRegionStats;
import credit.vo.fieldVo.TravelTrackAnalysis;

/**
 * 新版--运营商分析报告
 * @author YCM
 * @date 2019年5月16日 下午2:24:16
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_analyze_report0", type = "credit_data", createIndex = false)
public class MobileAnalyzeReport0 {

    @Id
    @Field(type = FieldType.Keyword)
    private String report_id;//报告ID

	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Object)
	private UserInfoReport user_info_report; // 运营商用户信息报告
	@Field(type = FieldType.Object)
	private ActiveSilentStats active_silence_stats; // 静默统计
	@Field(type = FieldType.Object)
	private List<ContactCheck> risk_contact_check; // 风险联系人
	@Field(type = FieldType.Object)
	private List<ContactRegionStats> contact_region_stats; // 联系人归属地统计
	@Field(type = FieldType.Object)
	private List<CallAreaStats> call_area_stats; // 通话时所在地统计
	@Field(type = FieldType.Object)
	private List<TravelTrackAnalysis> travel_track_analysis; // 出行记录分析(漫游)
	@Field(type = FieldType.Object)
	private MultipointInfoCheck multipoint_info_check; // 多头信息检测
	@Field(type = FieldType.Object)
	private SocialRiskCheck social_risk_check; // 社交风险检测
	@Field(type = FieldType.Object)
	private ContactNightStats contact_night_stats; // 运营商夜间通话情况
	@Field(type = FieldType.Object)
	private ContactEachOther contact_each_other; // 运营商通话号码数量情况
	
    @Field(type = FieldType.Text, index = false)
    private String  analyze_data; // 分析报告数据

    @Field(type = FieldType.Text)
    private String route_name; // 认证通道

    @Field(type = FieldType.Integer)
    private int update_time;

    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public String getAnalyze_data() {
        return analyze_data;
    }

    public void setAnalyze_data(String analyze_data) {
        this.analyze_data = analyze_data;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getRoute_name() {
        return route_name;
    }

    public void setRoute_name(String route_name) {
        this.route_name = route_name;
    }

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}

	public List<ContactCheck> getRisk_contact_check() {
		return risk_contact_check;
	}

	public void setRisk_contact_check(List<ContactCheck> risk_contact_check) {
		this.risk_contact_check = risk_contact_check;
	}

	public List<ContactRegionStats> getContact_region_stats() {
		return contact_region_stats;
	}

	public void setContact_region_stats(List<ContactRegionStats> contact_region_stats) {
		this.contact_region_stats = contact_region_stats;
	}

	public List<TravelTrackAnalysis> getTravel_track_analysis() {
		return travel_track_analysis;
	}

	public void setTravel_track_analysis(List<TravelTrackAnalysis> travel_track_analysis) {
		this.travel_track_analysis = travel_track_analysis;
	}

	public MultipointInfoCheck getMultipoint_info_check() {
		return multipoint_info_check;
	}

	public void setMultipoint_info_check(MultipointInfoCheck multipoint_info_check) {
		this.multipoint_info_check = multipoint_info_check;
	}

	public SocialRiskCheck getSocial_risk_check() {
		return social_risk_check;
	}

	public void setSocial_risk_check(SocialRiskCheck social_risk_check) {
		this.social_risk_check = social_risk_check;
	}

	public UserInfoReport getUser_info_report() {
		return user_info_report;
	}

	public void setUser_info_report(UserInfoReport user_info_report) {
		this.user_info_report = user_info_report;
	}

	public ContactNightStats getContact_night_stats() {
		return contact_night_stats;
	}

	public void setContact_night_stats(ContactNightStats contact_night_stats) {
		this.contact_night_stats = contact_night_stats;
	}

	public ContactEachOther getContact_each_other() {
		return contact_each_other;
	}

	public void setContact_each_other(ContactEachOther contact_each_other) {
		this.contact_each_other = contact_each_other;
	}

	public ActiveSilentStats getActive_silence_stats() {
		return active_silence_stats;
	}

	public void setActive_silence_stats(ActiveSilentStats active_silence_stats) {
		this.active_silence_stats = active_silence_stats;
	}

	public List<CallAreaStats> getCall_area_stats() {
		return call_area_stats;
	}

	public void setCall_area_stats(List<CallAreaStats> call_area_stats) {
		this.call_area_stats = call_area_stats;
	}
 
}

package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.JdExpense;
import credit.vo.parmVo.EbusinessOrder;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-13.
 * Description:  电商月度消费报告
 *******************************************************************************/

@SuppressWarnings("serial")
@Document(indexName = "ebusiness_expense_report", type = "credit_data", createIndex = false)
public class JdExpenseReport implements Serializable {
    @Id
    @Field(type = FieldType.Keyword)
    public String report_id;    // 报告id

    /**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
    @Field(type = FieldType.Integer)
    private int update_time; // 数据获取时间

    @Field(type = FieldType.Object)
    public List<JdExpense> ebusiness_expense_list;

    @Field(type = FieldType.Object)
    public List<EbusinessOrder> order_list;
    
    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public List<JdExpense> getEbusiness_expense_list() {
        return ebusiness_expense_list;
    }

    public void setEbusiness_expense_list(List<JdExpense> ebusiness_expense_list) {
        this.ebusiness_expense_list = ebusiness_expense_list;
    }

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public List<EbusinessOrder> getOrder_list() {
		return order_list;
	}

	public void setOrder_list(List<EbusinessOrder> order_list) {
		this.order_list = order_list;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
    
}

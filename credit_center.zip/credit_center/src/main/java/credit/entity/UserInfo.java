package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 用户基本认证表
 * 
 * @author YCM
 *
 */
@Document(indexName = "user_info", type = "credit_data", createIndex = false)
public class UserInfo implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;
	@Field(type = FieldType.Text)
    private String report_no;//报告编号
	@Field(type = FieldType.Text)
    private String puid;
	@Field(type = FieldType.Boolean)
	private Boolean is_user;//是否为用户(今借到信用报告有个查借款人的功能，传过来的puid不是用户id)
	@Field(type = FieldType.Text)
	private String ouid;    // 今借到原有id
	@Field(type = FieldType.Keyword)
    private String system_name;
	@Field(type = FieldType.Text)
	private String user_name;
	@Field(type = FieldType.Text)
	private String card_no;
	@Field(type = FieldType.Text)
	private String telephone;
	@Field(type = FieldType.Boolean)
	private boolean data_change; // 数据是否发生变化，需要重新生成报告
	@Field(type = FieldType.Boolean)
	private boolean bind_card;// 是否绑卡
	@Field(type = FieldType.Integer)
	private int baseInfo_credit_status;// 基础信息认证状态
	@Field(type = FieldType.Integer)
	private int base_upd_tm;// 基础信息更新时间
	@Field(type = FieldType.Integer)
	private int mobile_credit_status;// 运营商认证状态
	@Field(type = FieldType.Integer)
	private int mobile_upd_tm;// 运营商信息更新时间
	@Field(type = FieldType.Text)
	public String mobile_phone;// 运营商认证用的手机号
	@Field(type = FieldType.Boolean)
	private boolean skip_mobile_auth;// 是否跳过运营商认证
	@Field(type = FieldType.Integer)
	private int skip_mobile_tm;// 跳过运营商时间
	@Field(type = FieldType.Integer)
	private int taobao_credit_status;// 淘宝数据抓取状态
	@Field(type = FieldType.Integer)
	private int taobao_upd_tm;// 淘宝数据更新时间
	@Field(type = FieldType.Integer)
	private int jingdong_credit_status;//京东数据认证状态
	@Field(type = FieldType.Boolean)
	private boolean skip_jd_auth;// 是否跳过京东认证
	@Field(type = FieldType.Integer)
	private int jingdong_upd_tm;// 京东数据更新时间
	@Field(type = FieldType.Integer)
	private int skip_jd_tm;// 跳过京东时间
	@Field(type = FieldType.Integer)
	private int shebao_credit_status;//社保数据认证状态
	@Field(type = FieldType.Integer)
	private int shebao_upd_tm;// 社保数据更新时间
	@Field(type = FieldType.Integer)
	private int gjj_credit_status;//公积金数据认证状态
	@Field(type = FieldType.Integer)
	private int gjj_upd_tm; // 公积金数据更新时间
	@Field(type = FieldType.Integer)
	private int xuexin_credit_status;//学信数据认证状态
	@Field(type = FieldType.Integer)
	private int xuexin_upd_tm; // 学信数据更新时间
	@Field(type = FieldType.Integer)
	private int student_status = -1;// 是否在校大学生 -1.未知 0.不是大学生 1.是大学生 2 专科以下学历
	@Field(type = FieldType.Boolean)
	private boolean up_special;// 是否专科及以上学历  true 专科及以上学历 false 专科以下学历
	@Field(type = FieldType.Integer)
	private int zhengxin_credit_status;//征信数据认证状态
	@Field(type = FieldType.Integer)
	private int zhengxin_upd_tm; // 征信数据更新时间
	@Field(type = FieldType.Integer)
	private int house_credit_status;//房产数据认证状态
	@Field(type = FieldType.Integer)
	private int house_upd_tm; // 房产数据更新时间
	@Field(type = FieldType.Integer)
	private int car_credit_status;//车产数据认证状态
	@Field(type = FieldType.Integer)
	private int car_upd_tm; // 车产数据更新时间
	@Field(type = FieldType.Integer)
	private int income_credit_status;//收入数据认证状态
	@Field(type = FieldType.Integer)
	private int income_upd_tm; // 收入数据更新时间
	@Field(type = FieldType.Integer)
	private int job_credit_status;//工作数据认证状态
	@Field(type = FieldType.Integer)
	private int job_upd_tm; // 工作数据更新时间
	@Field(type = FieldType.Integer)
	private int zhima_credit_status;//芝麻信用认证状态
	@Field(type = FieldType.Integer)
	private int zhima_credit_upd_tm; //芝麻信用数据更新时间
	@Field(type = FieldType.Integer)
	private int mobileAnalysis_credit_status;//通话记录分析认证状态
	@Field(type = FieldType.Integer)
	private int location_credit_status;//定位信息认证状态
	@Field(type = FieldType.Integer)
	private int location_upd_tm; // 定位信息更新时间
	@Field(type = FieldType.Integer)
	private int multipoint_status;//多头借贷认证状态
	@Field(type = FieldType.Integer)
	private int multipoint_upd_time;
	@Field(type = FieldType.Integer)
	private int face_verify_status;//人脸认证状态
	@Field(type = FieldType.Integer)
	private int face_verify_upd_tm; //人脸更新时间
	@Field(type = FieldType.Integer)
	private int dishonest_credit_status;//高法失信认证状态
	@Field(type = FieldType.Integer)
	private int dishonest_upd_tm; //高法更新时间
	@Field(type = FieldType.Integer)
	private int twoElement_credit_status;//二要素认证状态
	@Field(type = FieldType.Integer)
	private int twoElement_upd_tm; //二要素更新时间
	@Field(type = FieldType.Integer)
	private int fourElement_credit_status;//四要素认证状态
	@Field(type = FieldType.Integer)
	private int fourElement_upd_tm; //四要素更新时间
	@Field(type = FieldType.Integer)
	private int alipay_credit_status;//支付宝认证状态
	@Field(type = FieldType.Integer)
	private int alipay_upd_tm;
	@Field(type = FieldType.Integer)
	private int jdbImage_credit_status;//借贷宝图片认证状态
	@Field(type = FieldType.Integer)
	private int jdbImage_upd_tm;//借贷宝图片认证时间
	@Field(type = FieldType.Integer)
	private int urgent_credit_status;//紧急联系人认证状态（第一风控中紧急联系人和基础信息是分开认证的）
	@Field(type = FieldType.Integer)
	private int urgent_upd_tm;//紧急联系人认证时间（第一风控中紧急联系人和基础信息是分开认证的）
	@Field(type = FieldType.Integer)
	private int idcardImage_credit_status;//身份证图片认证状态
	@Field(type = FieldType.Integer)
	private int idcardImage_upd_tm;//身份证图片认证时间
	@Field(type = FieldType.Integer)
	private int netloanBlacklist_credit_status;//网贷黑名单认证状态
	@Field(type = FieldType.Integer)
	private int netloanBlacklist_upd_tm; //网贷黑名单更新时间
	@Field(type = FieldType.Integer)
	private int mobile_analysis_upd_tm;//通话记录分析结果更新时间
	@Field(type = FieldType.Integer)
	private int update_time;
	@Field(type = FieldType.Integer)
	private int create_time;
	@Field(type = FieldType.Boolean) //是否同步
	private Boolean sync_status;
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getCard_no() {
		return card_no;
	}

	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public int getBaseInfo_credit_status() {
		return baseInfo_credit_status;
	}

	public void setBaseInfo_credit_status(int baseInfo_credit_status) {
		this.baseInfo_credit_status = baseInfo_credit_status;
	}

	public int getTaobao_credit_status() {
		return taobao_credit_status;
	}

	public void setTaobao_credit_status(int taobao_credit_status) {
		this.taobao_credit_status = taobao_credit_status;
	}

	public int getJingdong_credit_status() {
		return jingdong_credit_status;
	}

	public void setJingdong_credit_status(int jingdong_credit_status) {
		this.jingdong_credit_status = jingdong_credit_status;
	}

	public int getShebao_credit_status() {
		return shebao_credit_status;
	}

	public void setShebao_credit_status(int shebao_credit_status) {
		this.shebao_credit_status = shebao_credit_status;
	}

	public int getGjj_credit_status() {
		return gjj_credit_status;
	}

	public void setGjj_credit_status(int gjj_credit_status) {
		this.gjj_credit_status = gjj_credit_status;
	}

	public int getHouse_credit_status() {
		return house_credit_status;
	}

	public void setHouse_credit_status(int house_credit_status) {
		this.house_credit_status = house_credit_status;
	}

	public int getCar_credit_status() {
		return car_credit_status;
	}

	public void setCar_credit_status(int car_credit_status) {
		this.car_credit_status = car_credit_status;
	}

	public int getIncome_credit_status() {
		return income_credit_status;
	}

	public void setIncome_credit_status(int income_credit_status) {
		this.income_credit_status = income_credit_status;
	}

	public int getJob_credit_status() {
		return job_credit_status;
	}

	public void setJob_credit_status(int job_credit_status) {
		this.job_credit_status = job_credit_status;
	}

	public int getZhima_credit_status() {
		return zhima_credit_status;
	}

	public void setZhima_credit_status(int zhima_credit_status) {
		this.zhima_credit_status = zhima_credit_status;
	}

	public int getMobileAnalysis_credit_status() {
		return mobileAnalysis_credit_status;
	}

	public void setMobileAnalysis_credit_status(int mobileAnalysis_credit_status) {
		this.mobileAnalysis_credit_status = mobileAnalysis_credit_status;
	}

	public int getLocation_credit_status() {
		return location_credit_status;
	}

	public void setLocation_credit_status(int location_credit_status) {
		this.location_credit_status = location_credit_status;
	}

	public String getMobile_phone() {
		return mobile_phone;
	}

	public void setMobile_phone(String mobile_phone) {
		this.mobile_phone = mobile_phone;
	}

	public int getBase_upd_tm() {
		return base_upd_tm;
	}

	public void setBase_upd_tm(int base_upd_tm) {
		this.base_upd_tm = base_upd_tm;
	}

	public int getTaobao_upd_tm() {
		return taobao_upd_tm;
	}

	public void setTaobao_upd_tm(int taobao_upd_tm) {
		this.taobao_upd_tm = taobao_upd_tm;
	}

	public int getJingdong_upd_tm() {
		return jingdong_upd_tm;
	}

	public void setJingdong_upd_tm(int jingdong_upd_tm) {
		this.jingdong_upd_tm = jingdong_upd_tm;
	}

	public int getShebao_upd_tm() {
		return shebao_upd_tm;
	}

	public void setShebao_upd_tm(int shebao_upd_tm) {
		this.shebao_upd_tm = shebao_upd_tm;
	}

	public int getGjj_upd_tm() {
		return gjj_upd_tm;
	}

	public void setGjj_upd_tm(int gjj_upd_tm) {
		this.gjj_upd_tm = gjj_upd_tm;
	}

	public int getXuexin_credit_status() {
		return xuexin_credit_status;
	}

	public void setXuexin_credit_status(int xuexin_credit_status) {
		this.xuexin_credit_status = xuexin_credit_status;
	}

	public int getZhengxin_credit_status() {
		return zhengxin_credit_status;
	}

	public void setZhengxin_credit_status(int zhengxin_credit_status) {
		this.zhengxin_credit_status = zhengxin_credit_status;
	}

	public int getXuexin_upd_tm() {
		return xuexin_upd_tm;
	}

	public void setXuexin_upd_tm(int xuexin_upd_tm) {
		this.xuexin_upd_tm = xuexin_upd_tm;
	}

	public int getZhengxin_upd_tm() {
		return zhengxin_upd_tm;
	}

	public void setZhengxin_upd_tm(int zhengxin_upd_tm) {
		this.zhengxin_upd_tm = zhengxin_upd_tm;
	}

	public int getHouse_upd_tm() {
		return house_upd_tm;
	}

	public void setHouse_upd_tm(int house_upd_tm) {
		this.house_upd_tm = house_upd_tm;
	}

	public int getCar_upd_tm() {
		return car_upd_tm;
	}

	public void setCar_upd_tm(int car_upd_tm) {
		this.car_upd_tm = car_upd_tm;
	}

	public int getIncome_upd_tm() {
		return income_upd_tm;
	}

	public void setIncome_upd_tm(int income_upd_tm) {
		this.income_upd_tm = income_upd_tm;
	}

	public int getJob_upd_tm() {
		return job_upd_tm;
	}

	public void setJob_upd_tm(int job_upd_tm) {
		this.job_upd_tm = job_upd_tm;
	}

	public int getZhima_credit_upd_tm() {
		return zhima_credit_upd_tm;
	}

	public void setZhima_credit_upd_tm(int zhima_credit_upd_tm) {
		this.zhima_credit_upd_tm = zhima_credit_upd_tm;
	}

	public int getMobile_analysis_upd_tm() {
		return mobile_analysis_upd_tm;
	}

	public void setMobile_analysis_upd_tm(int mobile_analysis_upd_tm) {
		this.mobile_analysis_upd_tm = mobile_analysis_upd_tm;
	}

	public int getLocation_upd_tm() {
		return location_upd_tm;
	}

	public void setLocation_upd_tm(int location_upd_tm) {
		this.location_upd_tm = location_upd_tm;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public int getMobile_credit_status() {
		return mobile_credit_status;
	}

	public void setMobile_credit_status(int mobile_credit_status) {
		this.mobile_credit_status = mobile_credit_status;
	}

	public int getMobile_upd_tm() {
		return mobile_upd_tm;
	}

	public void setMobile_upd_tm(int mobile_upd_tm) {
		this.mobile_upd_tm = mobile_upd_tm;
	}

	public int getStudent_status() {
		return student_status;
	}

	public void setStudent_status(int student_status) {
		this.student_status = student_status;
	}

	public String getPuid() {
		return puid;
	}

	public void setPuid(String puid) {
		this.puid = puid;
	}

	public boolean isUp_special() {
		return up_special;
	}

	public void setUp_special(boolean up_special) {
		this.up_special = up_special;
	}

	public boolean isData_change() {
		return data_change;
	}

	public void setData_change(boolean data_change) {
		this.data_change = data_change;
	}

	public int getFace_verify_status() {
		return face_verify_status;
	}

	public void setFace_verify_status(int face_verify_status) {
		this.face_verify_status = face_verify_status;
	}

	public int getFace_verify_upd_tm() {
		return face_verify_upd_tm;
	}

	public void setFace_verify_upd_tm(int face_verify_upd_tm) {
		this.face_verify_upd_tm = face_verify_upd_tm;
	}

	public int getMultipoint_status() {
		return multipoint_status;
	}

	public void setMultipoint_status(int multipoint_status) {
		this.multipoint_status = multipoint_status;
	}

	public int getMultipoint_upd_time() {
		return multipoint_upd_time;
	}

	public void setMultipoint_upd_time(int multipoint_upd_time) {
		this.multipoint_upd_time = multipoint_upd_time;
	}

	public int getAlipay_credit_status() {
		return alipay_credit_status;
	}

	public void setAlipay_credit_status(int alipay_credit_status) {
		this.alipay_credit_status = alipay_credit_status;
	}

	public int getAlipay_upd_tm() {
		return alipay_upd_tm;
	}

	public void setAlipay_upd_tm(int alipay_upd_tm) {
		this.alipay_upd_tm = alipay_upd_tm;
	}

	public boolean isBind_card() {
		return bind_card;
	}

	public void setBind_card(boolean bind_card) {
		this.bind_card = bind_card;
	}

	public String getOuid() {
		return ouid;
	}

	public void setOuid(String ouid) {
		this.ouid = ouid;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	
	public int getDishonest_credit_status() {
		return dishonest_credit_status;
	}

	public void setDishonest_credit_status(int dishonest_credit_status) {
		this.dishonest_credit_status = dishonest_credit_status;
	}

	public int getDishonest_upd_tm() {
		return dishonest_upd_tm;
	}

	public void setDishonest_upd_tm(int dishonest_upd_tm) {
		this.dishonest_upd_tm = dishonest_upd_tm;
	}

	public boolean isSkip_mobile_auth() {
		return skip_mobile_auth;
	}

	public void setSkip_mobile_auth(boolean skip_mobile_auth) {
		this.skip_mobile_auth = skip_mobile_auth;
	}

	public int getSkip_mobile_tm() {
		return skip_mobile_tm;
	}

	public void setSkip_mobile_tm(int skip_mobile_tm) {
		this.skip_mobile_tm = skip_mobile_tm;
	}

	public int getCreate_time() {
		return create_time;
	}

	public void setCreate_time(int create_time) {
		this.create_time = create_time;
	}

	public String getReport_no() {
		return report_no;
	}

	public void setReport_no(String report_no) {
		this.report_no = report_no;
	}
	
	public boolean isSkip_jd_auth() {
		return skip_jd_auth;
	}

	public void setSkip_jd_auth(boolean skip_jd_auth) {
		this.skip_jd_auth = skip_jd_auth;
	}

	public int getSkip_jd_tm() {
		return skip_jd_tm;
	}

	public void setSkip_jd_tm(int skip_jd_tm) {
		this.skip_jd_tm = skip_jd_tm;
	}

	public int getJdbImage_credit_status() {
		return jdbImage_credit_status;
	}

	public void setJdbImage_credit_status(int jdbImage_credit_status) {
		this.jdbImage_credit_status = jdbImage_credit_status;
	}

	public int getUrgent_credit_status() {
		return urgent_credit_status;
	}

	public void setUrgent_credit_status(int urgent_credit_status) {
		this.urgent_credit_status = urgent_credit_status;
	}

	public int getIdcardImage_credit_status() {
		return idcardImage_credit_status;
	}

	public void setIdcardImage_credit_status(int idcardImage_credit_status) {
		this.idcardImage_credit_status = idcardImage_credit_status;
	}

	public int getJdbImage_upd_tm() {
		return jdbImage_upd_tm;
	}

	public void setJdbImage_upd_tm(int jdbImage_upd_tm) {
		this.jdbImage_upd_tm = jdbImage_upd_tm;
	}

	public int getUrgent_upd_tm() {
		return urgent_upd_tm;
	}

	public void setUrgent_upd_tm(int urgent_upd_tm) {
		this.urgent_upd_tm = urgent_upd_tm;
	}

	public int getIdcardImage_upd_tm() {
		return idcardImage_upd_tm;
	}

	public void setIdcardImage_upd_tm(int idcardImage_upd_tm) {
		this.idcardImage_upd_tm = idcardImage_upd_tm;
	}

	public int getTwoElement_credit_status() {
		return twoElement_credit_status;
	}

	public void setTwoElement_credit_status(int twoElement_credit_status) {
		this.twoElement_credit_status = twoElement_credit_status;
	}

	public int getFourElement_credit_status() {
		return fourElement_credit_status;
	}

	public void setFourElement_credit_status(int fourElement_credit_status) {
		this.fourElement_credit_status = fourElement_credit_status;
	}

	public int getTwoElement_upd_tm() {
		return twoElement_upd_tm;
	}

	public void setTwoElement_upd_tm(int twoElement_upd_tm) {
		this.twoElement_upd_tm = twoElement_upd_tm;
	}

	public int getFourElement_upd_tm() {
		return fourElement_upd_tm;
	}

	public void setFourElement_upd_tm(int fourElement_upd_tm) {
		this.fourElement_upd_tm = fourElement_upd_tm;
	}
 
	public Boolean getIs_user() {
		return is_user;
	}

	public void setIs_user(Boolean is_user) {
		this.is_user = is_user;
	}

	public int getNetloanBlacklist_credit_status() {
		return netloanBlacklist_credit_status;
	}

	public void setNetloanBlacklist_credit_status(int netloanBlacklist_credit_status) {
		this.netloanBlacklist_credit_status = netloanBlacklist_credit_status;
	}

	public int getNetloanBlacklist_upd_tm() {
		return netloanBlacklist_upd_tm;
	}

	public void setNetloanBlacklist_upd_tm(int netloanBlacklist_upd_tm) {
		this.netloanBlacklist_upd_tm = netloanBlacklist_upd_tm;
	}

	public Boolean isSync_status() {
		return sync_status;
	}

	public void setSync_status(Boolean sync_status) {
		this.sync_status = sync_status;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}

	@Override
	public String toString() {
		return "UserInfo [report_id=" + report_id + ", report_no=" + report_no + ", puid=" + puid + ", ouid=" + ouid
				+ ", system_name=" + system_name + ", user_name=" + user_name + ", card_no=" + card_no + ", telephone="
				+ telephone + ", data_change=" + data_change + ", baseInfo_credit_status=" + baseInfo_credit_status
				+ ", mobile_credit_status=" + mobile_credit_status + ", skip_mobile_auth=" + skip_mobile_auth
				+ ", taobao_credit_status=" + taobao_credit_status + ", jingdong_credit_status="
				+ jingdong_credit_status + ", skip_jd_auth=" + skip_jd_auth + ", shebao_credit_status="
				+ shebao_credit_status + ", gjj_credit_status=" + gjj_credit_status + ", xuexin_credit_status="
				+ xuexin_credit_status + ", zhengxin_credit_status=" + zhengxin_credit_status + ", house_credit_status="
				+ house_credit_status + ", car_credit_status=" + car_credit_status + ", income_credit_status="
				+ income_credit_status + ", job_credit_status=" + job_credit_status + ", zhima_credit_status="
				+ zhima_credit_status + ", mobileAnalysis_credit_status=" + mobileAnalysis_credit_status
				+ ", location_credit_status=" + location_credit_status + ", multipoint_status=" + multipoint_status
				+ ", face_verify_status=" + face_verify_status + ", dishonest_credit_status=" + dishonest_credit_status
				+ ", twoElement_credit_status=" + twoElement_credit_status + ", fourElement_credit_status="
				+ fourElement_credit_status + ", alipay_credit_status=" + alipay_credit_status
				+ ", jdbImage_credit_status=" + jdbImage_credit_status + ", urgent_credit_status="
				+ urgent_credit_status + ", idcardImage_credit_status=" + idcardImage_credit_status
				+ ", student_status=" + student_status + ", bind_card=" + bind_card + ", up_special=" + up_special
				+ ", mobile_phone=" + mobile_phone + ", twoElement_upd_tm=" + twoElement_upd_tm
				+ ", fourElement_upd_tm=" + fourElement_upd_tm + ", dishonest_upd_tm=" + dishonest_upd_tm
				+ ", face_verify_upd_tm=" + face_verify_upd_tm + ", base_upd_tm=" + base_upd_tm + ", mobile_upd_tm="
				+ mobile_upd_tm + ", skip_mobile_tm=" + skip_mobile_tm + ", skip_jd_tm=" + skip_jd_tm
				+ ", taobao_upd_tm=" + taobao_upd_tm + ", jingdong_upd_tm=" + jingdong_upd_tm + ", shebao_upd_tm="
				+ shebao_upd_tm + ", gjj_upd_tm=" + gjj_upd_tm + ", xuexin_upd_tm=" + xuexin_upd_tm
				+ ", zhengxin_upd_tm=" + zhengxin_upd_tm + ", house_upd_tm=" + house_upd_tm + ", car_upd_tm="
				+ car_upd_tm + ", income_upd_tm=" + income_upd_tm + ", job_upd_tm=" + job_upd_tm
				+ ", zhima_credit_upd_tm=" + zhima_credit_upd_tm + ", mobile_analysis_upd_tm=" + mobile_analysis_upd_tm
				+ ", location_upd_tm=" + location_upd_tm + ", update_time=" + update_time + ", multipoint_upd_time="
				+ multipoint_upd_time + ", alipay_upd_tm=" + alipay_upd_tm + ", jdbImage_upd_tm=" + jdbImage_upd_tm
				+ ", urgent_upd_tm=" + urgent_upd_tm + ", idcardImage_upd_tm=" + idcardImage_upd_tm + ", create_time="
				+ create_time + "]";
	}

}

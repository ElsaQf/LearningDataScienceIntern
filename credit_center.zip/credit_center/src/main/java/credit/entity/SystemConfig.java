package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 系统配置（以后加系统密钥、系统各类回调地址）
 * @author YCM
 * @date 2019年1月16日 下午2:33:50
 */
@SuppressWarnings("serial")
@Document(indexName = "system_config", type = "credit_data", createIndex = false)
public class SystemConfig implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
    private String system_name;//系统名称
	
	@Field(type = FieldType.Text)
	private String api_return_url;//后端接口返回url
	
	@Field(type = FieldType.Text)
	private String credit_notify;//认证通知
	
	@Field(type = FieldType.Text)
	private String face_return_url;//人脸返回url（下次弃用）
	
	@Field(type = FieldType.Text)
	private String app_return_url;//前端app返回url
	
	@Field(type = FieldType.Text)
	private String wechat_return_url;//前端微信返回url
	
	@Field(type = FieldType.Text)
	private String pc_return_url;//前端pc返回url
	
	@Field(type = FieldType.Integer)
	private Integer update_time;// 更新时间
	
	@Field(type = FieldType.Integer)
	private Integer crt_tm;// 创建时间

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public String getFace_return_url() {
		return face_return_url;
	}

	public void setFace_return_url(String face_return_url) {
		this.face_return_url = face_return_url;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public Integer getCrt_tm() {
		return crt_tm;
	}

	public void setCrt_tm(Integer crt_tm) {
		this.crt_tm = crt_tm;
	}

	public String getApp_return_url() {
		return app_return_url;
	}

	public void setApp_return_url(String app_return_url) {
		this.app_return_url = app_return_url;
	}

	public String getWechat_return_url() {
		return wechat_return_url;
	}

	public void setWechat_return_url(String wechat_return_url) {
		this.wechat_return_url = wechat_return_url;
	}

	public String getPc_return_url() {
		return pc_return_url;
	}

	public void setPc_return_url(String pc_return_url) {
		this.pc_return_url = pc_return_url;
	}

	public String getApi_return_url() {
		return api_return_url;
	}

	public void setApi_return_url(String api_return_url) {
		this.api_return_url = api_return_url;
	}

	public String getCredit_notify() {
		return credit_notify;
	}

	public void setCredit_notify(String credit_notify) {
		this.credit_notify = credit_notify;
	}
	
}
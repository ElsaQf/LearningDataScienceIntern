package credit.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.SbConsume;
import credit.vo.fieldVo.SbInsurance;
import credit.vo.fieldVo.SbOverview;
import credit.vo.fieldVo.SbUserInfo;

/**
 * 社保数据
 * @author YCM
 * @date 2019年6月24日 上午11:21:53
 */
@Document(indexName = "shebao_info", type = "credit_data", createIndex = false)
public class ShebaoInfo {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Object)	
	private SbUserInfo baseInfo;//社保用户信息
	
	@Field(type = FieldType.Object)	
	private SbOverview endowment_overview;//养老保险缴费总览
	@Field(type = FieldType.Object)	
	private List<SbInsurance> endowment_insurance;//养老保险缴费记录
	
	@Field(type = FieldType.Object)	
	private SbOverview medical_overview;//医疗保险缴费总览
	@Field(type = FieldType.Object)	
	private List<SbInsurance> medical_insurance;//医疗保险缴费记录
	
	@Field(type = FieldType.Object)	
	private SbOverview unemployment_overview;//失业保险缴费总览
	@Field(type = FieldType.Object)	
	private List<SbInsurance> unemployment_insurance;//失业保险缴费记录
	
	@Field(type = FieldType.Object)	
	private SbOverview accident_overview;//工伤保险缴费总览
	@Field(type = FieldType.Object)	
	private List<SbInsurance> accident_insurance;//工伤保险缴费记录
	
	@Field(type = FieldType.Object)	
	private SbOverview maternity_overview;//生育保险缴费总览
	@Field(type = FieldType.Object)	
	private List<SbInsurance> maternity_insurance;//生育保险缴费记录
	
	@Field(type = FieldType.Object)	
	private List<SbConsume> medical_consumption;//医保消费记录
	
	@Field(type = FieldType.Text)	
	private String shebao_data;
	
	@Field(type = FieldType.Text)
    private String route_name; // 认证通道
	
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getShebao_data() {
		return shebao_data;
	}
	public void setShebao_data(String shebao_data) {
		this.shebao_data = shebao_data;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getVerson_num() {
		return verson_num;
	}
	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	public SbUserInfo getBaseInfo() {
		return baseInfo;
	}
	public void setBaseInfo(SbUserInfo baseInfo) {
		this.baseInfo = baseInfo;
	}
	public SbOverview getEndowment_overview() {
		return endowment_overview;
	}
	public void setEndowment_overview(SbOverview endowment_overview) {
		this.endowment_overview = endowment_overview;
	}
	public SbOverview getMedical_overview() {
		return medical_overview;
	}
	public void setMedical_overview(SbOverview medical_overview) {
		this.medical_overview = medical_overview;
	}
	public SbOverview getUnemployment_overview() {
		return unemployment_overview;
	}
	public void setUnemployment_overview(SbOverview unemployment_overview) {
		this.unemployment_overview = unemployment_overview;
	}
	public SbOverview getAccident_overview() {
		return accident_overview;
	}
	public void setAccident_overview(SbOverview accident_overview) {
		this.accident_overview = accident_overview;
	}
	public SbOverview getMaternity_overview() {
		return maternity_overview;
	}
	public void setMaternity_overview(SbOverview maternity_overview) {
		this.maternity_overview = maternity_overview;
	}
	public List<SbInsurance> getEndowment_insurance() {
		return endowment_insurance;
	}
	public void setEndowment_insurance(List<SbInsurance> endowment_insurance) {
		this.endowment_insurance = endowment_insurance;
	}
	public List<SbInsurance> getMedical_insurance() {
		return medical_insurance;
	}
	public void setMedical_insurance(List<SbInsurance> medical_insurance) {
		this.medical_insurance = medical_insurance;
	}
	public List<SbInsurance> getUnemployment_insurance() {
		return unemployment_insurance;
	}
	public void setUnemployment_insurance(List<SbInsurance> unemployment_insurance) {
		this.unemployment_insurance = unemployment_insurance;
	}
	public List<SbInsurance> getAccident_insurance() {
		return accident_insurance;
	}
	public void setAccident_insurance(List<SbInsurance> accident_insurance) {
		this.accident_insurance = accident_insurance;
	}
	public List<SbInsurance> getMaternity_insurance() {
		return maternity_insurance;
	}
	public void setMaternity_insurance(List<SbInsurance> maternity_insurance) {
		this.maternity_insurance = maternity_insurance;
	}
	public List<SbConsume> getMedical_consumption() {
		return medical_consumption;
	}
	public void setMedical_consumption(List<SbConsume> medical_consumption) {
		this.medical_consumption = medical_consumption;
	}
	public String getRoute_name() {
		return route_name;
	}
	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}
	 
}

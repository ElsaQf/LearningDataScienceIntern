package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.apache.http.message.BasicNameValuePair;

/*******************************************************************************
 * Copyright 2018 renrenxin, Inc. All Rights Reserved
 * credit_center
 * credit.vo
 * Created by bob on 18-7-3.
 * Description:  
 *******************************************************************************/
public class CreditRedisInfo implements Serializable {

    private static final long serialVersionUID = 2509267956030007458L;

    private String taskId;            // 任务id
    private String reportId;         // 报告id
    private String idCard;            // 身份证号
    private String username;         // 电商渠道帐号
    private String realName;        // 真实姓名
    private String password;        // 电商渠道密码
    private String taskStage;       // 任务状态
    public String nextStage;        // 任务下一步状态
    public String requestType;        //请求类型
    private int returnCode;      // 数据魔盒返回状态码
    private String returnMsg;       // 数据魔盒返回信息
    private String creditAuthPath; // 信用认证通道
    private String creditType;       // 认证项目
    public String smsCode;             // 短信验证码
    private String captcha;             // 图形验证码
    private String school;             //学校
    private List<BasicNameValuePair> requestParams; // 认证请求参数


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTaskStage() {
        return taskStage;
    }

    public void setTaskStage(String taskStage) {
        this.taskStage = taskStage;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }

    public int getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }

    public String getNextStage() {
        return nextStage;
    }

    public void setNextStage(String nextStage) {
        this.nextStage = nextStage;
    }

    public String getCreditAuthPath() {
        return creditAuthPath;
    }

    public void setCreditAuthPath(String creditAuthPath) {
        this.creditAuthPath = creditAuthPath;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public List<BasicNameValuePair> getRequestParams() {
        return requestParams;
    }

    public void setRequestParams(List<BasicNameValuePair> requestParams) {
        this.requestParams = requestParams;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}
	
}

package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.MultipointLendDetail;
@SuppressWarnings("serial")
@Document(indexName = "multipoint_lend_report", type = "credit_data", createIndex = false)
public class MultipointLendReport implements Serializable{

	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;
	
	@Field(type = FieldType.Text)
	private String trx_no; //交易代码
	
	@Field(type = FieldType.Keyword)
	private String system_name; //系统名称
	
	@Field(type = FieldType.Text)
	private String loan_success_rate;  //申贷成功率
	
	@Field(type = FieldType.Integer)
	private int loan_platform_count; //金融借贷平台数
	
	@Field(type = FieldType.Integer)
	private int badness_platform_count; //不良记录平台数
	
	@Field(type = FieldType.Integer)
	private int borrow_cnt; //借贷总次数
	
	@Field(type = FieldType.Integer)
	private int borrow_success_cnt; //成功次数
	
	@Field(type = FieldType.Integer)
	private int refuse_count; //拒贷次数
	
	@Field(type = FieldType.Integer)
	private int overdue_cnt; //逾期次数
	
	@Field(type = FieldType.Long)
	private Long overdue_amt;  //逾期金额
	
	@Field(type = FieldType.Text)
	private String return_mes;  //91返回的描述
	
	@Field(type = FieldType.Integer)
	private int audit_count;
	
	@Field(type = FieldType.Integer)
	private int status;
	
	@Field(type = FieldType.Object)
	private List<MultipointLendDetail> detailList;
	
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getTrx_no() {
		return trx_no;
	}
	public void setTrx_no(String trx_no) {
		this.trx_no = trx_no;
	}
	public String getLoan_success_rate() {
		return loan_success_rate;
	}
	public void setLoan_success_rate(String loan_success_rate) {
		this.loan_success_rate = loan_success_rate;
	}
	public int getLoan_platform_count() {
		return loan_platform_count;
	}
	public void setLoan_platform_count(int loan_platform_count) {
		this.loan_platform_count = loan_platform_count;
	}
	public int getBadness_platform_count() {
		return badness_platform_count;
	}
	public void setBadness_platform_count(int badness_platform_count) {
		this.badness_platform_count = badness_platform_count;
	}
	public int getBorrow_cnt() {
		return borrow_cnt;
	}
	public void setBorrow_cnt(int borrow_cnt) {
		this.borrow_cnt = borrow_cnt;
	}
	public int getRefuse_count() {
		return refuse_count;
	}
	public void setRefuse_count(int refuse_count) {
		this.refuse_count = refuse_count;
	}
	public int getOverdue_cnt() {
		return overdue_cnt;
	}
	public void setOverdue_cnt(int overdue_cnt) {
		this.overdue_cnt = overdue_cnt;
	}


	public Long getOverdue_amt() {
		return overdue_amt;
	}
	public void setOverdue_amt(Long overdue_amt) {
		this.overdue_amt = overdue_amt;
	}
	public String getReturn_mes() {
		return return_mes;
	}
	public void setReturn_mes(String return_mes) {
		this.return_mes = return_mes;
	}
	public int getBorrow_success_cnt() {
		return borrow_success_cnt;
	}
	public void setBorrow_success_cnt(int borrow_success_cnt) {
		this.borrow_success_cnt = borrow_success_cnt;
	}
	public int getAudit_count() {
		return audit_count;
	}
	public void setAudit_count(int audit_count) {
		this.audit_count = audit_count;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public List<MultipointLendDetail> getDetailList() {
		return detailList;
	}
	public void setDetailList(List<MultipointLendDetail> detailList) {
		this.detailList = detailList;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getVerson_num() {
		return verson_num;
	}
	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}

package credit.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.DishonestCases;

/*******************************************************************************
 * Copyright 2018 agilestar, Inc. All Rights Reserved
 * agileCloud
 * credit.vo
 * Created by bob on 18-9-27.
 * Description:  高法失信
 *******************************************************************************/
@SuppressWarnings("serial")
@Document(indexName = "dishonest_report", type = "credit_data", createIndex = false)
public class DishonestReport {

    @Id
    @Field(type = FieldType.Keyword)
    public String report_id;    // 报告id

    @Field(type = FieldType.Keyword)
    public String identity;    // 身份证
    
    @Field(type = FieldType.Keyword)
    public String name;    // 姓名
    
    @Field(type = FieldType.Object)
    public List<DishonestCases> casesList;  //失信案件详情
    
    @Field(type = FieldType.Text)
    private String route_name; // 认证通道

    @Field(type = FieldType.Integer)
    public int update_time; // 数据更新时间
    
    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }
 
    public String getRoute_name() {
        return route_name;
    }

    public void setRoute_name(String route_name) {
        this.route_name = route_name;
    }

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<DishonestCases> getCasesList() {
		return casesList;
	}

	public void setCasesList(List<DishonestCases> casesList) {
		this.casesList = casesList;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
    
}

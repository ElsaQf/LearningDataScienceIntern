package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.CallRecordDetail;
import credit.vo.fieldVo.SmsRecordDetail;

/**
 * 移动运营商存档数据信息(已拆分成三个索引：mobile_sms_raw_data、mobile_consume_raw_data、mobile_call_raw_data，新数据不再存这个索引了)
 * Title: MobileArchiveData.java 
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_archive_data", type = "credit_data", createIndex = false)
public class MobileArchiveData implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String id;
	
	@Field(type = FieldType.Keyword)
	private String user_report_id;//报告ID
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Text)
	private String cell_phone; // 本机号码
	
	private String month; //月份
	
	@Field(type = FieldType.Integer)
	private Integer total_amt; // 总费用（分）
	
	@Field(type = FieldType.Integer)
	private Integer month_call_fee; // 月费用（分）
	
	@Field(type = FieldType.Integer)
	private Integer month_call_count; // 月通话次数,用于判断后来获取的和之前已经取到的对比
	
	@Field(type = FieldType.Float)
	private Float month_call_len = 0F; // 月通话时长
	
	@Field(type = FieldType.Integer)
	private Integer month_msg_fee; // 月费用（分）
	
	@Field(type = FieldType.Integer)
	private Integer month_msg_count;//总短信次数。整形数字
	
	@Field(type = FieldType.Object)
	private List<CallRecordDetail>  call_record_detail; //通话记录
	
	@Field(type = FieldType.Object)
	private List<SmsRecordDetail>  sms_record_detail; //短信记录
	
	@Field(type = FieldType.Integer)
	private Integer update_time; // 数据获取时间

	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_report_id() {
		return user_report_id;
	}

	public void setUser_report_id(String user_report_id) {
		this.user_report_id = user_report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public String getCell_phone() {
		return cell_phone;
	}

	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Integer getTotal_amt() {
		return total_amt;
	}

	public void setTotal_amt(Integer total_amt) {
		this.total_amt = total_amt;
	}

	public Integer getMonth_call_fee() {
		return month_call_fee;
	}

	public void setMonth_call_fee(Integer month_call_fee) {
		this.month_call_fee = month_call_fee;
	}

	public Integer getMonth_call_count() {
		return month_call_count;
	}

	public void setMonth_call_count(Integer month_call_count) {
		this.month_call_count = month_call_count;
	}

	public Float getMonth_call_len() {
		return month_call_len;
	}

	public void setMonth_call_len(Float month_call_len) {
		this.month_call_len = month_call_len;
	}

	public Integer getMonth_msg_fee() {
		return month_msg_fee;
	}

	public void setMonth_msg_fee(Integer month_msg_fee) {
		this.month_msg_fee = month_msg_fee;
	}

	public Integer getMonth_msg_count() {
		return month_msg_count;
	}

	public void setMonth_msg_count(Integer month_msg_count) {
		this.month_msg_count = month_msg_count;
	}

	public List<CallRecordDetail> getCall_record_detail() {
		return call_record_detail;
	}

	public void setCall_record_detail(List<CallRecordDetail> call_record_detail) {
		this.call_record_detail = call_record_detail;
	}

	public List<SmsRecordDetail> getSms_record_detail() {
		return sms_record_detail;
	}

	public void setSms_record_detail(List<SmsRecordDetail> sms_record_detail) {
		this.sms_record_detail = sms_record_detail;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}

}
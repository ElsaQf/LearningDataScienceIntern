package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.TaobaoAddress;
import credit.vo.fieldVo.TaobaoBaseInfo;
import credit.vo.fieldVo.TaobaoOrder;

/**
 * 淘宝信息（第一风控使用，后期停用）
 */
@SuppressWarnings("serial")
@Document(indexName = "taobao_report", type = "credit_data", createIndex = false)
public class TaobaoReport implements Serializable{
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;	// 主键
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Integer)
	private Integer update_time;
		
	@Field(type = FieldType.Object)
	public TaobaoBaseInfo baseInfo; //基础信息
	
	@Field(type = FieldType.Object)
	public List<TaobaoOrder> orderList; //订单
	
	@Field(type = FieldType.Object)
	public List<TaobaoAddress> addressList; //地址

	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public TaobaoBaseInfo getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(TaobaoBaseInfo baseInfo) {
		this.baseInfo = baseInfo;
	}

	public List<TaobaoOrder> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<TaobaoOrder> orderList) {
		this.orderList = orderList;
	}

	public List<TaobaoAddress> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<TaobaoAddress> addressList) {
		this.addressList = addressList;
	}
	
}

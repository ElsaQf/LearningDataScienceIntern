package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 人脸识别 路由
 * 
 * @author YCM
 *
 */
@Document(indexName = "face_verify_route_config", type = "credit_data", createIndex = false)
public class FaceVerifyRouteConfig implements Serializable {

	@Id
	@Field(type = FieldType.Keyword)
	private String id;// id
	
	@Field(type = FieldType.Boolean)
	private boolean b_faceId;// face++通道是否启用 1:启用 0:停用
	
	@Field(type = FieldType.Boolean)
	private boolean b_webank;// 微众通道是否启用 1:启用 0:停用
	
	@Field(type = FieldType.Text)
	private String c_switch_seq; // 通道切换序列 1:face++ 2:微众
	
	@Field(type = FieldType.Integer)
	private int n_faceId_tries;// face++尝试次数
	
	@Field(type = FieldType.Integer)
	private int n_webank_tries;// 微众尝试次数
	
	@Field(type = FieldType.Integer)
	private int n_total_tries;// 所有通道尝试总次数
	
	@Field(type = FieldType.Boolean)
	private boolean b_valid;// 是否有效 1:有效 2:无效 (同一时间只能有一个配置生效)
	
	@Field(type = FieldType.Text)
	private String t_crt_tm;// 创建时间
	
	@Field(type = FieldType.Text)
	private String t_upd_tm;// 更新时间

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isB_faceId() {
		return b_faceId;
	}

	public void setB_faceId(boolean b_faceId) {
		this.b_faceId = b_faceId;
	}

	public boolean isB_webank() {
		return b_webank;
	}

	public void setB_webank(boolean b_webank) {
		this.b_webank = b_webank;
	}

	public String getC_switch_seq() {
		return c_switch_seq;
	}

	public void setC_switch_seq(String c_switch_seq) {
		this.c_switch_seq = c_switch_seq;
	}

	public int getN_faceId_tries() {
		return n_faceId_tries;
	}

	public void setN_faceId_tries(int n_faceId_tries) {
		this.n_faceId_tries = n_faceId_tries;
	}

	public int getN_webank_tries() {
		return n_webank_tries;
	}

	public void setN_webank_tries(int n_webank_tries) {
		this.n_webank_tries = n_webank_tries;
	}

	public int getN_total_tries() {
		return n_total_tries;
	}

	public void setN_total_tries(int n_total_tries) {
		this.n_total_tries = n_total_tries;
	}

	public boolean isB_valid() {
		return b_valid;
	}

	public void setB_valid(boolean b_valid) {
		this.b_valid = b_valid;
	}

	public String getT_crt_tm() {
		return t_crt_tm;
	}

	public void setT_crt_tm(String t_crt_tm) {
		this.t_crt_tm = t_crt_tm;
	}

	public String getT_upd_tm() {
		return t_upd_tm;
	}

	public void setT_upd_tm(String t_upd_tm) {
		this.t_upd_tm = t_upd_tm;
	}
}
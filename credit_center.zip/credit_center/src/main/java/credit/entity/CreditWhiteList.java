package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 授信路由
 * @author YCM
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "credit_white_list", type = "credit_data")
public class CreditWhiteList implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
    private String telephone;//id

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
}

package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.BlacklistDetail;
import credit.vo.fieldVo.NetloanData;

/**
 * 网贷、黑名单数据
 */
@SuppressWarnings("serial")
@Document(indexName = "netloan_blacklist_data", type = "credit_data", createIndex = false)
public class NetloanBlacklistData implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;//主键
	 
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Object)
	private List<BlacklistDetail> blacklist_data;//黑名单
	
	@Field(type = FieldType.Object)
	private List<NetloanData> netloan_data;//网贷
	
	@Field(type = FieldType.Integer)
	private Integer update_time;

	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public List<BlacklistDetail> getBlacklist_data() {
		return blacklist_data;
	}

	public void setBlacklist_data(List<BlacklistDetail> blacklist_data) {
		this.blacklist_data = blacklist_data;
	}

	public List<NetloanData> getNetloan_data() {
		return netloan_data;
	}

	public void setNetloan_data(List<NetloanData> netloan_data) {
		this.netloan_data = netloan_data;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}

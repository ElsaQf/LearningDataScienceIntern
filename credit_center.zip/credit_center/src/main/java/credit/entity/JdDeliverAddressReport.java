package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.JdDeliverAddress;

/**
 * 京东电商地址
 * @author YCM
 * @date 2019年4月25日 下午6:29:10
 */

@SuppressWarnings("serial")
@Document(indexName = "deliver_address_report", type = "credit_data", createIndex = false)
public class JdDeliverAddressReport implements Serializable {

    @Id
    @Field(type = FieldType.Keyword)
    public String report_id;    // 报告id

    /**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
    @Field(type = FieldType.Integer)
    public int update_time; // 数据更新时间

    @Field(type = FieldType.Object)
    public List<JdDeliverAddress> deliver_addresse_list;   // 电商地址信息

    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public List<JdDeliverAddress> getDeliver_addresse_list() {
        return deliver_addresse_list;
    }

    public void setDeliver_addresse_list(List<JdDeliverAddress> deliver_addresse_list) {
        this.deliver_addresse_list = deliver_addresse_list;
    }

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}

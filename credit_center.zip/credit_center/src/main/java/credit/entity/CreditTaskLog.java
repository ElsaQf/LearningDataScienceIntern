package credit.entity;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 第三方认证日志
 * @author yuan
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "credit_task_log", type = "credit_data", createIndex = false)
public class CreditTaskLog implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
	private String task_id;//任务id
	
	@Field(type = FieldType.Keyword)
    private String user_report_id;//报告id
	
	@Field(type = FieldType.Keyword)
    private String system_name;
	
	@Field(type = FieldType.Text)
    private String user_name;
	
	@Field(type = FieldType.Text)
    private String telephone;
	
	@Field(type = FieldType.Text)
    private String card_no; // 身份证号
	
	@Field(type = FieldType.Text)
    private String route_name; // 认证通道

	@Field(type = FieldType.Text)
    private String business_no; // 第三方业务订单号

	@Field(type = FieldType.Integer)
    private int status; //const.credit_auth_task_status

	@Field(type = FieldType.Text)
    private String fail_reason; //失败原因
	
	@Field(type = FieldType.Text)
    private Integer fail_code; //第三方失败编码
	
	@Field(type = FieldType.Integer)
    private Integer fail_type;//失败类型：0.用户操作错误  1.第三方错误
	
	@Field(type = FieldType.Integer)
    private int credit_type;//认证类型 

	@Field(type = FieldType.Boolean)
    private boolean skip_mobile_auth;//是否跳过运营商
	
	@Field(type = FieldType.Integer)
    private int taskCount;//记录执行定时任务的次数
	
	@Field(type = FieldType.Integer)
	private Integer source_type;//人脸入口来源（今借到有两个人脸入口（1：九宫格  2：极速借条实名））
	
	@Field(type = FieldType.Integer)
	private Integer app_type;//认证应用类型（1：app 2:微信  3：pc）
	
	@Field(type = FieldType.Text)
	private String task_params;//任务参数（原样返回给业务系统）
	
	@Field(type = FieldType.Text) //跳转URL后缀（第一风控每次返回的url不一样，把不一样的放在这）
	private String return_url_suffix;
	
	@Field(type = FieldType.Integer)
	private int verify_success_time;//验证成功时间（可以爬取了）
	
	@Field(type = FieldType.Integer)
    private int update_time;//创建时间
	
	@Field(type = FieldType.Date)
    private Date update_tm;//创建时间

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public String getUser_report_id() {
		return user_report_id;
	}

	public void setUser_report_id(String user_report_id) {
		this.user_report_id = user_report_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getCard_no() {
		return card_no;
	}

	public void setCard_no(String card_no) {
		this.card_no = card_no;
	}

	public String getRoute_name() {
		return route_name;
	}

	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}

	public String getBusiness_no() {
		return business_no;
	}

	public void setBusiness_no(String business_no) {
		this.business_no = business_no;
	}

	public String getFail_reason() {
		return fail_reason;
	}

	public void setFail_reason(String fail_reason) {
		this.fail_reason = fail_reason;
	}

	public Integer getFail_code() {
		return fail_code;
	}

	public void setFail_code(Integer fail_code) {
		this.fail_code = fail_code;
	}

	public Integer getFail_type() {
		return fail_type;
	}

	public void setFail_type(Integer fail_type) {
		this.fail_type = fail_type;
	}

	public int getCredit_type() {
		return credit_type;
	}

	public void setCredit_type(int credit_type) {
		this.credit_type = credit_type;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public boolean isSkip_mobile_auth() {
		return skip_mobile_auth;
	}

	public void setSkip_mobile_auth(boolean skip_mobile_auth) {
		this.skip_mobile_auth = skip_mobile_auth;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Date getUpdate_tm() {
		return update_tm;
	}

	public void setUpdate_tm(Date update_tm) {
		this.update_tm = update_tm;
	}

	public int getTaskCount() {
		return taskCount;
	}

	public void setTaskCount(int taskCount) {
		this.taskCount = taskCount;
	}

	
	public Integer getSource_type() {
		return source_type;
	}

	public void setSource_type(Integer source_type) {
		this.source_type = source_type;
	}

	public Integer getApp_type() {
		return app_type;
	}

	public void setApp_type(Integer app_type) {
		this.app_type = app_type;
	}

	public String getTask_params() {
		return task_params;
	}

	public void setTask_params(String task_params) {
		this.task_params = task_params;
	}

	public String getReturn_url_suffix() {
		return return_url_suffix;
	}

	public void setReturn_url_suffix(String return_url_suffix) {
		this.return_url_suffix = return_url_suffix;
	}

	public int getVerify_success_time() {
		return verify_success_time;
	}

	public void setVerify_success_time(int verify_success_time) {
		this.verify_success_time = verify_success_time;
	}

	@Override
	public String toString() {
		return "CreditTaskLog [task_id=" + task_id + ", user_report_id=" + user_report_id + ", system_name="
				+ system_name + ", user_name=" + user_name + ", telephone=" + telephone + ", card_no=" + card_no
				+ ", route_name=" + route_name + ", business_no=" + business_no + ", status=" + status
				+ ", fail_reason=" + fail_reason + ", fail_code=" + fail_code + ", fail_type=" + fail_type
				+ ", credit_type=" + credit_type + ", skip_mobile_auth=" + skip_mobile_auth + ", taskCount=" + taskCount
				+ ", source_type=" + source_type + ", app_type=" + app_type + ", task_params=" + task_params
				+ ", update_time=" + update_time + ", update_tm=" + update_tm + "]";
	}
	
}

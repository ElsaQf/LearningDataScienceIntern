package credit.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 已改为mobile_analyze_report0索引，新数据不再存这个索引了
 * @author YCM
 * @date 2019年6月5日 上午11:38:10
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_analyze_report", type = "credit_data", createIndex = false)
public class MobileAnalyzeReport {

    @Id
    @Field(type = FieldType.Keyword)
    private String report_id;//报告ID

    /**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
    private String system_name;
	
    @Field(type = FieldType.Text)
    private String  analyze_data; // 分析报告数据

    @Field(type = FieldType.Text)
    private String route_name; // 认证通道

    @Field(type = FieldType.Integer)
    private int update_time;

    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public String getAnalyze_data() {
        return analyze_data;
    }

    public void setAnalyze_data(String analyze_data) {
        this.analyze_data = analyze_data;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public String getRoute_name() {
        return route_name;
    }

    public void setRoute_name(String route_name) {
        this.route_name = route_name;
    }

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
    
}

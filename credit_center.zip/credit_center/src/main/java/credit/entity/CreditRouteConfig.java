package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 授信路由(除运营商外)
 * @author YCM
 *
 */
@SuppressWarnings("serial")
@Document(indexName = "credit_route_config", type = "credit_data", createIndex = false)
public class CreditRouteConfig implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
	private String credit_name;
	
	@Field(type = FieldType.Text)
	private String route_name; // 通道切换序列 1:face++ 2:微众
	
	@Field(type = FieldType.Boolean)
	private boolean valid;

	public String getCredit_name() {
		return credit_name;
	}

	public void setCredit_name(String credit_name) {
		this.credit_name = credit_name;
	}

	public String getRoute_name() {
		return route_name;
	}

	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean valid) {
		this.valid = valid;
	}
	
}

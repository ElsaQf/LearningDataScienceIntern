package credit.entity;

import java.io.Serializable;

/**
 * 抓取授信数据过程中保存的redis存储信息 Title: CreditRedisInfo.java Description
 * 
 * @date 2018年7月2日
 * @version 1.0
 */
@SuppressWarnings("serial")
public class MobileCreditRedisInfo implements Serializable {

	private String report_id; // 报告ID
	private String task_id; // 报告ID
	private String mobile_Phone; // 运营商认证的手机号
	private String mobile_Password; // 运营商认证的手机服务密码
	private int mobile_return_code;// 运营商返回码
	private String mobile_return_msg;// 运营商返回信息
	private String mobile_next_stage;// 下一个阶段。比如next_stage是"LOGIN"，那么继续调用登录验证接口，task_stage输入"LOGIN"
	private String credit_auth_path; // 信用认证通道
	private String credit_type; // 认证项目
	private int verify_type;// 验证方式 0.短信 1.图片 2.短信+图片
	private String jxl_verify_type;// 聚信立验证方式 SUBMIT_CAPTCHA（提交短信验证码）RESEND_CAPTCHA（重发短信验证码）SUBMIT_QUERY_PWD（提交查询密码）【仅北京移动会出现】
	private String location_code;//归属地编码
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getMobile_Phone() {
		return mobile_Phone;
	}

	public void setMobile_Phone(String mobile_Phone) {
		this.mobile_Phone = mobile_Phone;
	}

	public String getMobile_Password() {
		return mobile_Password;
	}

	public void setMobile_Password(String mobile_Password) {
		this.mobile_Password = mobile_Password;
	}

	public String getCredit_auth_path() {
		return credit_auth_path;
	}

	public void setCredit_auth_path(String credit_auth_path) {
		this.credit_auth_path = credit_auth_path;
	}

	public String getCredit_type() {
		return credit_type;
	}

	public void setCredit_type(String credit_type) {
		this.credit_type = credit_type;
	}

	public int getMobile_return_code() {
		return mobile_return_code;
	}

	public void setMobile_return_code(int mobile_return_code) {
		this.mobile_return_code = mobile_return_code;
	}

	public String getMobile_return_msg() {
		return mobile_return_msg;
	}

	public void setMobile_return_msg(String mobile_return_msg) {
		this.mobile_return_msg = mobile_return_msg;
	}

	public String getMobile_next_stage() {
		return mobile_next_stage;
	}

	public void setMobile_next_stage(String mobile_next_stage) {
		this.mobile_next_stage = mobile_next_stage;
	} 

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public int getVerify_type() {
		return verify_type;
	}

	public void setVerify_type(int verify_type) {
		this.verify_type = verify_type;
	}

	public String getLocation_code() {
		return location_code;
	}

	public void setLocation_code(String location_code) {
		this.location_code = location_code;
	}

	public String getJxl_verify_type() {
		return jxl_verify_type;
	}

	public void setJxl_verify_type(String jxl_verify_type) {
		this.jxl_verify_type = jxl_verify_type;
	}
	
}
package credit.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 借贷宝逾期数据
 * @author: YCM
 * @date: 2018-11-30
 **/
@Document(indexName = "jdb_overdue_data", type = "credit_data", createIndex = false)
public class JdbOverdueData {

    @Id
    @Field(type = FieldType.Keyword)
    private String report_id;// 主键
    @Field(type = FieldType.Keyword)
    private String system_name;
    @Field(type = FieldType.Text)
    private String task_id;//查询id
    @Field(type = FieldType.Text)
    private String	is_high_risk_user;//是否高风险用户：无|1（是）|0（否），1表示命中了风控标签，包括刷信用、高利贷、收押金、小贷公司、小号等
    @Field(type = FieldType.Text)
    private String	last_visit_dt;//最近一次访问日期
    @Field(type = FieldType.Text)
    private String	thirty_overdue_cnt;//30天以上逾期次数：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	his_overdue_amt;//历史逾期金额：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	last_overdue_dt;//最近一次逾期时间	：最近一次逾期时间
    @Field(type = FieldType.Text)
    private String	last_overdue_amt;//最近一次逾期金额：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	curr_overdue_amt;//当前逾期金额：	无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	curr_overdue_days;//当前逾期最大天数：	0|D1|D3|W1|W2|M1|M2|M3|M6
    @Field(type = FieldType.Text)
    private String	first_overdue_dt;//首次逾期时间：	2017/10/4
    @Field(type = FieldType.Text)
    private String	first_overdue_amt;//首次逾期金额：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	last_repay_tm;//最近一次还款时间：	2017/10/2 21:46
    @Field(type = FieldType.Text)
    private String	repay_times;//总还款次数：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	curr_debt_product_cnt;//正在进行的贷款笔数：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	total_in_order_cnt;//历史贷款笔数：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Text)
    private String	total_in_order_amt;//历史总借款金额：无|极低|较低|低|中|高|较高|极高
    @Field(type = FieldType.Integer)
    private Integer update_time;
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
	public String getIs_high_risk_user() {
		return is_high_risk_user;
	}
	public void setIs_high_risk_user(String is_high_risk_user) {
		this.is_high_risk_user = is_high_risk_user;
	}
	public String getLast_visit_dt() {
		return last_visit_dt;
	}
	public void setLast_visit_dt(String last_visit_dt) {
		this.last_visit_dt = last_visit_dt;
	}
	public String getThirty_overdue_cnt() {
		return thirty_overdue_cnt;
	}
	public void setThirty_overdue_cnt(String thirty_overdue_cnt) {
		this.thirty_overdue_cnt = thirty_overdue_cnt;
	}
	public String getHis_overdue_amt() {
		return his_overdue_amt;
	}
	public void setHis_overdue_amt(String his_overdue_amt) {
		this.his_overdue_amt = his_overdue_amt;
	}
	public String getLast_overdue_dt() {
		return last_overdue_dt;
	}
	public void setLast_overdue_dt(String last_overdue_dt) {
		this.last_overdue_dt = last_overdue_dt;
	}
	public String getLast_overdue_amt() {
		return last_overdue_amt;
	}
	public void setLast_overdue_amt(String last_overdue_amt) {
		this.last_overdue_amt = last_overdue_amt;
	}
	public String getCurr_overdue_amt() {
		return curr_overdue_amt;
	}
	public void setCurr_overdue_amt(String curr_overdue_amt) {
		this.curr_overdue_amt = curr_overdue_amt;
	}
	public String getCurr_overdue_days() {
		return curr_overdue_days;
	}
	public void setCurr_overdue_days(String curr_overdue_days) {
		this.curr_overdue_days = curr_overdue_days;
	}
	public String getFirst_overdue_dt() {
		return first_overdue_dt;
	}
	public void setFirst_overdue_dt(String first_overdue_dt) {
		this.first_overdue_dt = first_overdue_dt;
	}
	public String getFirst_overdue_amt() {
		return first_overdue_amt;
	}
	public void setFirst_overdue_amt(String first_overdue_amt) {
		this.first_overdue_amt = first_overdue_amt;
	}
	public String getLast_repay_tm() {
		return last_repay_tm;
	}
	public void setLast_repay_tm(String last_repay_tm) {
		this.last_repay_tm = last_repay_tm;
	}
	public String getRepay_times() {
		return repay_times;
	}
	public void setRepay_times(String repay_times) {
		this.repay_times = repay_times;
	}
	public String getCurr_debt_product_cnt() {
		return curr_debt_product_cnt;
	}
	public void setCurr_debt_product_cnt(String curr_debt_product_cnt) {
		this.curr_debt_product_cnt = curr_debt_product_cnt;
	}
	public String getTotal_in_order_cnt() {
		return total_in_order_cnt;
	}
	public void setTotal_in_order_cnt(String total_in_order_cnt) {
		this.total_in_order_cnt = total_in_order_cnt;
	}
	public String getTotal_in_order_amt() {
		return total_in_order_amt;
	}
	public void setTotal_in_order_amt(String total_in_order_amt) {
		this.total_in_order_amt = total_in_order_amt;
	}
	public String getTask_id() {
		return task_id;
	}
	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}
    
}

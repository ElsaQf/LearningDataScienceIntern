package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.util.gxb.ecommerce.EcommerceFeesAccountDTO;
import credit.util.gxb.ecommerce.EcommerceTransferBankCardDTO;
import credit.util.gxb.ecommerce.MyBankAssetDetailDTO;
import credit.util.gxb.ecommerce.MyBankBindInfoDTO;
import credit.util.gxb.ecommerce.MyBankLoanDetailDTO;
import credit.util.gxb.ecommerce.MyBankRepayPlanDTO;
import credit.util.gxb.ecommerce.ZmCredit;
import credit.vo.fieldVo.AlipayBadRecord;
import credit.vo.fieldVo.AlipayBalanceData;
import credit.vo.fieldVo.AlipayBankCardList;
import credit.vo.fieldVo.AlipayBillList;
import credit.vo.fieldVo.AlipayHuabei;
import credit.vo.fieldVo.AlipayJiebei;
import credit.vo.fieldVo.AlipayPersonInfo;
import credit.vo.fieldVo.AlipayZhima;

/**
 * 支付宝数据
 * @author: yuetongfei
 * @date: 2018-11-30
 **/
@SuppressWarnings("serial")
@Document(indexName = "alipay_data", type = "credit_data", createIndex = false)
public class AlipayData implements Serializable{

    @Id
    @Field(type = FieldType.Keyword)
    private String report_id;	// 主键

    @Field(type = FieldType.Keyword)
    private String system_name;

    @Field(type = FieldType.Integer)
    private Integer update_time;
    
    @Field(type = FieldType.Object)
    private AlipayPersonInfo person_info; // 个人信息
    
    @Field(type = FieldType.Object)
    private AlipayBalanceData balance_data; // 资产

    @Field(type = FieldType.Object)
    private AlipayHuabei huabei; // 花呗
    
    @Field(type = FieldType.Object)
    private AlipayBillList pay_bill_list; // 消费记录

    @Field(type = FieldType.Object)
    private AlipayZhima zhima_data; // 芝麻分

    @Field(type = FieldType.Object)
    private List<ZmCredit> zmCreditList;
    
    @Field(type = FieldType.Object)
    private List<AlipayBadRecord> bad_credit_recoder; // 负面记录

    @Field(type = FieldType.Object)
    private AlipayJiebei jiebei; // 借呗

    @Field(type = FieldType.Object)
    private List<AlipayBankCardList> bank_card_list; // 银行卡列表
    
    @Field(type = FieldType.Object)
    private List<EcommerceFeesAccountDTO> ecommercePaymentAccounts; //水电煤缴费账户字段
    
    @Field(type = FieldType.Object)
    private List<EcommerceTransferBankCardDTO> transferBankCards; //历史转账银行储蓄卡
    
    @Field(type = FieldType.Object)
    private MyBankBindInfoDTO myBankBindInfo; //网商贷绑定信息
    
    @Field(type = FieldType.Object)
    private List<MyBankLoanDetailDTO> myBankLoanDetails;//网商贷近一年借款明细
    
    @Field(type = FieldType.Object)
    private List<MyBankAssetDetailDTO> myBankAssetDetails;//网商贷近三个月资金明细
    
    @Field(type = FieldType.Object)
    private List<MyBankRepayPlanDTO> myBankRepayPlanList;//网商贷近一年还款计划明细
    
    @Field(type = FieldType.Text)
    private String route_name; // 认证通道
    
    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public String getSystem_name() {
        return system_name;
    }

    public void setSystem_name(String system_name) {
        this.system_name = system_name;
    }

    public Integer getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Integer update_time) {
        this.update_time = update_time;
    }

	public AlipayHuabei getHuabei() {
        return huabei;
    }

    public void setHuabei(AlipayHuabei huabei) {
        this.huabei = huabei;
    }

    public AlipayZhima getZhima_data() {
        return zhima_data;
    }

    public void setZhima_data(AlipayZhima zhima_data) {
        this.zhima_data = zhima_data;
    }

    public List<AlipayBadRecord> getBad_credit_recoder() {
        return bad_credit_recoder;
    }

    public void setBad_credit_recoder(List<AlipayBadRecord> bad_credit_recoder) {
        this.bad_credit_recoder = bad_credit_recoder;
    }

    public AlipayJiebei getJiebei() {
        return jiebei;
    }

    public void setJiebei(AlipayJiebei jiebei) {
        this.jiebei = jiebei;
    }

    public AlipayBillList getPay_bill_list() {
        return pay_bill_list;
    }

    public void setPay_bill_list(AlipayBillList pay_bill_list) {
        this.pay_bill_list = pay_bill_list;
    }

    public AlipayBalanceData getBalance_data() {
        return balance_data;
    }

    public void setBalance_data(AlipayBalanceData balance_data) {
        this.balance_data = balance_data;
    }

    public AlipayPersonInfo getPerson_info() {
        return person_info;
    }

    public void setPerson_info(AlipayPersonInfo person_info) {
        this.person_info = person_info;
    }

    public List<AlipayBankCardList> getBank_card_list() {
        return bank_card_list;
    }

    public void setBank_card_list(List<AlipayBankCardList> bank_card_list) {
        this.bank_card_list = bank_card_list;
    }

	public String getRoute_name() {
		return route_name;
	}

	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}

	public List<EcommerceFeesAccountDTO> getEcommercePaymentAccounts() {
		return ecommercePaymentAccounts;
	}

	public void setEcommercePaymentAccounts(List<EcommerceFeesAccountDTO> ecommercePaymentAccounts) {
		this.ecommercePaymentAccounts = ecommercePaymentAccounts;
	}

	public List<EcommerceTransferBankCardDTO> getTransferBankCards() {
		return transferBankCards;
	}

	public void setTransferBankCards(List<EcommerceTransferBankCardDTO> transferBankCards) {
		this.transferBankCards = transferBankCards;
	}

	public MyBankBindInfoDTO getMyBankBindInfo() {
		return myBankBindInfo;
	}

	public void setMyBankBindInfo(MyBankBindInfoDTO myBankBindInfo) {
		this.myBankBindInfo = myBankBindInfo;
	}

	public List<MyBankLoanDetailDTO> getMyBankLoanDetails() {
		return myBankLoanDetails;
	}

	public void setMyBankLoanDetails(List<MyBankLoanDetailDTO> myBankLoanDetails) {
		this.myBankLoanDetails = myBankLoanDetails;
	}

	public List<MyBankAssetDetailDTO> getMyBankAssetDetails() {
		return myBankAssetDetails;
	}

	public void setMyBankAssetDetails(List<MyBankAssetDetailDTO> myBankAssetDetails) {
		this.myBankAssetDetails = myBankAssetDetails;
	}

	public List<MyBankRepayPlanDTO> getMyBankRepayPlanList() {
		return myBankRepayPlanList;
	}

	public void setMyBankRepayPlanList(List<MyBankRepayPlanDTO> myBankRepayPlanList) {
		this.myBankRepayPlanList = myBankRepayPlanList;
	}

	public List<ZmCredit> getZmCreditList() {
		return zmCreditList;
	}

	public void setZmCreditList(List<ZmCredit> zmCreditList) {
		this.zmCreditList = zmCreditList;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
    
}

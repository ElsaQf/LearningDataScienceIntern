package credit.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.BrApplyLoanReport;

/**
 * 百融黑名单
 * @author YCM
 * @date 2019年3月29日 下午1:55:27
 */
@Document(indexName = "br_apply_loan_data", type = "credit_data", createIndex = false)
public class BrApplyLoanData {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;//主键
	 
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Integer)
	private int credit_status;//认证状态
	
	@Field(type = FieldType.Text)
	private String task_id;
	
	@Field(type = FieldType.Object)
	private List<BrApplyLoanReport> apply_loan_report;
	
	@Field(type = FieldType.Integer)
	private Integer update_time;

	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public List<BrApplyLoanReport> getApply_loan_report() {
		return apply_loan_report;
	}

	public void setApply_loan_report(List<BrApplyLoanReport> apply_loan_report) {
		this.apply_loan_report = apply_loan_report;
	}

	public Integer getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}

	public int getCredit_status() {
		return credit_status;
	}

	public void setCredit_status(int credit_status) {
		this.credit_status = credit_status;
	}
	
}

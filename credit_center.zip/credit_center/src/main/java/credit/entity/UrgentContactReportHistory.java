package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.UrgentContactDetail;
 
/**
 * 紧急联系人详细分析
 * @author YCM
 * @date 2018年7月11日 上午11:46:10
 */
@SuppressWarnings("serial")
@Document(indexName = "urgent_contact_report_history", type = "credit_data", createIndex = false)
public class UrgentContactReportHistory implements Serializable{
	@Id
	@Field(type = FieldType.Keyword)
    private String id;//id
	
	@Field(type = FieldType.Keyword)
    private String user_report_id;//报告id
	
	/**
	 * 系统名称（便于分系统处理数据）
	 */
	@Field(type = FieldType.Keyword)
	private String system_name;
	
	@Field(type = FieldType.Object)
	private List<UrgentContactDetail> contactDetail;//紧急联系人详细分析

	@Field(type = FieldType.Integer)
    private int update_time;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_report_id() {
		return user_report_id;
	}

	public void setUser_report_id(String user_report_id) {
		this.user_report_id = user_report_id;
	}

	public List<UrgentContactDetail> getContactDetail() {
		return contactDetail;
	}

	public void setContactDetail(List<UrgentContactDetail> contactDetail) {
		this.contactDetail = contactDetail;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
 
}

package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.ChsiReportInfo;
import credit.vo.parmVo.EducationRawInfo;
import credit.vo.parmVo.SchoolRawInfo;

/**
 * 学信数据
 * @author YCM
 * @date 2019年6月19日 下午5:38:23
 */
@SuppressWarnings("serial")
@Document(indexName = "student_info_report", type = "credit_data", createIndex = false)
public class StudentInfoReport implements Serializable {

    @Id
    @Field(type = FieldType.Keyword)
    private String report_id;    // 报告id
 
	@Field(type = FieldType.Keyword)
    private String system_name;

	@Field(type = FieldType.Text)
    private String edu_level;
	
    @Field(type = FieldType.Object)
    private List<ChsiReportInfo> student_info_list;  //学信报告信息

    @Field(type = FieldType.Object)
    private List<EducationRawInfo> education_info;//原始学历信息

    @Field(type = FieldType.Object)
    private List<SchoolRawInfo> school_info ;//原始学籍信息
    
    @Field(type = FieldType.Integer)
    private int update_time;   // 更新时间
    
    @Field(type = FieldType.Integer)
    private Integer version_type;//版本号：第一风控的老数据改为版本2
    
    @Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
    
    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public int getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(int update_time) {
        this.update_time = update_time;
    }

    public List<ChsiReportInfo> getStudent_info_list() {
        return student_info_list;
    }

    public void setStudent_info_list(List<ChsiReportInfo> student_info_list) {
        this.student_info_list = student_info_list;
    }

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public List<EducationRawInfo> getEducation_info() {
		return education_info;
	}

	public void setEducation_info(List<EducationRawInfo> education_info) {
		this.education_info = education_info;
	}

	public List<SchoolRawInfo> getSchool_info() {
		return school_info;
	}

	public void setSchool_info(List<SchoolRawInfo> school_info) {
		this.school_info = school_info;
	}

	public String getEdu_level() {
		return edu_level;
	}

	public void setEdu_level(String edu_level) {
		this.edu_level = edu_level;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}

	public Integer getVersion_type() {
		return version_type;
	}

	public void setVersion_type(Integer version_type) {
		this.version_type = version_type;
	}
	
}

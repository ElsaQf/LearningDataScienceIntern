package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 认证尝试时间（授权成功到抓取到数据的最大尝试时间，如果到达尝试时间，还未抓到数据，则认证失败）
 * 单位：秒
 * @author YCM
 */
@SuppressWarnings("serial")
@Document(indexName = "credit_try_time", type = "credit_data", createIndex = false)
public class CreditTryTime implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
    private String id;//id
	@Field(type = FieldType.Integer)
	private int mobile_try_time;//运营商尝试时间
	@Field(type = FieldType.Integer)
	private int shebao_try_time;//社保尝试时间
	@Field(type = FieldType.Integer)
	private int gjj_try_time;//公积金尝试时间
	@Field(type = FieldType.Integer)
	private int chsi_try_time;//学信尝试时间
	@Field(type = FieldType.Boolean)
	private boolean valid;//是否合法
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getMobile_try_time() {
		return mobile_try_time;
	}
	public void setMobile_try_time(int mobile_try_time) {
		this.mobile_try_time = mobile_try_time;
	}
	public int getShebao_try_time() {
		return shebao_try_time;
	}
	public void setShebao_try_time(int shebao_try_time) {
		this.shebao_try_time = shebao_try_time;
	}
	public int getGjj_try_time() {
		return gjj_try_time;
	}
	public void setGjj_try_time(int gjj_try_time) {
		this.gjj_try_time = gjj_try_time;
	}
	public int getChsi_try_time() {
		return chsi_try_time;
	}
	public void setChsi_try_time(int chsi_try_time) {
		this.chsi_try_time = chsi_try_time;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	 
}

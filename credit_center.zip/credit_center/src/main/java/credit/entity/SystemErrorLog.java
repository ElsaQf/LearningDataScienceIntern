package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 错误日志表
 * @author YCM
 * @date 2018年7月19日 下午4:38:56
 */
@SuppressWarnings("serial")
@Document(indexName = "system_error_log", type = "credit_data", createIndex = false)
public class SystemErrorLog implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String id;

	@Field(type = FieldType.Keyword)
	private String user_report_id; // 用户ID

	@Field(type = FieldType.Text)
	private String error_detail; // 错误详情

	@Field(type = FieldType.Text)
    private String error_time;//创建时间

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_report_id() {
		return user_report_id;
	}

	public void setUser_report_id(String user_report_id) {
		this.user_report_id = user_report_id;
	}

	public String getError_detail() {
		return error_detail;
	}

	public void setError_detail(String error_detail) {
		this.error_detail = error_detail;
	}

	public String getError_time() {
		return error_time;
	}

	public void setError_time(String error_time) {
		this.error_time = error_time;
	}

}

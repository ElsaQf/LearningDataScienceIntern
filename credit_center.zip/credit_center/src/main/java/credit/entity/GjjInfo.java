package credit.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.GjjBillRecord;
import credit.vo.fieldVo.GjjUserInfo;
/**
 * 公积金信息
 * @author YCM
 * @date 2019年6月26日 上午10:40:01
 */
@Document(indexName = "gjj_info", type = "credit_data", createIndex = false)
public class GjjInfo {
	@Id
	@Field(type = FieldType.Keyword)	
	private String report_id;
	@Field(type = FieldType.Keyword)
    private String system_name;
	@Field(type = FieldType.Text)
	private String route_name;
	
	@Field(type = FieldType.Object)	
	private GjjUserInfo user_info;
	
	@Field(type = FieldType.Object)	
	private List<GjjBillRecord> bill_record;
	
	@Field(type = FieldType.Text)	
	private String gjj_data;
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getGjj_data() {
		return gjj_data;
	}
	public void setGjj_data(String gjj_data) {
		this.gjj_data = gjj_data;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getVerson_num() {
		return verson_num;
	}
	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	public String getRoute_name() {
		return route_name;
	}
	public void setRoute_name(String route_name) {
		this.route_name = route_name;
	}
	public GjjUserInfo getUser_info() {
		return user_info;
	}
	public void setUser_info(GjjUserInfo user_info) {
		this.user_info = user_info;
	}
	public List<GjjBillRecord> getBill_record() {
		return bill_record;
	}
	public void setBill_record(List<GjjBillRecord> bill_record) {
		this.bill_record = bill_record;
	}
	
}

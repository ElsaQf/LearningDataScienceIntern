package credit.entity;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.fieldVo.MobileBillDetail;

/**
 * 移动运营商账单信息
 * Title: EBasicInfo.java 
 * @version 1.0
 */
@SuppressWarnings("serial")
@Document(indexName = "mobile_bill_report", type = "credit_data", createIndex = false)
public class MobileBillReport implements Serializable {
	@Id
	@Field(type = FieldType.Text)
	private String report_id;//报告ID
	
	@Field(type = FieldType.Keyword)
    private String system_name;
	 
	@Field(type = FieldType.Object)
    private List<MobileBillDetail> report_bill_list;
	
	@Field(type = FieldType.Integer)
	private int update_time; // 数据获取时间

	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2,版本5以后的数据
	
	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public int getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(int update_time) {
		this.update_time = update_time;
	}

	public List<MobileBillDetail> getReport_bill_list() {
		return report_bill_list;
	}

	public void setReport_bill_list(List<MobileBillDetail> report_bill_list) {
		this.report_bill_list = report_bill_list;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getVerson_num() {
		return verson_num;
	}

	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
    
}
package credit.entity;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 二要素认证
 * @author YCM
 * @date 2018年11月27日 上午10:15:23
 */
@Document(indexName = "idcard_cert_info", type = "credit_data", createIndex = false)
public class IdCardCertInfo implements Serializable  {
	@Id
	@Field(type = FieldType.Keyword)
	private String id;//身份证和名字hashid加密做主键
	@Field(type = FieldType.Keyword)
	private String system_name;
	@Field(type = FieldType.Text)
    private String idCard;//身份证
	@Field(type = FieldType.Text)
	private String name;// 姓名
	@Field(type = FieldType.Text)
	private String sex;//性别
	@Field(type = FieldType.Text)
    private String area;//身份证所在地(参考)
	@Field(type = FieldType.Text)
    private String province;//省
	@Field(type = FieldType.Text)
    private String city;//市
	@Field(type = FieldType.Text)
    private String prefecture;//区县
	@Field(type = FieldType.Text)
    private String birthday;//出生年月
	@Field(type = FieldType.Text)
    private String addrCode;//地区代码
	@Field(type = FieldType.Text)
    private String lastCode;///身份证校验码
	@Field(type = FieldType.Keyword)
    private String route_type; //认证通道
	@Field(type = FieldType.Integer)
	private int create_time; //创建时间
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	 
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPrefecture() {
		return prefecture;
	}
	public void setPrefecture(String prefecture) {
		this.prefecture = prefecture;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getAddrCode() {
		return addrCode;
	}
	public void setAddrCode(String addrCode) {
		this.addrCode = addrCode;
	}
	public String getLastCode() {
		return lastCode;
	}
	public void setLastCode(String lastCode) {
		this.lastCode = lastCode;
	}
	public int getCreate_time() {
		return create_time;
	}
	public void setCreate_time(int create_time) {
		this.create_time = create_time;
	}
	 
	public String getRoute_type() {
		return route_type;
	}
	public void setRoute_type(String route_type) {
		this.route_type = route_type;
	}
	
}

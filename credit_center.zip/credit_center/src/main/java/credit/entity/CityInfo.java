package credit.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 城市信息
 * 
 * @author zhanglle
 *
 */
@Document(indexName = "city_info", type = "credit_data", createIndex = false)
public class CityInfo {
	@Id
	@Field(type = FieldType.Keyword)
	private String channel_type;

	@Field(type = FieldType.Text)
	private String city_info; // 城市信息

	public String getChannel_type() {
		return channel_type;
	}

	public void setChannel_type(String channel_type) {
		this.channel_type = channel_type;
	}

	public String getCity_info() {
		return city_info;
	}

	public void setCity_info(String city_info) {
		this.city_info = city_info;
	}

}

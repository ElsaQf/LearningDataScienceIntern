package credit.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import credit.vo.parmVo.mifang.BorrowDetail;

/**
 * 米房数据
 */
@SuppressWarnings("serial")
@Document(indexName = "mifang_data", type = "credit_data", createIndex = false)
public class MiFangData implements Serializable {
	@Id
	@Field(type = FieldType.Keyword)
	private String report_id;// 主键
	@Field(type = FieldType.Keyword)
	private String system_name;
	@Field(type = FieldType.Text)
	private String phone; //米房手机号
	@Field(type = FieldType.Text)
	private String user_name; //米房姓名
	@Field(type = FieldType.Text)
	private String id_no; //米房身份证
	@Field(type = FieldType.Text)
	private String nickname; // 昵称
	@Field(type = FieldType.Boolean)
	private Boolean wechat_binding; // 是否绑定微信
	@Field(type = FieldType.Boolean)
	private Boolean bank_card_binded; // 是否绑卡
	@Field(type = FieldType.Text)
	private String state; // 账户状态
	@Field(type = FieldType.Date)
	private Date register_time; //注册时间
	@Field(type = FieldType.Object)
	private List<BorrowDetail> borrow_details;//借入详情
	@Field(type = FieldType.Integer)
	private Integer update_time;
	@Field(type = FieldType.Integer)
	private Integer verson_num;//版本号：第一风控的老数据改为版本2
	public String getReport_id() {
		return report_id;
	}
	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public Boolean getWechat_binding() {
		return wechat_binding;
	}
	public void setWechat_binding(Boolean wechat_binding) {
		this.wechat_binding = wechat_binding;
	}
	public Boolean getBank_card_binded() {
		return bank_card_binded;
	}
	public void setBank_card_binded(Boolean bank_card_binded) {
		this.bank_card_binded = bank_card_binded;
	}
	public Date getRegister_time() {
		return register_time;
	}
	public void setRegister_time(Date register_time) {
		this.register_time = register_time;
	}
	public List<BorrowDetail> getBorrow_details() {
		return borrow_details;
	}
	public void setBorrow_details(List<BorrowDetail> borrow_details) {
		this.borrow_details = borrow_details;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public Integer getVerson_num() {
		return verson_num;
	}
	public void setVerson_num(Integer verson_num) {
		this.verson_num = verson_num;
	}
	
}

package credit.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class DateUtil {
	
	/**
	 * Date类型转成秒
	 * @param date
	 * @return
	 */
	public static int getSecond(Date date) {
		if (null == date) {
			return 0;
		}
		return (int) (date.getTime() / 1000);
	}
	
	/**
	 * 通过秒获取Date
	 * @param second
	 * @return
	 */
	public static Date getDate(int second) {
		if (second < 0) {
			return null;
		}
		return new Date(((long) second) * 1000);
	}

	/**
	 * 通过秒获取Date
	 * @param second
	 * @return
	 */
	public static Date getDateByLong(long second) {
		if (second < 0) {
			return null;
		}
		return new Date(second);
	}

	/**获取m分钟后的时间
	 * @param d
	 * @param day
	 * @return
	 * 
	 */
	public static Date getMinute(Date d, int m) {
		Calendar now = Calendar.getInstance();
		now.setTime(d);
		now.add(Calendar.MINUTE, m);
//		now.set(Calendar.MINUTE, now.get(Calendar.MINUTE) - m);
		return now.getTime();
	}
	
	/**
	 * 将字符串转换为Date类型
	 * 
	 * @param date 字符串类型
	 * @param pattern 格式
	 * @return 日期类型
	 */
	public static Date format(String date, String pattern) {
		if (pattern == null || pattern.equals("") || pattern.equals("null")) {
			pattern = "yyyy-MM-dd HH:mm:ss";
		}
		if (date == null || date.equals("") || date.equals("null")) {
			return new Date();
		}
		Date d = null;
		try {
			d = new java.text.SimpleDateFormat(pattern).parse(date);
		} catch (ParseException pe) {
		}
		return d;
	}
	
	/**
	 * 将Date类型转换为字符串
	 * 
	 * @param date 日期类型
	 * @param pattern 字符串格式
	 * @return 日期字符串
	 */
	public static String format(Date date, String pattern) {
		if (date == null) {
			return "null";
		}
		if (pattern == null || pattern.equals("") || pattern.equals("null")) {
			pattern = "yyyy-MM-dd HH:mm:ss";
		}
		return new java.text.SimpleDateFormat(pattern).format(date);
	}
	
	/**
	 * 计算两个日期相差的天数
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	public static int DateBetween(Date beginDate, Date endDate){
		Date beginDate1 = format(format(beginDate, "yyyy-MM-dd"), "yyyy-MM-dd");
		Date endDate1 = format(format(endDate, "yyyy-MM-dd"), "yyyy-MM-dd");
		long beginTime = beginDate1.getTime();
		long endTime = endDate1.getTime();
		return(int)((endTime - beginTime) / (1000 * 60 * 60 *24));
	}
	
	/**
	 * 获取今天还剩下多少秒
	 * @return
	 */
	public static int getMiao(){
		Calendar curDate = Calendar.getInstance();
		Calendar tommorowDate = new GregorianCalendar(curDate
				.get(Calendar.YEAR), curDate.get(Calendar.MONTH), curDate
				.get(Calendar.DATE) + 1, 0, 0, 0);
		return (int)(tommorowDate.getTimeInMillis() - curDate .getTimeInMillis()) / 1000;
	}
	
	  /**
     * 获取上一个月
     * 
     * @return
     */
    public static String getLastMonth(int m) {
        Calendar cal = Calendar.getInstance();
        cal.add(cal.MONTH, m);
        SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM");
        String lastMonth = dft.format(cal.getTime());
        return lastMonth;
    }
    
	/**
	 * 得到几个月前或几月后的时间
	 */
	public static Date getMonth(Date d, int month) throws Exception {
		Calendar now = Calendar.getInstance();
		now.setTime(d);
		now.add(Calendar.MONTH, month);
//		now.set(Calendar.MONTH, now.get(Calendar.MONTH) - month);
		return now.getTime();
	}
}
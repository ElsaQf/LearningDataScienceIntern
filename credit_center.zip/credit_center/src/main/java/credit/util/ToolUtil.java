package credit.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

import credit.accessory.ConfigBean;


public class ToolUtil {

    private static Logger log = LoggerFactory.getLogger(ToolUtil.class);
 

    public static String checkIdNo(String idNo) {
        if (idNo == null || idNo.equals("")) {
            return idNo;
        }

        String temp = idNo.trim();
        if (temp.endsWith("x")) {
            temp = temp.replace("x", "X");
        }

        return temp;
    }

   
    /**
     * 把图像数据转换为byte数组
     */

    public static byte[] convertImageBase64(String imgStr) throws Exception {
        if (imgStr == null) // 图像数据为空
            return null;
        // 去掉 data:image/jpeg;base64,
        int nIndex = imgStr.indexOf(",");
        imgStr = imgStr.substring(nIndex + 1);
        Base64 decoder = new Base64();
        byte[] b = decoder.decode(imgStr);// Base64解码 decodeBuffer(imgStr)
        for (int i = 0; i < b.length; ++i) {
            if (b[i] < 0) {// 调整异常数据
                b[i] += 256;
            }
        }
        return b;
    }

    /**
     * 脱敏
     *
     * @param str
     * @param start
     * @param end
     * @return
     */
    public static String replace(String str, int start, int end) {
        if (str == null)
            return null;
        char c = '*';
        StringBuffer strbf = new StringBuffer(str);
        for (int i = start; i < str.length() - end; i++) {
            strbf.setCharAt(i, c);
        }
        return strbf.toString();
    }

    /**
     * 获取远端ip
     *
     * @param request
     * @return
     */
    public static String getRemoteIP(HttpServletRequest request) {
        if (request.getHeader("x-forwarded-for") == null || request.getHeader("x-forwarded-for").equals("")) {
            return request.getRemoteAddr();
        }
        String xforward = request.getHeader("x-forwarded-for");
        String[] temp = xforward.split(",");
        String ip = null;
        for (int i = 0; i < temp.length; i++) {
            if (!temp[i].equalsIgnoreCase("unknown")) {
                ip = temp[i];
                break;
            }
        }
        return ip;
    }
    
    /**
     * 是否为数字
     * @Title: isDigit   
     * @Description: TODO   
     * @param: @param str
     * @param: @return      
     * @return: boolean      
     * @throws
     */
    public static boolean isDigit(String str) {
		try {
			Double.parseDouble(str);
			return true;
		} catch (Exception e) {
			return false;
		}
    }
    
    /**
     * 判断是否为图片
     *
     * @param urlString
     * @param key
     * @return
     * @throws Exception
     */
    public static boolean isExistPic(String urlString){
    	try {
    		// 构造URL
    		URL url = new URL(urlString);
    		// 打开连接
    		URLConnection con = url.openConnection();
    		// 设置请求超时为5s
    		con.setConnectTimeout(5 * 1000);
    		// 输入流
    		InputStream is = con.getInputStream();
    		
    		is.close();
    		return true;
		} catch (Exception e) {
			return false;
		}
    }
    
    /**
     * 文件转为二进制字符串
     * @param file
     * @return
     */
    public static String fileToBinStr(File file){
        try {
            InputStream fis = new FileInputStream(file);
            byte[] bytes = FileCopyUtils.copyToByteArray(fis);
            return new String(bytes,"ISO-8859-1");
        }catch (Exception ex){
            throw new RuntimeException("transform file into bin String 出错",ex);
        }
    }
}
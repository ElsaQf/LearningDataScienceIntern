package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
    * 运营商敏感通话行为检测
 * @author YCM
 * @date 2019年7月1日 下午6:17:50
 */
@SuppressWarnings("serial")
public class ContactCheck implements Serializable {
	@Field(type = FieldType.Text, index = false)
	private	String	check_point;//分析点
	@Field(type = FieldType.Integer)
	private	Integer	call_cnt;//	通话次数
	@Field(type = FieldType.Float)
	private	Float call_time_mins;//通话时长
	@Field(type = FieldType.Text, index = false)
	private	String	result;//	检查结果
	@Field(type = FieldType.Text, index = false)
	private	String	evidence;//	证据
	@Field(type = FieldType.Integer)
	private	Integer	score;//	标记0:无数据, 1:通过, 2:不通过
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getEvidence() {
		return evidence;
	}
	public void setEvidence(String evidence) {
		this.evidence = evidence;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public Integer getCall_cnt() {
		return call_cnt;
	}
	public void setCall_cnt(Integer call_cnt) {
		this.call_cnt = call_cnt;
	}
	public Float getCall_time_mins() {
		return call_time_mins;
	}
	public void setCall_time_mins(Float call_time_mins) {
		this.call_time_mins = call_time_mins;
	}
	public String getCheck_point() {
		return check_point;
	}
	public void setCheck_point(String check_point) {
		this.check_point = check_point;
	}
	
}

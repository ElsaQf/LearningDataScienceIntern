package credit.util.jxl.report;

import java.io.Serializable;
import java.util.List;

import credit.vo.fieldVo.TravelTrackAnalysis;

@SuppressWarnings("serial")
public class ReportBasicVersion implements Serializable {
	private UserBasic user_basic;//运营商基本信息
	private CellPhoneInfo cell_phone_info;//运营商基本信息
	private BehaviorAnalysis behavior_check;//运营商敏感通话行为检测
	private List<CellPhoneBehavior> cell_phone_behavior;//运营商月账单信息
	private List<ContactRegion> contact_region;//运营商通话归属地分析
	private List<ContactList> contact_list;//运营商通话详情
	private List<RoamInfo> roam_info;//运营商通话漫游记录
	private MultipointInfoCheck configurable_search_info_check;//多头借贷风险
	private SocialRiskCheck configurable_user_gray_info;//运营商社交圈风险 
	private ContactEachOther configurable_contact_each_other;//运营商通话号码数量情况
	private PhoneSilentDetails configurable_phone_silent_details;//运营商静默时间
	private ContactNightStats configurable_contact_night;//运营商夜间通话情况
	
	public CellPhoneInfo getCell_phone_info() {
		return cell_phone_info;
	}
	public void setCell_phone_info(CellPhoneInfo cell_phone_info) {
		this.cell_phone_info = cell_phone_info;
	}
	public BehaviorAnalysis getBehavior_check() {
		return behavior_check;
	}
	public void setBehavior_check(BehaviorAnalysis behavior_check) {
		this.behavior_check = behavior_check;
	}
	public List<CellPhoneBehavior> getCell_phone_behavior() {
		return cell_phone_behavior;
	}
	public void setCell_phone_behavior(List<CellPhoneBehavior> cell_phone_behavior) {
		this.cell_phone_behavior = cell_phone_behavior;
	}
	public List<ContactRegion> getContact_region() {
		return contact_region;
	}
	public void setContact_region(List<ContactRegion> contact_region) {
		this.contact_region = contact_region;
	}
	public List<ContactList> getContact_list() {
		return contact_list;
	}
	public void setContact_list(List<ContactList> contact_list) {
		this.contact_list = contact_list;
	}
	public List<RoamInfo> getRoam_info() {
		return roam_info;
	}
	public void setRoam_info(List<RoamInfo> roam_info) {
		this.roam_info = roam_info;
	}
	public MultipointInfoCheck getConfigurable_search_info_check() {
		return configurable_search_info_check;
	}
	public void setConfigurable_search_info_check(MultipointInfoCheck configurable_search_info_check) {
		this.configurable_search_info_check = configurable_search_info_check;
	}
	public SocialRiskCheck getConfigurable_user_gray_info() {
		return configurable_user_gray_info;
	}
	public void setConfigurable_user_gray_info(SocialRiskCheck configurable_user_gray_info) {
		this.configurable_user_gray_info = configurable_user_gray_info;
	}
	public ContactEachOther getConfigurable_contact_each_other() {
		return configurable_contact_each_other;
	}
	public void setConfigurable_contact_each_other(ContactEachOther configurable_contact_each_other) {
		this.configurable_contact_each_other = configurable_contact_each_other;
	}
	public PhoneSilentDetails getConfigurable_phone_silent_details() {
		return configurable_phone_silent_details;
	}
	public void setConfigurable_phone_silent_details(PhoneSilentDetails configurable_phone_silent_details) {
		this.configurable_phone_silent_details = configurable_phone_silent_details;
	}
	public ContactNightStats getConfigurable_contact_night() {
		return configurable_contact_night;
	}
	public void setConfigurable_contact_night(ContactNightStats configurable_contact_night) {
		this.configurable_contact_night = configurable_contact_night;
	}
	public UserBasic getUser_basic() {
		return user_basic;
	}
	public void setUser_basic(UserBasic user_basic) {
		this.user_basic = user_basic;
	}
	
}

package credit.util.jxl.report;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UserBasic implements Serializable {
	private	Boolean	court_blacklist_check	;//	姓名+身份证查询黑名单接口
	private	Boolean	financial_blacklist_check	;//	姓名+身份证查询黑名单接口
	public Boolean getCourt_blacklist_check() {
		return court_blacklist_check;
	}
	public void setCourt_blacklist_check(Boolean court_blacklist_check) {
		this.court_blacklist_check = court_blacklist_check;
	}
	public Boolean getFinancial_blacklist_check() {
		return financial_blacklist_check;
	}
	public void setFinancial_blacklist_check(Boolean financial_blacklist_check) {
		this.financial_blacklist_check = financial_blacklist_check;
	}
	
}

package credit.util.jxl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RespResult implements Serializable {
	private Boolean success;// 返回码
	private String message;// 返回信息
	public Boolean getSuccess() {
		return success;
	}
	public void setSuccess(Boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}

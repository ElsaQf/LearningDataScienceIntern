package credit.util.jxl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class DataRespResult implements Serializable {
	private String code;// 返回码
	private String message;// 返回信息
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}

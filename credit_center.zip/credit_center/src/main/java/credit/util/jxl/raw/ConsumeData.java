package credit.util.jxl.raw;

import java.io.Serializable;

/**
    *   消费情况
 * @author YCM
 * @date 2019年7月1日 下午3:17:55
 */
@SuppressWarnings("serial")
public class ConsumeData implements Serializable {
	private String bill_cycle;//账单月份
	private String cell_phone;//本机号码
	private Float pay_amt;//实际缴费金额（元）
	private Float plan_amt;//套餐及固定费（元）
	private Float total_amt;//总费用（元）
	public String getBill_cycle() {
		return bill_cycle;
	}
	public void setBill_cycle(String bill_cycle) {
		this.bill_cycle = bill_cycle;
	}
	public String getCell_phone() {
		return cell_phone;
	}
	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}
	public Float getPay_amt() {
		return pay_amt;
	}
	public void setPay_amt(Float pay_amt) {
		this.pay_amt = pay_amt;
	}
	public Float getPlan_amt() {
		return plan_amt;
	}
	public void setPlan_amt(Float plan_amt) {
		this.plan_amt = plan_amt;
	}
	public Float getTotal_amt() {
		return total_amt;
	}
	public void setTotal_amt(Float total_amt) {
		this.total_amt = total_amt;
	}
}

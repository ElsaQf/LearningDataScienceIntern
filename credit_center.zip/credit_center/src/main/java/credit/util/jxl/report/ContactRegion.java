package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商通话归属地分析
 * @author YCM
 * @date 2019年7月1日 下午6:17:13
 */
@SuppressWarnings("serial")
public class ContactRegion implements Serializable {
	@Field(type = FieldType.Text, index = false)
	private	String region_loc;//	联系人的号码归属地
	@Field(type = FieldType.Float)
	private	Float region_call_time;//	联系人的通话总时长
	@Field(type = FieldType.Integer)
	private	Integer	region_call_cnt;//	联系人的通话总次数
	@Field(type = FieldType.Integer)
	private	Integer	region_uniq_num_cnt;//	去重后的联系人号码数量
	@Field(type = FieldType.Integer)
	private	Integer	region_call_in_cnt;//	电话呼入次数
	@Field(type = FieldType.Integer)
	private	Integer	region_call_out_cnt;//	电话呼出次数
	@Field(type = FieldType.Float)
	private	Float region_call_in_time;//	电话呼入总时间（分）
	@Field(type = FieldType.Float)
	private	Float region_call_out_time;//	电话呼出总时间（分）
	@Field(type = FieldType.Float)
	private	Float region_avg_call_in_time;//	平均电话呼入时间（分）
	@Field(type = FieldType.Float)
	private	Float region_avg_call_out_time;//	平均电话呼出时间（分）
	@Field(type = FieldType.Float)
	private	Float region_call_in_cnt_pct;//	电话呼入次数百分比
	@Field(type = FieldType.Float)
	private	Float region_call_out_cnt_pct;//	电话呼出次数百分比
	@Field(type = FieldType.Float)
	private	Float region_call_in_time_pct;//	电话呼入时间百分比
	@Field(type = FieldType.Float)
	private	Float region_call_out_time_pct;//	电话呼出时间百分比
	
	public String getRegion_loc() {
		return region_loc;
	}
	public void setRegion_loc(String region_loc) {
		this.region_loc = region_loc;
	}
	public Float getRegion_call_time() {
		return region_call_time;
	}
	public void setRegion_call_time(Float region_call_time) {
		if(region_call_time != null) {
			region_call_time = (float)Math.round(region_call_time*60);
		}
		this.region_call_time = region_call_time;
	}
	public Integer getRegion_call_cnt() {
		return region_call_cnt;
	}
	public void setRegion_call_cnt(Integer region_call_cnt) {
		this.region_call_cnt = region_call_cnt;
	}
	public Integer getRegion_uniq_num_cnt() {
		return region_uniq_num_cnt;
	}
	public void setRegion_uniq_num_cnt(Integer region_uniq_num_cnt) {
		this.region_uniq_num_cnt = region_uniq_num_cnt;
	}
	public Integer getRegion_call_in_cnt() {
		return region_call_in_cnt;
	}
	public void setRegion_call_in_cnt(Integer region_call_in_cnt) {
		this.region_call_in_cnt = region_call_in_cnt;
	}
	public Integer getRegion_call_out_cnt() {
		return region_call_out_cnt;
	}
	public void setRegion_call_out_cnt(Integer region_call_out_cnt) {
		this.region_call_out_cnt = region_call_out_cnt;
	}
	public Float getRegion_call_in_time() {
		return region_call_in_time;
	}
	public void setRegion_call_in_time(Float region_call_in_time) {
		if(region_call_in_time != null) {
			region_call_in_time = (float)Math.round(region_call_in_time*60);
		}
		this.region_call_in_time = region_call_in_time;
	}
	public Float getRegion_call_out_time() {
		return region_call_out_time;
	}
	public void setRegion_call_out_time(Float region_call_out_time) {
		if(region_call_out_time != null) {
			region_call_out_time = (float)Math.round(region_call_out_time*60);
		}
		this.region_call_out_time = region_call_out_time;
	}
	public Float getRegion_avg_call_in_time() {
		return region_avg_call_in_time;
	}
	public void setRegion_avg_call_in_time(Float region_avg_call_in_time) {
		if(region_avg_call_in_time != null) {
			region_avg_call_in_time = (float)Math.round(region_avg_call_in_time*60);
		}
		this.region_avg_call_in_time = region_avg_call_in_time;
	}
	public Float getRegion_avg_call_out_time() {
		return region_avg_call_out_time;
	}
	public void setRegion_avg_call_out_time(Float region_avg_call_out_time) {
		if(region_avg_call_out_time != null) {
			region_avg_call_out_time = (float)Math.round(region_avg_call_out_time*60);
		}
		this.region_avg_call_out_time = region_avg_call_out_time;
	}
	public Float getRegion_call_in_cnt_pct() {
		return region_call_in_cnt_pct;
	}
	public void setRegion_call_in_cnt_pct(Float region_call_in_cnt_pct) {
		if(region_call_in_cnt_pct != null) {
			region_call_in_cnt_pct = ((float)Math.round(region_call_in_cnt_pct*10000))/10000;
		}
		this.region_call_in_cnt_pct = region_call_in_cnt_pct;
	}
	public Float getRegion_call_out_cnt_pct() {
		return region_call_out_cnt_pct;
	}
	public void setRegion_call_out_cnt_pct(Float region_call_out_cnt_pct) {
		if(region_call_out_cnt_pct != null) {
			region_call_out_cnt_pct = ((float)Math.round(region_call_out_cnt_pct*10000))/10000;
		}
		this.region_call_out_cnt_pct = region_call_out_cnt_pct;
	}
	public Float getRegion_call_in_time_pct() {
		return region_call_in_time_pct;
	}
	public void setRegion_call_in_time_pct(Float region_call_in_time_pct) {
		if(region_call_in_time_pct != null) {
			region_call_in_time_pct = ((float)Math.round(region_call_in_time_pct*10000))/10000;
		}
		this.region_call_in_time_pct = region_call_in_time_pct;
	}
	public Float getRegion_call_out_time_pct() {
		return region_call_out_time_pct;
	}
	public void setRegion_call_out_time_pct(Float region_call_out_time_pct) {
		if(region_call_out_time_pct != null) {
			region_call_out_time_pct = ((float)Math.round(region_call_out_time_pct*10000))/10000;
		}
		this.region_call_out_time_pct = region_call_out_time_pct;
	}
	
}

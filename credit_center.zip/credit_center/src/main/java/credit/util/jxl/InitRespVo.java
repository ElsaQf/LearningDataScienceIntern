package credit.util.jxl;

@SuppressWarnings("serial")
public class InitRespVo extends RespResult {
	private InitRespData data;//返回数据

	public InitRespData getData() {
		return data;
	}

	public void setData(InitRespData data) {
		this.data = data;
	}
}

package credit.util.jxl.report;

import java.io.Serializable;
import java.util.List;

/**
     *  运营商静默统计
 * @author YCM
 * @date 2019年7月1日 下午6:16:51
 */
@SuppressWarnings("serial")
public class PhoneSilentDetails implements Serializable {
	private Integer	six_month_silent_days	;//	近6个月静默天数
	private Integer	six_month_max_silent_days	;//	近6个月最长静默天数
	private List<String> six_month_silent_days_details	;//	近6月连续静默>=3天的次数
	private Integer	three_month_silent_days	;//	近3个月静默天数
	private Integer	three_month_max_silent_days	;//	近3个月最长静默天数
	private List<String> three_month_silent_days_details	;//	近3月连续静默>=3天的次数
	private Integer	one_month_silent_days	;//	近1个月静默天数
	private Integer	one_month_max_silent_days	;//	近1个月最长静默天数
	private List<String> one_month_silent_days_details	;//	近1月连续静默>=3天的次数
	private Integer	one_week_silent_days	;//	近1周静默天数
	private Integer	one_week_max_silent_days	;//	近1周最长静默天数
	private List<String> one_week_silent_days_details	;//	近1周连续静默>=3天的次数
	
	public Integer getSix_month_silent_days() {
		return six_month_silent_days;
	}
	public void setSix_month_silent_days(Integer six_month_silent_days) {
		this.six_month_silent_days = six_month_silent_days;
	}
	public Integer getSix_month_max_silent_days() {
		return six_month_max_silent_days;
	}
	public void setSix_month_max_silent_days(Integer six_month_max_silent_days) {
		this.six_month_max_silent_days = six_month_max_silent_days;
	}
	public Integer getThree_month_silent_days() {
		return three_month_silent_days;
	}
	public void setThree_month_silent_days(Integer three_month_silent_days) {
		this.three_month_silent_days = three_month_silent_days;
	}
	public Integer getThree_month_max_silent_days() {
		return three_month_max_silent_days;
	}
	public void setThree_month_max_silent_days(Integer three_month_max_silent_days) {
		this.three_month_max_silent_days = three_month_max_silent_days;
	}
	public Integer getOne_month_silent_days() {
		return one_month_silent_days;
	}
	public void setOne_month_silent_days(Integer one_month_silent_days) {
		this.one_month_silent_days = one_month_silent_days;
	}
	public Integer getOne_month_max_silent_days() {
		return one_month_max_silent_days;
	}
	public void setOne_month_max_silent_days(Integer one_month_max_silent_days) {
		this.one_month_max_silent_days = one_month_max_silent_days;
	}
	public Integer getOne_week_silent_days() {
		return one_week_silent_days;
	}
	public void setOne_week_silent_days(Integer one_week_silent_days) {
		this.one_week_silent_days = one_week_silent_days;
	}
	public Integer getOne_week_max_silent_days() {
		return one_week_max_silent_days;
	}
	public void setOne_week_max_silent_days(Integer one_week_max_silent_days) {
		this.one_week_max_silent_days = one_week_max_silent_days;
	}
	public List<String> getSix_month_silent_days_details() {
		return six_month_silent_days_details;
	}
	public void setSix_month_silent_days_details(List<String> six_month_silent_days_details) {
		this.six_month_silent_days_details = six_month_silent_days_details;
	}
	public List<String> getThree_month_silent_days_details() {
		return three_month_silent_days_details;
	}
	public void setThree_month_silent_days_details(List<String> three_month_silent_days_details) {
		this.three_month_silent_days_details = three_month_silent_days_details;
	}
	public List<String> getOne_month_silent_days_details() {
		return one_month_silent_days_details;
	}
	public void setOne_month_silent_days_details(List<String> one_month_silent_days_details) {
		this.one_month_silent_days_details = one_month_silent_days_details;
	}
	public List<String> getOne_week_silent_days_details() {
		return one_week_silent_days_details;
	}
	public void setOne_week_silent_days_details(List<String> one_week_silent_days_details) {
		this.one_week_silent_days_details = one_week_silent_days_details;
	}
	
}

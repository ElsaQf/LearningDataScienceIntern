package credit.util.jxl.report;

import credit.util.jxl.DataRespResult;

@SuppressWarnings("serial")
public class ReportDataRespVo extends DataRespResult {
	private ReportData data;//原始数据

	public ReportData getData() {
		return data;
	}

	public void setData(ReportData data) {
		this.data = data;
	}
}

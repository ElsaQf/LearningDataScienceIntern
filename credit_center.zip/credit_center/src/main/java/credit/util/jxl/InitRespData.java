package credit.util.jxl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class InitRespData implements Serializable {
	private String token;//本次任务token
	private DataSource datasource;//本次任务token
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public DataSource getDatasource() {
		return datasource;
	}
	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}
}

package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
     *  运营商夜间通话统计
 * @author YCM
 * @date 2019年7月1日 下午6:16:51
 */
@SuppressWarnings("serial")
public class ContactNightStats implements Serializable {
	@Field(type = FieldType.Integer)
	private	Integer	six_month_night_cnt	;//	近6个月0点到6点夜间活动次数
	@Field(type = FieldType.Text, index = false)
	private	String	six_month_night_ratio	;//	近6个月0点到6点夜间活动比重
	@Field(type = FieldType.Integer)
	private	Integer	three_month_night_cnt	;//	近3个月0点到6点夜间活动次数
	@Field(type = FieldType.Text, index = false)
	private	String	three_month_night_ratio	;//	近3个月0点到6点夜间活动比重
	@Field(type = FieldType.Integer)
	private	Integer	one_month_night_cnt	;//	近1个月0点到6点夜间活动次数
	@Field(type = FieldType.Text, index = false)
	private	String	one_month_night_ratio	;//	近1个月0点到6点夜间活动比重
	@Field(type = FieldType.Integer)
	private	Integer	one_week_night_cnt	;//	近1周0点到6点夜间活动次数
	@Field(type = FieldType.Text, index = false)
	private	String	one_week_night_ratio	;//	近1周0点到6点夜间活动比重
	public Integer getSix_month_night_cnt() {
		return six_month_night_cnt;
	}
	public void setSix_month_night_cnt(Integer six_month_night_cnt) {
		this.six_month_night_cnt = six_month_night_cnt;
	}
	public String getSix_month_night_ratio() {
		return six_month_night_ratio;
	}
	public void setSix_month_night_ratio(String six_month_night_ratio) {
		this.six_month_night_ratio = six_month_night_ratio;
	}
	public Integer getThree_month_night_cnt() {
		return three_month_night_cnt;
	}
	public void setThree_month_night_cnt(Integer three_month_night_cnt) {
		this.three_month_night_cnt = three_month_night_cnt;
	}
	public String getThree_month_night_ratio() {
		return three_month_night_ratio;
	}
	public void setThree_month_night_ratio(String three_month_night_ratio) {
		this.three_month_night_ratio = three_month_night_ratio;
	}
	public Integer getOne_month_night_cnt() {
		return one_month_night_cnt;
	}
	public void setOne_month_night_cnt(Integer one_month_night_cnt) {
		this.one_month_night_cnt = one_month_night_cnt;
	}
	public String getOne_month_night_ratio() {
		return one_month_night_ratio;
	}
	public void setOne_month_night_ratio(String one_month_night_ratio) {
		this.one_month_night_ratio = one_month_night_ratio;
	}
	public Integer getOne_week_night_cnt() {
		return one_week_night_cnt;
	}
	public void setOne_week_night_cnt(Integer one_week_night_cnt) {
		this.one_week_night_cnt = one_week_night_cnt;
	}
	public String getOne_week_night_ratio() {
		return one_week_night_ratio;
	}
	public void setOne_week_night_ratio(String one_week_night_ratio) {
		this.one_week_night_ratio = one_week_night_ratio;
	}
	 
}

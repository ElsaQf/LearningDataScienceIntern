package credit.util.jxl;

public enum StatusCodes {
	status_10001("10001","再次输入短信验证码"),
	status_10002("10002","输入短信验证码"),
	status_10003("10003","密码错误"),
	status_10004("10004","短信验证码错误"),
	status_10006("10006","短信验证码失效系统已自动重新下发"),
	status_10007("10007","简单密码或初始密码无法登录"),
	status_10008("10008","开始采集行为数据"),
	status_10010("10010","新密码格式错误"),
	status_10017("10017","请用本机发送CXXD至10001获取查询详单的验证码"),
	status_10018("10018","短信码失效请用本机发送CXXD至10001获取查询详单的验证码"),
	status_10022("10022","输入查询密码"),
	status_10023("10023","查询密码错误"),
	status_11000("11000","重置密码成功"),
	status_20000("20000","继续轮询"),
	status_30000("30000","错误信息"),
	status_31000("31000","重置密码失败"),
	status_0("0","继续轮询");
	
	private String key;
	private String message;

	private StatusCodes(String key, String message) {
		this.key = key;
		this.message = message;
	}

	public String getKey() {
		return this.key;
	}

	public String getMessage() {
		return this.message;
	}

	public static String getStatusMessage(String key) {
		for (StatusCodes c : StatusCodes.values()) {
			if (c.getKey().equals(key))
				return c.getMessage();
		}
		return "";
	}
}

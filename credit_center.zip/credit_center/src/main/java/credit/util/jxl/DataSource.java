package credit.util.jxl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class DataSource implements Serializable {
	private String website;//运营商网站英文名称

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
}

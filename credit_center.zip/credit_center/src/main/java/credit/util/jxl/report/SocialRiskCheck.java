package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
     *  运营商社交圈风险
 * @author YCM
 * @date 2019年7月1日 下午6:16:51
 */
@SuppressWarnings("serial")
public class SocialRiskCheck implements Serializable {
	@Field(type = FieldType.Integer)
	private	Integer	phone_gray_score;//	用户号码灰度分
	@Field(type = FieldType.Integer)
	private	Integer	contacts_class1_blacklist_cnt;//	直接联系人中黑名单人数 
	@Field(type = FieldType.Integer)
	private	Integer	contacts_class2_blacklist_cnt;//	间接联系人中黑名单人数
	@Field(type = FieldType.Integer)
	private	Integer	contacts_class1_cnt;//	直接联系人人数
	@Field(type = FieldType.Integer)
	private	Integer	contacts_router_cnt;//	引起间接黑名单人数
	@Field(type = FieldType.Float)
	private	Float contacts_router_ratio;//	直接联系人中引起间接黑名单占比
	
	public Integer getPhone_gray_score() {
		return phone_gray_score;
	}
	public void setPhone_gray_score(Integer phone_gray_score) {
		this.phone_gray_score = phone_gray_score;
	}
	public Integer getContacts_class1_blacklist_cnt() {
		return contacts_class1_blacklist_cnt;
	}
	public void setContacts_class1_blacklist_cnt(Integer contacts_class1_blacklist_cnt) {
		this.contacts_class1_blacklist_cnt = contacts_class1_blacklist_cnt;
	}
	public Integer getContacts_class2_blacklist_cnt() {
		return contacts_class2_blacklist_cnt;
	}
	public void setContacts_class2_blacklist_cnt(Integer contacts_class2_blacklist_cnt) {
		this.contacts_class2_blacklist_cnt = contacts_class2_blacklist_cnt;
	}
	public Integer getContacts_class1_cnt() {
		return contacts_class1_cnt;
	}
	public void setContacts_class1_cnt(Integer contacts_class1_cnt) {
		this.contacts_class1_cnt = contacts_class1_cnt;
	}
	public Integer getContacts_router_cnt() {
		return contacts_router_cnt;
	}
	public void setContacts_router_cnt(Integer contacts_router_cnt) {
		this.contacts_router_cnt = contacts_router_cnt;
	}
	public Float getContacts_router_ratio() {
		return contacts_router_ratio;
	}
	public void setContacts_router_ratio(Float contacts_router_ratio) {
		if(contacts_router_ratio != null) {
			contacts_router_ratio = ((float)Math.round(contacts_router_ratio*10000))/10000;
		}
		this.contacts_router_ratio = contacts_router_ratio;
	}
}

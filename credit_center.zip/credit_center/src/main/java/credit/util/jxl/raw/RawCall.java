package credit.util.jxl.raw;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RawCall implements Serializable {
	private String call_type;//通话类型	
	private String cell_phone;//本机号码	
	private String init_type;//呼叫类型	
	private String other_cell_phone;//对方号码	
	private String place;//通话地点	
	private String start_time;//通话时间	
	private Float subtotal;//本次通话花费（元）	
	private Float use_time;//通话时长（秒）	
	
	public String getCall_type() {
		return call_type;
	}
	public void setCall_type(String call_type) {
		this.call_type = call_type;
	}
	public String getCell_phone() {
		return cell_phone;
	}
	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}
	public String getInit_type() {
		return init_type;
	}
	public void setInit_type(String init_type) {
		this.init_type = init_type;
	}
	public String getOther_cell_phone() {
		return other_cell_phone;
	}
	public void setOther_cell_phone(String other_cell_phone) {
		this.other_cell_phone = other_cell_phone;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public Float getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(Float subtotal) {
		this.subtotal = subtotal;
	}
	public Float getUse_time() {
		return use_time;
	}
	public void setUse_time(Float use_time) {
		this.use_time = use_time;
	}
}

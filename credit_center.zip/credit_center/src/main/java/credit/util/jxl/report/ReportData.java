package credit.util.jxl.report;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ReportData implements Serializable {
	private String status;//抓取状态
	private ReportBasicVersion basic_version;//原始数据
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ReportBasicVersion getBasic_version() {
		return basic_version;
	}
	public void setBasic_version(ReportBasicVersion basic_version) {
		this.basic_version = basic_version;
	}
}

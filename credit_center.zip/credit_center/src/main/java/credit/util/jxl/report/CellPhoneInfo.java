package credit.util.jxl.report;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CellPhoneInfo implements Serializable {
	private	String	mobile	;//	手机号
	private	String	website	;//	移动运营商
	private	String	reliability	;//	是否实名
	private	String	mobile_name	;//	运营商提供的姓名
	private	Boolean	name_match	;//	用户姓名与运营商提供的姓名是否匹配
	private	String	mobile_idcard	;//	运营商提供的身份证号码
	private	Boolean	idcard_match	;//	用户身份证号与运营商提供的身份证号码是否匹配
	private	Boolean	financial_blacklist	;//	金融服务类机构黑名单检查
	private	String	phone_status	;//	手机状态
	private	String	phone_brand	;//	所属品牌
	private	String	star_level	;//	用户级别（星级）
	private	String	reg_time	;//	开户时间（网龄）
	private	String	reg_time_length	;//	开户时长
	private	String	email	;//	用户邮箱
	private	String	mobile_address	;//	运营商提供的地址
	private	String	phone_attribution	;//	手机号码归属地
	private	String	regular_address	;//	朋友圈所在地
	private	Float available_balance	;//	余额
	private	Integer	phone_used_time	;//	号码使用时间
	private	String	package_name	;//	套餐
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getReliability() {
		return reliability;
	}
	public void setReliability(String reliability) {
		this.reliability = reliability;
	}
	public String getMobile_name() {
		return mobile_name;
	}
	public void setMobile_name(String mobile_name) {
		this.mobile_name = mobile_name;
	}
	public Boolean getName_match() {
		return name_match;
	}
	public void setName_match(Boolean name_match) {
		this.name_match = name_match;
	}
	public String getMobile_idcard() {
		return mobile_idcard;
	}
	public void setMobile_idcard(String mobile_idcard) {
		this.mobile_idcard = mobile_idcard;
	}
	public Boolean getIdcard_match() {
		return idcard_match;
	}
	public void setIdcard_match(Boolean idcard_match) {
		this.idcard_match = idcard_match;
	}
	public Boolean getFinancial_blacklist() {
		return financial_blacklist;
	}
	public void setFinancial_blacklist(Boolean financial_blacklist) {
		this.financial_blacklist = financial_blacklist;
	}
	public String getPhone_status() {
		return phone_status;
	}
	public void setPhone_status(String phone_status) {
		this.phone_status = phone_status;
	}
	public String getPhone_brand() {
		return phone_brand;
	}
	public void setPhone_brand(String phone_brand) {
		this.phone_brand = phone_brand;
	}
	public String getStar_level() {
		return star_level;
	}
	public void setStar_level(String star_level) {
		this.star_level = star_level;
	}
	public String getReg_time() {
		return reg_time;
	}
	public void setReg_time(String reg_time) {
		this.reg_time = reg_time;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile_address() {
		return mobile_address;
	}
	public void setMobile_address(String mobile_address) {
		this.mobile_address = mobile_address;
	}
	public String getPhone_attribution() {
		return phone_attribution;
	}
	public void setPhone_attribution(String phone_attribution) {
		this.phone_attribution = phone_attribution;
	}
	public String getRegular_address() {
		return regular_address;
	}
	public void setRegular_address(String regular_address) {
		this.regular_address = regular_address;
	}
	public Float getAvailable_balance() {
		return available_balance;
	}
	public void setAvailable_balance(Float available_balance) {
		this.available_balance = available_balance;
	}
	public Integer getPhone_used_time() {
		return phone_used_time;
	}
	public void setPhone_used_time(Integer phone_used_time) {
		this.phone_used_time = phone_used_time;
	}
	public String getPackage_name() {
		return package_name;
	}
	public void setPackage_name(String package_name) {
		this.package_name = package_name;
	}
	public String getReg_time_length() {
		return reg_time_length;
	}
	public void setReg_time_length(String reg_time_length) {
		this.reg_time_length = reg_time_length;
	}
}

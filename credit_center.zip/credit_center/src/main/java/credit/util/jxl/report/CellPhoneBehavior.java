package credit.util.jxl.report;

import java.io.Serializable;

/**
     * 运营商月账单信息
 * @author YCM
 * @date 2019年7月1日 下午6:17:33
 */
@SuppressWarnings("serial")
public class CellPhoneBehavior implements Serializable {
	private	String	month	;//	月份
	private	Integer	call_cnt	;//	呼叫次数
	private	Integer	call_out_cnt	;//	主叫次数
	private	Float	call_out_time	;//	主叫时间（分）
	private	Integer	call_in_cnt	;//	被叫次数
	private	Float	call_in_time	;//	被叫时间（分）
	private	Integer	recharge_cnt	;//	按月份对充值记录进行统计的次数
	private	Float	recharge_amount	;//	按月份对充值记录进行统计的总金额
	private	Integer	sms_cnt	;//	短信数量
	private	Float	total_amount	;//	话费消费(元)
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Integer getCall_cnt() {
		return call_cnt;
	}
	public void setCall_cnt(Integer call_cnt) {
		this.call_cnt = call_cnt;
	}
	public Integer getCall_out_cnt() {
		return call_out_cnt;
	}
	public void setCall_out_cnt(Integer call_out_cnt) {
		this.call_out_cnt = call_out_cnt;
	}
	public Float getCall_out_time() {
		return call_out_time;
	}
	public void setCall_out_time(Float call_out_time) {
		if(call_out_time != null) {
			call_out_time = (float)Math.round(call_out_time*60);
		}
		this.call_out_time = call_out_time;
	}
	public Integer getCall_in_cnt() {
		return call_in_cnt;
	}
	public void setCall_in_cnt(Integer call_in_cnt) {
		this.call_in_cnt = call_in_cnt;
	}
	public Float getCall_in_time() {
		return call_in_time;
	}
	public void setCall_in_time(Float call_in_time) {
		if(call_in_time != null) {
			call_in_time = (float)Math.round(call_in_time*60);
		}
		this.call_in_time = call_in_time;
	}
	 
	public Integer getRecharge_cnt() {
		return recharge_cnt;
	}
	public void setRecharge_cnt(Integer recharge_cnt) {
		this.recharge_cnt = recharge_cnt;
	}
	public Float getRecharge_amount() {
		return recharge_amount;
	}
	public void setRecharge_amount(Float recharge_amount) {
		this.recharge_amount = recharge_amount;
	}
	public Integer getSms_cnt() {
		return sms_cnt;
	}
	public void setSms_cnt(Integer sms_cnt) {
		this.sms_cnt = sms_cnt;
	}
	public Float getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(Float total_amount) {
		this.total_amount = total_amount;
	}
}

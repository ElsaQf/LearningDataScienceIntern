package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
    * 运营商敏感通话行为检测
 * @author YCM
 * @date 2019年7月1日 下午6:17:50
 */
@SuppressWarnings("serial")
public class BehaviorAnalysis implements Serializable {
	private	ContactCheck contact_macao;//澳门电话通话情况
	private	ContactCheck contact_110;//110话通话情况
	private	ContactCheck contact_120;//120话通话情况
	private	ContactCheck contact_lawyer;//律师号码通话情况
	private	ContactCheck contact_court;//法院号码通话情况
	private	ContactCheck contact_loan;//贷款类号码联系情况
	private	ContactCheck contact_bank;//银行类号码联系情况
	private	ContactCheck contact_credit_card;//信用卡类号码联系情况
	
	public ContactCheck getContact_macao() {
		return contact_macao;
	}
	public void setContact_macao(ContactCheck contact_macao) {
		this.contact_macao = contact_macao;
	}
	public ContactCheck getContact_110() {
		return contact_110;
	}
	public void setContact_110(ContactCheck contact_110) {
		this.contact_110 = contact_110;
	}
	public ContactCheck getContact_120() {
		return contact_120;
	}
	public void setContact_120(ContactCheck contact_120) {
		this.contact_120 = contact_120;
	}
	public ContactCheck getContact_lawyer() {
		return contact_lawyer;
	}
	public void setContact_lawyer(ContactCheck contact_lawyer) {
		this.contact_lawyer = contact_lawyer;
	}
	public ContactCheck getContact_court() {
		return contact_court;
	}
	public void setContact_court(ContactCheck contact_court) {
		this.contact_court = contact_court;
	}
	public ContactCheck getContact_loan() {
		return contact_loan;
	}
	public void setContact_loan(ContactCheck contact_loan) {
		this.contact_loan = contact_loan;
	}
	public ContactCheck getContact_bank() {
		return contact_bank;
	}
	public void setContact_bank(ContactCheck contact_bank) {
		this.contact_bank = contact_bank;
	}
	public ContactCheck getContact_credit_card() {
		return contact_credit_card;
	}
	public void setContact_credit_card(ContactCheck contact_credit_card) {
		this.contact_credit_card = contact_credit_card;
	}
	 
}

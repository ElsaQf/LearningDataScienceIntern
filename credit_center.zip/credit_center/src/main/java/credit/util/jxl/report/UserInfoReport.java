package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 运营商基础信息表
 * @author YCM
 *
 */
@SuppressWarnings("serial")
public class UserInfoReport implements Serializable  {
	
	@Field(type = FieldType.Text, index = false)
	private String user_mobile; // 本机号码
	@Field(type = FieldType.Text, index = false)
	private String mobile_net_addr; // 归属地
	@Field(type = FieldType.Text, index = false)
	private String mobile_carrier; // 运营商
	@Field(type = FieldType.Text, index = false)
	private String real_name; // 登记姓名
	@Field(type = FieldType.Text, index = false)
	private String identity_code; // 登记身份证号
	@Field(type = FieldType.Text, index = false)
	private String reliability; // 是否实名
	@Field(type = FieldType.Text, index = false)
	private String account_status; // 账户状态
	@Field(type = FieldType.Text, index = false)
	private String package_type; // 套餐名称
	@Field(type = FieldType.Integer)
	private Integer account_balance; // 账户余额(分)
	@Field(type = FieldType.Text, index = false)
	private String mobile_net_time; // 入网时间
	@Field(type = FieldType.Integer)
	private Integer phone_used_time; // 号码使用时间(与入网时长不同)
	@Field(type = FieldType.Text, index = false)
	private String email; // 邮箱
	@Field(type = FieldType.Text, index = false)
	private String contact_addr; // 地址
	@Field(type = FieldType.Boolean)
	private Boolean name_idcard_court_blacklist; // 姓名+身份证是否在法院黑名单
	@Field(type = FieldType.Boolean)
	private Boolean name_idcard_financial_blacklist; // 姓名+身份证是否在金融服务类机构黑名单
	@Field(type = FieldType.Boolean)
	private Boolean name_telephone_financial_blacklist; // 姓名+手机号查询黑名单接口
	
	public String getUser_mobile() {
		return user_mobile;
	}
	public void setUser_mobile(String user_mobile) {
		this.user_mobile = user_mobile;
	}
	public String getMobile_net_addr() {
		return mobile_net_addr;
	}
	public void setMobile_net_addr(String mobile_net_addr) {
		this.mobile_net_addr = mobile_net_addr;
	}
	public String getMobile_carrier() {
		return mobile_carrier;
	}
	public void setMobile_carrier(String mobile_carrier) {
		this.mobile_carrier = mobile_carrier;
	}
	public String getReal_name() {
		return real_name;
	}
	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}
	public String getIdentity_code() {
		return identity_code;
	}
	public void setIdentity_code(String identity_code) {
		this.identity_code = identity_code;
	}
	public String getReliability() {
		return reliability;
	}
	public void setReliability(String reliability) {
		this.reliability = reliability;
	}
	public String getAccount_status() {
		return account_status;
	}
	public void setAccount_status(String account_status) {
		this.account_status = account_status;
	}
	public String getPackage_type() {
		return package_type;
	}
	public void setPackage_type(String package_type) {
		this.package_type = package_type;
	}
	public Integer getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(Integer account_balance) {
		this.account_balance = account_balance;
	}
	public String getMobile_net_time() {
		return mobile_net_time;
	}
	public void setMobile_net_time(String mobile_net_time) {
		this.mobile_net_time = mobile_net_time;
	}
	public Integer getPhone_used_time() {
		return phone_used_time;
	}
	public void setPhone_used_time(Integer phone_used_time) {
		this.phone_used_time = phone_used_time;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact_addr() {
		return contact_addr;
	}
	public void setContact_addr(String contact_addr) {
		this.contact_addr = contact_addr;
	}
	public Boolean getName_idcard_court_blacklist() {
		return name_idcard_court_blacklist;
	}
	public void setName_idcard_court_blacklist(Boolean name_idcard_court_blacklist) {
		this.name_idcard_court_blacklist = name_idcard_court_blacklist;
	}
	public Boolean getName_idcard_financial_blacklist() {
		return name_idcard_financial_blacklist;
	}
	public void setName_idcard_financial_blacklist(Boolean name_idcard_financial_blacklist) {
		this.name_idcard_financial_blacklist = name_idcard_financial_blacklist;
	}
	public Boolean getName_telephone_financial_blacklist() {
		return name_telephone_financial_blacklist;
	}
	public void setName_telephone_financial_blacklist(Boolean name_telephone_financial_blacklist) {
		this.name_telephone_financial_blacklist = name_telephone_financial_blacklist;
	}
	
	 
}

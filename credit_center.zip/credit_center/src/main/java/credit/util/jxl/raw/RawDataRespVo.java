package credit.util.jxl.raw;

import credit.util.jxl.DataRespResult;

@SuppressWarnings("serial")
public class RawDataRespVo extends DataRespResult {
	private RawData data;//原始数据

	public RawData getData() {
		return data;
	}

	public void setData(RawData data) {
		this.data = data;
	}
}

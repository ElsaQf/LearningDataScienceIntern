package credit.util.jxl;

@SuppressWarnings("serial")
public class StatusRespVo extends RespResult {
	private StatusRespData data;//返回数据

	public StatusRespData getData() {
		return data;
	}

	public void setData(StatusRespData data) {
		this.data = data;
	}
}

package credit.util.jxl;

import java.io.Serializable;

@SuppressWarnings("serial")
public class StatusRespData implements Serializable {
	private String process_code;//状态码
	private String content;//返回提示
	
	public String getProcess_code() {
		return process_code;
	}
	public void setProcess_code(String process_code) {
		this.process_code = process_code;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}

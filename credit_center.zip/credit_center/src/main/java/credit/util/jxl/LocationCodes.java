package credit.util.jxl;

public enum LocationCodes {
	locationCode_1("chinaunicom","中国联通"),
	locationCode_2("chinamobileah","安徽移动"),
	locationCode_3("chinamobilebj","北京移动"),
	locationCode_4("chinamobilecq","重庆移动"),
	locationCode_5("chinamobilefj","福建移动"),
	locationCode_6("chinamobilegd","广东移动"),
	locationCode_7("chinamobilegs","甘肃移动"),
	locationCode_8("chinamobilegx","广西移动"),
	locationCode_9("chinamobilegz","贵州移动"),
	locationCode_10("chinamobileha","河南移动"),
	locationCode_11("chinamobilehb","湖北移动"),
	locationCode_12("chinamobilehe","河北移动"),
	locationCode_13("chinamobilehi","海南移动"),
	locationCode_14("chinamobilehl","黑龙江移动"),
	locationCode_15("chinamobilehn","湖南移动"),
	locationCode_16("chinamobilejl","吉林移动"),
	locationCode_17("chinamobilejs","江苏移动"),
	locationCode_18("chinamobilejx","江西移动"),
	locationCode_19("chinamobileln","辽宁移动"),
	locationCode_20("chinamobilenm","内蒙古移动"),
	locationCode_21("chinamobilenx","宁夏移动"),
	locationCode_22("chinamobileqh","青海移动"),
	locationCode_23("chinamobilesc","四川移动"),
	locationCode_24("chinamobilesd","山东移动"),
	locationCode_25("chinamobilesh","上海移动"),
	locationCode_26("chinamobilesn","陕西移动"),
	locationCode_27("chinamobilesx","山西移动"),
	locationCode_28("chinamobiletj","天津移动"),
	locationCode_29("chinamobilexj","新疆移动"),
	locationCode_30("chinamobilexz","西藏移动"),
	locationCode_31("chinamobileyn","云南移动"),
	locationCode_32("chinamobilezj","浙江移动"),
	locationCode_33("chinatelecomah","安徽电信"),
	locationCode_34("chinatelecombj","北京电信"),
	locationCode_35("chinatelecomcq","重庆电信"),
	locationCode_36("chinatelecomfj","福建电信"),
	locationCode_37("chinatelecomgd","广东电信"),
	locationCode_38("chinatelecomgs","甘肃电信"),
	locationCode_39("chinatelecomgx","广西电信"),
	locationCode_40("chinatelecomgz","贵州电信"),
	locationCode_41("chinatelecomha","河南电信"),
	locationCode_42("chinatelecomhb","湖北电信"),
	locationCode_43("chinatelecomhe","河北电信"),
	locationCode_44("chinatelecomhi","海南电信"),
	locationCode_45("chinatelecomhl","黑龙江电信"),
	locationCode_46("chinatelecomhn","湖南电信"),
	locationCode_47("chinatelecomjl","吉林电信"),
	locationCode_48("chinatelecomjs","江苏电信"),
	locationCode_49("chinatelecomjx","江西电信"),
	locationCode_50("chinatelecomln","辽宁电信"),
	locationCode_51("chinatelecomnm","内蒙古电信"),
	locationCode_52("chinatelecomnx","宁夏电信"),
	locationCode_53("chinatelecomqh","青海电信"),
	locationCode_54("chinatelecomsc","四川电信"),
	locationCode_55("chinatelecomsd","山东电信"),
	locationCode_56("chinatelecomsh","上海电信"),
	locationCode_57("chinatelecomsn","陕西电信"),
	locationCode_58("chinatelecomsx","山西电信"),
	locationCode_59("chinatelecomtj","天津电信"),
	locationCode_60("chinatelecomxj","新疆电信"),
	locationCode_61("chinatelecomxz","西藏电信"),
	locationCode_62("chinatelecomyn","云南电信"),
	locationCode_63("chinatelecomzj","浙江电信");
 
	
	private String key;
	private String message;

	private LocationCodes(String key, String message) {
		this.key = key;
		this.message = message;
	}

	public String getKey() {
		return this.key;
	}

	public String getMessage() {
		return this.message;
	}

	public static String getLocationMessage(String key) {
		for (LocationCodes c : LocationCodes.values()) {
			if (c.getKey().equals(key))
				return c.getMessage();
		}
		return "";
	}
}

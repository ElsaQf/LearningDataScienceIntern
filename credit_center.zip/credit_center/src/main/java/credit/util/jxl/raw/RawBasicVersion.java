package credit.util.jxl.raw;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public class RawBasicVersion implements Serializable {
	private RawBasic basic;//基本信息	-
	private List<RawCall> calls;//通话信息	-
	private List<Sms> smses;//短信信息	-
	private List<ConsumeData> transactions;//账单信息
	public RawBasic getBasic() {
		return basic;
	}
	public void setBasic(RawBasic basic) {
		this.basic = basic;
	}
	public List<RawCall> getCalls() {
		return calls;
	}
	public void setCalls(List<RawCall> calls) {
		this.calls = calls;
	}
	public List<Sms> getSmses() {
		return smses;
	}
	public void setSmses(List<Sms> smses) {
		this.smses = smses;
	}
	public List<ConsumeData> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<ConsumeData> transactions) {
		this.transactions = transactions;
	}
}

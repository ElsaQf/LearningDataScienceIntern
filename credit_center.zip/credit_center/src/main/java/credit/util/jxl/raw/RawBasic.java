package credit.util.jxl.raw;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RawBasic implements Serializable {
	private String cell_phone;//本机号码
	private String idcard;//登记身份证号
	private String real_name;//登记姓名
	private String reg_time;//入网时间
	public String getCell_phone() {
		return cell_phone;
	}
	public void setCell_phone(String cell_phone) {
		this.cell_phone = cell_phone;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getReal_name() {
		return real_name;
	}
	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}
	public String getReg_time() {
		return reg_time;
	}
	public void setReg_time(String reg_time) {
		this.reg_time = reg_time;
	}
}

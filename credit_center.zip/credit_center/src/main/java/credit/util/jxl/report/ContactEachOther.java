package credit.util.jxl.report;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
     *  运营商通话号码数量情况
 * @author YCM
 * @date 2019年7月1日 下午6:16:51
 */
@SuppressWarnings("serial")
public class ContactEachOther implements Serializable {
	@Field(type = FieldType.Integer)
	private	Integer	six_month_contact_each_other_cnt	;//	近6个月互通号码的数量
	@Field(type = FieldType.Text, index = false)
	private	String	six_month_contact_each_other_ratio	;//	近6个月互通号码的比率
	@Field(type = FieldType.Integer)
	private	Integer	three_month_contact_each_other_cnt	;//	近3个月互通号码的数量
	@Field(type = FieldType.Text, index = false)
	private	String	three_month_contact_each_other_ratio	;//	近3个月互通号码的比率
	@Field(type = FieldType.Integer)
	private	Integer	one_month_contact_each_other_cnt	;//	近1个月互通号码的数量
	@Field(type = FieldType.Text, index = false)
	private	String	one_month_contact_each_other_ratio	;//	近1个月互通号码的比率
	@Field(type = FieldType.Integer)
	private	Integer	one_week_contact_each_other_cnt	;//	近1周互通号码的数量
	@Field(type = FieldType.Text, index = false)
	private	String	one_week_contact_each_other_ratio	;//	近1周互通号码的比重
	public Integer getSix_month_contact_each_other_cnt() {
		return six_month_contact_each_other_cnt;
	}
	public void setSix_month_contact_each_other_cnt(Integer six_month_contact_each_other_cnt) {
		this.six_month_contact_each_other_cnt = six_month_contact_each_other_cnt;
	}
	public String getSix_month_contact_each_other_ratio() {
		return six_month_contact_each_other_ratio;
	}
	public void setSix_month_contact_each_other_ratio(String six_month_contact_each_other_ratio) {
		this.six_month_contact_each_other_ratio = six_month_contact_each_other_ratio;
	}
	public Integer getThree_month_contact_each_other_cnt() {
		return three_month_contact_each_other_cnt;
	}
	public void setThree_month_contact_each_other_cnt(Integer three_month_contact_each_other_cnt) {
		this.three_month_contact_each_other_cnt = three_month_contact_each_other_cnt;
	}
	public String getThree_month_contact_each_other_ratio() {
		return three_month_contact_each_other_ratio;
	}
	public void setThree_month_contact_each_other_ratio(String three_month_contact_each_other_ratio) {
		this.three_month_contact_each_other_ratio = three_month_contact_each_other_ratio;
	}
	public Integer getOne_month_contact_each_other_cnt() {
		return one_month_contact_each_other_cnt;
	}
	public void setOne_month_contact_each_other_cnt(Integer one_month_contact_each_other_cnt) {
		this.one_month_contact_each_other_cnt = one_month_contact_each_other_cnt;
	}
	public String getOne_month_contact_each_other_ratio() {
		return one_month_contact_each_other_ratio;
	}
	public void setOne_month_contact_each_other_ratio(String one_month_contact_each_other_ratio) {
		this.one_month_contact_each_other_ratio = one_month_contact_each_other_ratio;
	}
	public Integer getOne_week_contact_each_other_cnt() {
		return one_week_contact_each_other_cnt;
	}
	public void setOne_week_contact_each_other_cnt(Integer one_week_contact_each_other_cnt) {
		this.one_week_contact_each_other_cnt = one_week_contact_each_other_cnt;
	}
	public String getOne_week_contact_each_other_ratio() {
		return one_week_contact_each_other_ratio;
	}
	public void setOne_week_contact_each_other_ratio(String one_week_contact_each_other_ratio) {
		this.one_week_contact_each_other_ratio = one_week_contact_each_other_ratio;
	}
	
	
}

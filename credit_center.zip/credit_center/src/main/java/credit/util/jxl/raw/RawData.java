package credit.util.jxl.raw;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RawData implements Serializable {
	private String status;//抓取状态
	private RawBasicVersion basic_version;//原始数据
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public RawBasicVersion getBasic_version() {
		return basic_version;
	}
	public void setBasic_version(RawBasicVersion basic_version) {
		this.basic_version = basic_version;
	}
}

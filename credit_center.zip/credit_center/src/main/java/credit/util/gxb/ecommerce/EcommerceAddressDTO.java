package credit.util.gxb.ecommerce;

import static org.apache.commons.lang3.builder.ToStringStyle.SHORT_PREFIX_STYLE;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.alibaba.fastjson.annotation.JSONType;

/**
 * 
 * 
 * @author likun
 * @version $Id: EcommerceAddressDTO.java, v 0.1 May 18, 2016 8:32:26 PM likun Exp $
 */
@JSONType(ignores = {"id","baseInfoId","userId","status","createDate","lastUpdateDate"})
public class EcommerceAddressDTO implements Serializable {
  private static final long serialVersionUID = 1L;

  private Integer id;

  private Integer baseInfoId;

  private Integer userId;

  private String uuid;

  private String region;

  private String postCode;

  private String address;

  private String receiveName;

  private String telNumber;

  private Date tradeTime;

  private String tradeNo;

  private Byte defaultStatus;

  private Byte status;

  private Date createDate;

  private Date lastUpdateDate;


  public Integer getId() {
    return id;
  }



  public void setId(Integer id) {
    this.id = id;
  }



  public Integer getBaseInfoId() {
    return baseInfoId;
  }



  public void setBaseInfoId(Integer baseInfoId) {
    this.baseInfoId = baseInfoId;
  }



  public Integer getUserId() {
    return userId;
  }



  public void setUserId(Integer userId) {
    this.userId = userId;
  }



  public String getRegion() {
    return region;
  }



  public void setRegion(String region) {
    this.region = region;
  }



  public String getPostCode() {
    return postCode;
  }



  public void setPostCode(String postCode) {
    this.postCode = postCode;
  }



  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getReceiveName() {
    return receiveName;
  }

  public void setReceiveName(String receiveName) {
    this.receiveName = receiveName;
  }

  public String getTelNumber() {
    return telNumber;
  }

  public void setTelNumber(String telNumber) {
    this.telNumber = telNumber;
  }

  public Date getTradeTime() {
    return tradeTime;
  }

  public void setTradeTime(Date tradeTime) {
    this.tradeTime = tradeTime;
  }

  public String getTradeNo() {
    return tradeNo;
  }

  public void setTradeNo(String tradeNo) {
    this.tradeNo = tradeNo;
  }

  public Byte getStatus() {
    return status;
  }

  public void setStatus(Byte status) {
    this.status = status;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  public Date getLastUpdateDate() {
    return lastUpdateDate;
  }

  public void setLastUpdateDate(Date lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public Byte getDefaultStatus() {
    return defaultStatus;
  }

  public void setDefaultStatus(Byte defaultStatus) {
    this.defaultStatus = defaultStatus;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, SHORT_PREFIX_STYLE);
  }

}

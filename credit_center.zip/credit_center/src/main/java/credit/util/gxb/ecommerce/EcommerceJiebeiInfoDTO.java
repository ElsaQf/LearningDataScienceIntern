package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by DOmmy on 2017/11/19.
 */
@JSONType(ignores = {"id", "userId", "baseInfoId","jiebeiRefuseReason"})
public class EcommerceJiebeiInfoDTO implements Serializable{
    private static final long serialVersionUID = 5339380299393320757L;
    private Integer id;
    private Integer baseInfoId;
    private Integer userId;
    private Integer jiebeiAmount;

    private BigDecimal jiebeiBalance;
    /**
     *借呗日利率
     */
    private BigDecimal jiebeiRiskRate;
    /**
     *借呗是否逾期
     */
    private Integer jiebeiOvdAble;
    /**
     *借呗是否新开
     */
    private Integer jiebeiNewAble;
    /**
     *借呗拒绝原因
     */
    private String jiebeiRefuseReason;
    /**
     *借呗是否关闭
     */
    private Integer jiebeiIsClosed;
    /**
     *未还期数
     */
    private Integer jiebeiUnClearLoanCount;
    /**
     * 是否有借呗
     */
    private Integer jiebeiStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getJiebeiAmount() {
        return jiebeiAmount;
    }

    public void setJiebeiAmount(Integer jiebeiAmount) {
        this.jiebeiAmount = jiebeiAmount;
    }

    public BigDecimal getJiebeiBalance() {
        return jiebeiBalance;
    }

    public void setJiebeiBalance(BigDecimal jiebeiBalance) {
        this.jiebeiBalance = jiebeiBalance;
    }

    public BigDecimal getJiebeiRiskRate() {
        return jiebeiRiskRate;
    }

    public void setJiebeiRiskRate(BigDecimal jiebeiRiskRate) {
        this.jiebeiRiskRate = jiebeiRiskRate;
    }

    public Integer getJiebeiOvdAble() {
        return jiebeiOvdAble;
    }

    public void setJiebeiOvdAble(Integer jiebeiOvdAble) {
        this.jiebeiOvdAble = jiebeiOvdAble;
    }

    public Integer getJiebeiNewAble() {
        return jiebeiNewAble;
    }

    public void setJiebeiNewAble(Integer jiebeiNewAble) {
        this.jiebeiNewAble = jiebeiNewAble;
    }

    public String getJiebeiRefuseReason() {
        return jiebeiRefuseReason;
    }

    public void setJiebeiRefuseReason(String jiebeiRefuseReason) {
        this.jiebeiRefuseReason = jiebeiRefuseReason;
    }

    public Integer getJiebeiIsClosed() {
        return jiebeiIsClosed;
    }

    public void setJiebeiIsClosed(Integer jiebeiIsClosed) {
        this.jiebeiIsClosed = jiebeiIsClosed;
    }

    public Integer getJiebeiUnClearLoanCount() {
        return jiebeiUnClearLoanCount;
    }

    public void setJiebeiUnClearLoanCount(Integer jiebeiUnClearLoanCount) {
        this.jiebeiUnClearLoanCount = jiebeiUnClearLoanCount;
    }

    public Integer getJiebeiStatus() {
        return jiebeiStatus;
    }

    public void setJiebeiStatus(Integer jiebeiStatus) {
        this.jiebeiStatus = jiebeiStatus;
    }
}

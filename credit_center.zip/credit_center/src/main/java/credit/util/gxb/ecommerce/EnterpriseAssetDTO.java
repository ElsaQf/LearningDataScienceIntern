package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2018/12/25.
 */
public class EnterpriseAssetDTO implements Serializable {

    private static final long serialVersionUID = 3489832625380371469L;
    private String tradeNumber;
    private String orderNumber;
    private String tradeDetailUrl;
    private String title;
    private Date tradeDatetime;
    private String otherSide;
    private String otherSideAccount;
    private String otherSideName;
    private BigDecimal amount;
    private BigDecimal balance;
    private String cashierChannels;
    private String accountType;

    public String getTradeNumber() {
        return tradeNumber;
    }

    public void setTradeNumber(String tradeNumber) {
        this.tradeNumber = tradeNumber;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getTradeDetailUrl() {
        return tradeDetailUrl;
    }

    public void setTradeDetailUrl(String tradeDetailUrl) {
        this.tradeDetailUrl = tradeDetailUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getTradeDatetime() {
        return tradeDatetime;
    }

    public void setTradeDatetime(Date tradeDatetime) {
        this.tradeDatetime = tradeDatetime;
    }

    public String getOtherSide() {
        return otherSide;
    }

    public void setOtherSide(String otherSide) {
        this.otherSide = otherSide;
    }

    public String getOtherSideAccount() {
        return otherSideAccount;
    }

    public void setOtherSideAccount(String otherSideAccount) {
        this.otherSideAccount = otherSideAccount;
    }

    public String getOtherSideName() {
        return otherSideName;
    }

    public void setOtherSideName(String otherSideName) {
        this.otherSideName = otherSideName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getCashierChannels() {
        return cashierChannels;
    }

    public void setCashierChannels(String cashierChannels) {
        this.cashierChannels = cashierChannels;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
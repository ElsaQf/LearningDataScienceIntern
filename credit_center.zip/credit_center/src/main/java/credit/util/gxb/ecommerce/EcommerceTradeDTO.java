package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import static org.apache.commons.lang3.builder.ToStringStyle.SHORT_PREFIX_STYLE;

/**
 * 
 * 
 * @author likun
 * @version $Id: EcommerceTradeDTO.java, v 0.1 May 18, 2016 8:33:44 PM likun Exp $
 */
@JSONType(ignores = {"id","baseInfoId","userId","tradeStatus","tradeType","behaviorLableId","status","createDate","lastUpdateDate"})
public class EcommerceTradeDTO implements Serializable {
  private static final long serialVersionUID = 1L;

  private Integer id;

  private Integer baseInfoId;

  private Integer userId;

  private String title;

  private BigDecimal amount;

  private String tradeNo;

  private Date tradeTime;

  private Short tradeStatus;
  private String tradeStatusName;

  private Short tradeType;

  private Short txTypeId;
  private String txTypeName;

  private Short behaviorLableId;
  private String behaviorLableName;

  private String tradeDetailUrl;

  private String otherSide;

  private String otherSideAccount;

  private String otherSideName;
  /**
   * 1支付宝余额宝，2花呗，3银行卡
   */
  private Integer payType;
  /**
   * 如果是银行卡支付时展示银行以及卡号
   */
  private String payAccount;

  private Byte status;

  private Integer isDelete;

  private Date createDate;

  private Date lastUpdateDate;


  public Integer getId() {
    return id;
  }



  public void setId(Integer id) {
    this.id = id;
  }



  public Integer getBaseInfoId() {
    return baseInfoId;
  }



  public void setBaseInfoId(Integer baseInfoId) {
    this.baseInfoId = baseInfoId;
  }



  public Integer getUserId() {
    return userId;
  }



  public void setUserId(Integer userId) {
    this.userId = userId;
  }



  public String getTitle() {
    return title;
  }



  public void setTitle(String title) {
    this.title = title;
  }



  public BigDecimal getAmount() {
    return amount;
  }



  public void setAmount(BigDecimal amount) {
    this.amount = amount;
  }



  public String getTradeNo() {
    return tradeNo;
  }



  public void setTradeNo(String tradeNo) {
    this.tradeNo = tradeNo;
  }



  public Date getTradeTime() {
    return tradeTime;
  }



  public void setTradeTime(Date tradeTime) {
    this.tradeTime = tradeTime;
  }



  public Short getTradeStatus() {
    return tradeStatus;
  }



  public void setTradeStatus(Short tradeStatus) {
    this.tradeStatus = tradeStatus;
  }



  public Short getTradeType() {
    return tradeType;
  }



  public void setTradeType(Short tradeType) {
    this.tradeType = tradeType;
  }



  public Short getTxTypeId() {
    return txTypeId;
  }



  public void setTxTypeId(Short txTypeId) {
    this.txTypeId = txTypeId;
  }



  public Short getBehaviorLableId() {
    return behaviorLableId;
  }



  public void setBehaviorLableId(Short behaviorLableId) {
    this.behaviorLableId = behaviorLableId;
  }



  public String getTradeDetailUrl() {
    return tradeDetailUrl;
  }



  public void setTradeDetailUrl(String tradeDetailUrl) {
    this.tradeDetailUrl = tradeDetailUrl;
  }



  public String getOtherSide() {
    return otherSide;
  }



  public void setOtherSide(String otherSide) {
    this.otherSide = otherSide;
  }



  public String getOtherSideAccount() {
    return otherSideAccount;
  }



  public void setOtherSideAccount(String otherSideAccount) {
    this.otherSideAccount = otherSideAccount;
  }



  public String getOtherSideName() {
    return otherSideName;
  }



  public void setOtherSideName(String otherSideName) {
    this.otherSideName = otherSideName;
  }



  public Byte getStatus() {
    return status;
  }



  public void setStatus(Byte status) {
    this.status = status;
  }



  public Date getCreateDate() {
    return createDate;
  }



  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }



  public Date getLastUpdateDate() {
    return lastUpdateDate;
  }



  public void setLastUpdateDate(Date lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  public String getTradeStatusName() {
    return tradeStatusName;
  }

  public void setTradeStatusName(String tradeStatusName) {
    this.tradeStatusName = tradeStatusName;
  }

  public String getTxTypeName() {
    return txTypeName;
  }

  public void setTxTypeName(String txTypeName) {
    this.txTypeName = txTypeName;
  }

  public String getBehaviorLableName() {
    return behaviorLableName;
  }

  public void setBehaviorLableName(String behaviorLableName) {
    this.behaviorLableName = behaviorLableName;
  }

  public Integer getIsDelete() {
    return isDelete;
  }

  public void setIsDelete(Integer isDelete) {
    this.isDelete = isDelete;
  }

  public Integer getPayType() {
    return payType;
  }

  public void setPayType(Integer payType) {
    this.payType = payType;
  }

  public String getPayAccount() {
    return payAccount;
  }

  public void setPayAccount(String payAccount) {
    this.payAccount = payAccount;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, SHORT_PREFIX_STYLE);
  }
}

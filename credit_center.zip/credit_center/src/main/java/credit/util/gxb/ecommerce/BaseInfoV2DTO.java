package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yaojun on 2019/1/10.
 */
public class BaseInfoV2DTO implements Serializable {
    private static final long serialVersionUID = -98573437936128847L;
    private EcommerceBaseInfoDTO              ecommerceBaseInfo;
    private List<EcommerceTradeDTO>            ecommerceTrades;
    private List<EcommerceAddressDTO> ecommerceConsigneeAddresses;
    private List<EcommerceBindedBankCardDTO>   ecommerceBindedBankCards;
    private List<EcommerceFeesAccountDTO>   ecommercePaymentAccounts;
    private List<TaobaoOrderDTO> taobaoOrders;
    private EcommerceHuabeiInfoDTO huabeiInfo;
    private List<EcommerceTransferBankCardDTO> transferBankCards;
    private List<AlipayBillDetailDTO> alipayBillDetailList;
    private List<AlipayContactDTO> alipayContactList;
    private List<TradeContactDTO> tradeContactList;

    public EcommerceBaseInfoDTO getEcommerceBaseInfo() {
        return ecommerceBaseInfo;
    }

    public void setEcommerceBaseInfo(EcommerceBaseInfoDTO ecommerceBaseInfo) {
        this.ecommerceBaseInfo = ecommerceBaseInfo;
    }

    public List<EcommerceTradeDTO> getEcommerceTrades() {
        return ecommerceTrades;
    }

    public void setEcommerceTrades(List<EcommerceTradeDTO> ecommerceTrades) {
        this.ecommerceTrades = ecommerceTrades;
    }

    public List<EcommerceAddressDTO> getEcommerceConsigneeAddresses() {
        return ecommerceConsigneeAddresses;
    }

    public void setEcommerceConsigneeAddresses(List<EcommerceAddressDTO> ecommerceConsigneeAddresses) {
        this.ecommerceConsigneeAddresses = ecommerceConsigneeAddresses;
    }

    public List<EcommerceBindedBankCardDTO> getEcommerceBindedBankCards() {
        return ecommerceBindedBankCards;
    }

    public void setEcommerceBindedBankCards(List<EcommerceBindedBankCardDTO> ecommerceBindedBankCards) {
        this.ecommerceBindedBankCards = ecommerceBindedBankCards;
    }

    public List<EcommerceFeesAccountDTO> getEcommercePaymentAccounts() {
        return ecommercePaymentAccounts;
    }

    public void setEcommercePaymentAccounts(List<EcommerceFeesAccountDTO> ecommercePaymentAccounts) {
        this.ecommercePaymentAccounts = ecommercePaymentAccounts;
    }

    public List<TaobaoOrderDTO> getTaobaoOrders() {
        return taobaoOrders;
    }

    public void setTaobaoOrders(List<TaobaoOrderDTO> taobaoOrders) {
        this.taobaoOrders = taobaoOrders;
    }

    public EcommerceHuabeiInfoDTO getHuabeiInfo() {
        return huabeiInfo;
    }

    public void setHuabeiInfo(EcommerceHuabeiInfoDTO huabeiInfo) {
        this.huabeiInfo = huabeiInfo;
    }

    public List<EcommerceTransferBankCardDTO> getTransferBankCards() {
        return transferBankCards;
    }

    public void setTransferBankCards(List<EcommerceTransferBankCardDTO> transferBankCards) {
        this.transferBankCards = transferBankCards;
    }

    public List<AlipayBillDetailDTO> getAlipayBillDetailList() {
        return alipayBillDetailList;
    }

    public void setAlipayBillDetailList(List<AlipayBillDetailDTO> alipayBillDetailList) {
        this.alipayBillDetailList = alipayBillDetailList;
    }

    public List<AlipayContactDTO> getAlipayContactList() {
        return alipayContactList;
    }

    public void setAlipayContactList(List<AlipayContactDTO> alipayContactList) {
        this.alipayContactList = alipayContactList;
    }

    public List<TradeContactDTO> getTradeContactList() {
        return tradeContactList;
    }

    public void setTradeContactList(List<TradeContactDTO> tradeContactList) {
        this.tradeContactList = tradeContactList;
    }
}
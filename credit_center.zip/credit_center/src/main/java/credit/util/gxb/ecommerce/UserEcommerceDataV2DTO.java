package credit.util.gxb.ecommerce;

import java.util.Date;

/**
 * Created by yaojun on 2019/1/10.
 */
public class UserEcommerceDataV2DTO extends PushDataDTO {

    private static final long serialVersionUID = 3103678454906960030L;
    private BaseInfoV2DTO baseInfo;
    private MyBankV2DTO myBank;
    private AlipayEnterpriseV2DTO alipayEnterprise;
    private TaobaoSellerV2DTO taobaoSeller;

    public UserEcommerceDataV2DTO(){
        baseInfo = new BaseInfoV2DTO();
        myBank = new MyBankV2DTO();
        alipayEnterprise = new AlipayEnterpriseV2DTO();
        taobaoSeller = new TaobaoSellerV2DTO();
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Date getImportDate() {
        return importDate;
    }

    public void setImportDate(Date importDate) {
        this.importDate = importDate;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public BaseInfoV2DTO getBaseInfo() {
        return baseInfo;
    }

    public void setBaseInfo(BaseInfoV2DTO baseInfo) {
        this.baseInfo = baseInfo;
    }

    public MyBankV2DTO getMyBank() {
        return myBank;
    }

    public void setMyBank(MyBankV2DTO myBank) {
        this.myBank = myBank;
    }

    public AlipayEnterpriseV2DTO getAlipayEnterprise() {
        return alipayEnterprise;
    }

    public void setAlipayEnterprise(AlipayEnterpriseV2DTO alipayEnterprise) {
        this.alipayEnterprise = alipayEnterprise;
    }

    public TaobaoSellerV2DTO getTaobaoSeller() {
        return taobaoSeller;
    }

    public void setTaobaoSeller(TaobaoSellerV2DTO taobaoSeller) {
        this.taobaoSeller = taobaoSeller;
    }
}

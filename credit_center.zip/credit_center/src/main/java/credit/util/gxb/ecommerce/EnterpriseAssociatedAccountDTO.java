package credit.util.gxb.ecommerce;

import java.io.Serializable;

/**
 * Created by yaojun on 2018/12/25.
 */
public class EnterpriseAssociatedAccountDTO implements Serializable {
    private static final long serialVersionUID = -5063871453054851756L;
    private String accountName;

    public String getAccountName() {
        return accountName;
    }

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
}
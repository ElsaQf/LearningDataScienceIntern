package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2018/6/4.
 */
public class MyBankLoanDetailDTO implements Serializable {
    private BigDecimal loanAmt;
    private Date loanDate;
    private String loanArNo;
    private String loanTerm;
    private String lendDetailUrl;
    private String statusDesc;
    private String repayModeDesc;
    private String channel;
    private String repayAccount;
    private String loanPdName;
    private String repayAccountType;
    private String ownerPhoneNo;
    private Date applyDate;

    public BigDecimal getLoanAmt() {
        return loanAmt;
    }

    public void setLoanAmt(BigDecimal loanAmt) {
        this.loanAmt = loanAmt;
    }

    public Date getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(Date loanDate) {
        this.loanDate = loanDate;
    }

    public String getLoanArNo() {
        return loanArNo;
    }

    public void setLoanArNo(String loanArNo) {
        this.loanArNo = loanArNo;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public String getLendDetailUrl() {
        return lendDetailUrl;
    }

    public void setLendDetailUrl(String lendDetailUrl) {
        this.lendDetailUrl = lendDetailUrl;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public String getRepayModeDesc() {
        return repayModeDesc;
    }

    public void setRepayModeDesc(String repayModeDesc) {
        this.repayModeDesc = repayModeDesc;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getRepayAccount() {
        return repayAccount;
    }

    public void setRepayAccount(String repayAccount) {
        this.repayAccount = repayAccount;
    }

    public String getLoanPdName() {
        return loanPdName;
    }

    public void setLoanPdName(String loanPdName) {
        this.loanPdName = loanPdName;
    }

    public String getRepayAccountType() {
        return repayAccountType;
    }

    public void setRepayAccountType(String repayAccountType) {
        this.repayAccountType = repayAccountType;
    }

    public String getOwnerPhoneNo() {
        return ownerPhoneNo;
    }

    public void setOwnerPhoneNo(String ownerPhoneNo) {
        this.ownerPhoneNo = ownerPhoneNo;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }
}
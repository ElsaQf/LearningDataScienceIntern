package credit.util.gxb.chsi;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ChsiRawData implements Serializable {
	
	private UserChsiDataDTO authResult;

	public UserChsiDataDTO getAuthResult() {
		return authResult;
	}

	public void setAuthResult(UserChsiDataDTO authResult) {
		this.authResult = authResult;
	} 
}

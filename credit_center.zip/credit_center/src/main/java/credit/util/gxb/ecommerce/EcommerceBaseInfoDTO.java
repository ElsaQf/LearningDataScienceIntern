package credit.util.gxb.ecommerce;

import static org.apache.commons.lang3.builder.ToStringStyle.SHORT_PREFIX_STYLE;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.alibaba.fastjson.annotation.JSONType;


/**
 * 
 * 
 * @author likun
 * @version $Id: EcommerceBaseInfoDTO.java, v 0.1 May 18, 2016 8:33:03 PM likun Exp $
 */
@JSONType(ignores = {"id", "userId", "lastPreProcessDatetime", "jiebeiBalance", "huabeiNextMonthPayment", "huabeiCurrentMonthPayment", "huabeiPayDay", "huabeiOverdueBillCnt", "huabeiOverdueDays", "createDate", "lastUpdateDate"})
public class EcommerceBaseInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer id;

    private Integer userId;

    private String name;

    private String taobaoAccount;

    private String alipayAccount;

    private String alipayUserId;
    /**
     * 账号类型
     */
    private String alipayAccountType;

    private String identityCard;

    private String mobile;

    private String email;

    private Date alipayRegistrationDatetime;

    private Boolean isVerified;

    private BigDecimal alipayBalance;

    private BigDecimal yuebaoBalance;

    private Integer huabeiStatus;
    private Integer huabeiAmount;

    private BigDecimal huabeiBalance;

    /**
     * 花呗罚息
     */
    private BigDecimal huabeiPenaltyAmount;

    /**
     * 花呗逾期天数
     */
    private Integer huabeiOverdueDays;

    private Integer jiebeiAmount;

    private BigDecimal jiebeiBalance;

    private Integer creditLevelAsBuyer;

    private Integer creditLevelAsSeller;

    private Byte status;

    private Date lastPreProcessDatetime;

    private Date createDate;

    private Date lastUpdateDate;

    private Integer taoScore;

    private BigDecimal huabeiNextMonthPayment;

    /**
     * 花呗当月还款额
     *
     */
    private BigDecimal huabeiCurrentMonthPayment;

    /**
     * 花呗还款日
     *
     */
    private Integer huabeiPayDay;

    /**
     * 花呗还款日
     *
     */
    private Integer huabeiOverdueBillCnt;
    private BigDecimal huabeiOriginalAmount;
    /**
     * 支付宝余额支付开关，1开0关
     */
    private Integer balancePaymentEnable;
    /**
     * 余额宝累计收益
     */
    private BigDecimal yuebaoIncome;
    /**
     * 	天猫积分
     */
    private Integer tmallScore;
    /**
     *  蚂蚁会员积分
     */
    private Integer antMemberScore;
    /**
     * 	邮编
     */
    private String postCode;
    /**
     * 	天猫详细地址
     */
    private String detailAddress;
    /**
     * 	淘宝绑定微博账号
     */
    private String weiboAccount;
    /**
     * 	淘宝绑定微博昵称
     */
    private String weiboNickName;
    /**
     * 	买家好评率
     */
    private BigDecimal rateSummaryAsBuyer;
    /**
     * 	近6个月买家好评率
     */
    private Integer sixMonthGoodRateAsBuyer;
    /**
     * 	总计买家好评率
     */
    private Integer totalGoodRateAsBuyer;
    /**
     * 	近6个月买家中评率
     */
    private Integer sixMonthNeutralRateAsBuyer;
    /**
     * 	总计买家中评率
     */
    private Integer totalNeutralRateAsBuyer;
    /**
     * 	近6个月买家差评率
     */
    private Integer sixMonthBadRateAsBuyer;
    /**
     * 	总计买家差评率
     */
    private Integer totalBadRateAsBuyer;
    /**
     * 	卖家好评率
     */
    private BigDecimal rateSummaryAsSeller;
    /**
     * 	近6个月卖家好评数
     */
    private Integer sixMonthGoodRateAsSeller;
    /**
     * 	总计卖家好评数
     */
    private Integer totalGoodRateAsSeller;
    /**
     * 	近6个月卖家中评数
     */
    private Integer sixMonthNeutralRateAsSeller;
    /**
     * 	总计卖家中评数
     */
    private Integer totalNeutralRateAsSeller;
    /**
     * 	近6个月卖家差评数
     */
    private Integer sixMonthBadRateAsSeller;
    /**
     * 	总计卖家差评数
     */
    private Integer totalBadRateAsSeller;

    private String taobaoUserId;

    private Date earliestTaobaoOrderDate;

    private String taobaoImgUrl;

    private Integer gender;

    private Date birthday;
    //基金
    private BigDecimal fundAsset;
    //存金宝
    private BigDecimal cjbAsset;
    //招财宝
    private BigDecimal zcbAsset;
    //理财
    private BigDecimal financeAsset;

    public Integer getId() {
        return id;
    }



    public void setId(Integer id) {
        this.id = id;
    }



    public Integer getUserId() {
        return userId;
    }



    public void setUserId(Integer userId) {
        this.userId = userId;
    }



    public String getName() {
        return name;
    }



    public void setName(String name) {
        this.name = name;
    }



    public String getTaobaoAccount() {
        return taobaoAccount;
    }



    public void setTaobaoAccount(String taobaoAccount) {
        this.taobaoAccount = taobaoAccount;
    }



    public String getAlipayAccount() {
        return alipayAccount;
    }



    public void setAlipayAccount(String alipayAccount) {
        this.alipayAccount = alipayAccount;
    }



    public String getIdentityCard() {
        return identityCard;
    }



    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }



    public String getMobile() {
        return mobile;
    }



    public void setMobile(String mobile) {
        this.mobile = mobile;
    }



    public String getEmail() {
        return email;
    }



    public void setEmail(String email) {
        this.email = email;
    }



    public Date getAlipayRegistrationDatetime() {
        return alipayRegistrationDatetime;
    }



    public void setAlipayRegistrationDatetime(Date alipayRegistrationDatetime) {
        this.alipayRegistrationDatetime = alipayRegistrationDatetime;
    }

    public Integer getHuabeiStatus() {
        return huabeiStatus;
    }

    public void setHuabeiStatus(Integer huabeiStatus) {
        this.huabeiStatus = huabeiStatus;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }



    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }



    public BigDecimal getAlipayBalance() {
        return alipayBalance;
    }



    public void setAlipayBalance(BigDecimal alipayBalance) {
        this.alipayBalance = alipayBalance;
    }



    public BigDecimal getYuebaoBalance() {
        return yuebaoBalance;
    }



    public void setYuebaoBalance(BigDecimal yuebaoBalance) {
        this.yuebaoBalance = yuebaoBalance;
    }



    public Integer getHuabeiAmount() {
        return huabeiAmount;
    }



    public void setHuabeiAmount(Integer huabeiAmount) {
        this.huabeiAmount = huabeiAmount;
    }



    public BigDecimal getHuabeiBalance() {
        return huabeiBalance;
    }



    public void setHuabeiBalance(BigDecimal huabeiBalance) {
        this.huabeiBalance = huabeiBalance;
    }



    public Integer getJiebeiAmount() {
        return jiebeiAmount;
    }



    public void setJiebeiAmount(Integer jiebeiAmount) {
        this.jiebeiAmount = jiebeiAmount;
    }



    public BigDecimal getJiebeiBalance() {
        return jiebeiBalance;
    }



    public void setJiebeiBalance(BigDecimal jiebeiBalance) {
        this.jiebeiBalance = jiebeiBalance;
    }



    public Integer getCreditLevelAsBuyer() {
        return creditLevelAsBuyer;
    }



    public void setCreditLevelAsBuyer(Integer creditLevelAsBuyer) {
        this.creditLevelAsBuyer = creditLevelAsBuyer;
    }



    public Integer getCreditLevelAsSeller() {
        return creditLevelAsSeller;
    }



    public void setCreditLevelAsSeller(Integer creditLevelAsSeller) {
        this.creditLevelAsSeller = creditLevelAsSeller;
    }



    public Byte getStatus() {
        return status;
    }



    public void setStatus(Byte status) {
        this.status = status;
    }

    public Integer getTaoScore() {
        return taoScore;
    }

    public void setTaoScore(Integer taoScore) {
        this.taoScore = taoScore;
    }

    public Date getLastPreProcessDatetime() {
        return lastPreProcessDatetime;
    }



    public void setLastPreProcessDatetime(Date lastPreProcessDatetime) {
        this.lastPreProcessDatetime = lastPreProcessDatetime;
    }



    public Date getCreateDate() {
        return createDate;
    }



    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }


    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }


    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAlipayUserId() {
        return alipayUserId;
    }

    public void setAlipayUserId(String alipayUserId) {
        this.alipayUserId = alipayUserId;
    }

    public String getAlipayAccountType() {
        return alipayAccountType;
    }

    public void setAlipayAccountType(String alipayAccountType) {
        this.alipayAccountType = alipayAccountType;
    }


    public BigDecimal getHuabeiPenaltyAmount() {
        return huabeiPenaltyAmount;
    }



    public void setHuabeiPenaltyAmount(BigDecimal huabeiPenaltyAmount) {
        this.huabeiPenaltyAmount = huabeiPenaltyAmount;
    }



    public Integer getHuabeiOverdueDays() {
        return huabeiOverdueDays;
    }



    public void setHuabeiOverdueDays(Integer huabeiOverdueDays) {
        this.huabeiOverdueDays = huabeiOverdueDays;
    }

    public BigDecimal getHuabeiNextMonthPayment() {
        return huabeiNextMonthPayment;
    }

    public void setHuabeiNextMonthPayment(BigDecimal huabeiNextMonthPayment) {
        this.huabeiNextMonthPayment = huabeiNextMonthPayment;
    }

    public BigDecimal getHuabeiCurrentMonthPayment() {
        return huabeiCurrentMonthPayment;
    }

    public void setHuabeiCurrentMonthPayment(BigDecimal huabeiCurrentMonthPayment) {
        this.huabeiCurrentMonthPayment = huabeiCurrentMonthPayment;
    }

    public Integer getHuabeiPayDay() {
        return huabeiPayDay;
    }

    public void setHuabeiPayDay(Integer huabeiPayDay) {
        this.huabeiPayDay = huabeiPayDay;
    }

    public Integer getHuabeiOverdueBillCnt() {
        return huabeiOverdueBillCnt;
    }

    public void setHuabeiOverdueBillCnt(Integer huabeiOverdueBillCnt) {
        this.huabeiOverdueBillCnt = huabeiOverdueBillCnt;
    }

    public BigDecimal getHuabeiOriginalAmount() {
        return huabeiOriginalAmount;
    }

    public void setHuabeiOriginalAmount(BigDecimal huabeiOriginalAmount) {
        this.huabeiOriginalAmount = huabeiOriginalAmount;
    }

    public Integer getBalancePaymentEnable() {
        return balancePaymentEnable;
    }

    public void setBalancePaymentEnable(Integer balancePaymentEnable) {
        this.balancePaymentEnable = balancePaymentEnable;
    }

    public BigDecimal getYuebaoIncome() {
        return yuebaoIncome;
    }

    public void setYuebaoIncome(BigDecimal yuebaoIncome) {
        this.yuebaoIncome = yuebaoIncome;
    }

    public Integer getTmallScore() {
        return tmallScore;
    }

    public void setTmallScore(Integer tmallScore) {
        this.tmallScore = tmallScore;
    }

    public Integer getAntMemberScore() {
        return antMemberScore;
    }

    public void setAntMemberScore(Integer antMemberScore) {
        this.antMemberScore = antMemberScore;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getDetailAddress() {
        return detailAddress;
    }

    public void setDetailAddress(String detailAddress) {
        this.detailAddress = detailAddress;
    }

    public String getWeiboAccount() {
        return weiboAccount;
    }

    public void setWeiboAccount(String weiboAccount) {
        this.weiboAccount = weiboAccount;
    }

    public String getWeiboNickName() {
        return weiboNickName;
    }

    public void setWeiboNickName(String weiboNickName) {
        this.weiboNickName = weiboNickName;
    }

    public BigDecimal getRateSummaryAsBuyer() {
        return rateSummaryAsBuyer;
    }

    public void setRateSummaryAsBuyer(BigDecimal rateSummaryAsBuyer) {
        this.rateSummaryAsBuyer = rateSummaryAsBuyer;
    }

    public Integer getSixMonthGoodRateAsBuyer() {
        return sixMonthGoodRateAsBuyer;
    }

    public void setSixMonthGoodRateAsBuyer(Integer sixMonthGoodRateAsBuyer) {
        this.sixMonthGoodRateAsBuyer = sixMonthGoodRateAsBuyer;
    }

    public Integer getTotalGoodRateAsBuyer() {
        return totalGoodRateAsBuyer;
    }

    public void setTotalGoodRateAsBuyer(Integer totalGoodRateAsBuyer) {
        this.totalGoodRateAsBuyer = totalGoodRateAsBuyer;
    }

    public Integer getSixMonthNeutralRateAsBuyer() {
        return sixMonthNeutralRateAsBuyer;
    }

    public void setSixMonthNeutralRateAsBuyer(Integer sixMonthNeutralRateAsBuyer) {
        this.sixMonthNeutralRateAsBuyer = sixMonthNeutralRateAsBuyer;
    }

    public Integer getTotalNeutralRateAsBuyer() {
        return totalNeutralRateAsBuyer;
    }

    public void setTotalNeutralRateAsBuyer(Integer totalNeutralRateAsBuyer) {
        this.totalNeutralRateAsBuyer = totalNeutralRateAsBuyer;
    }

    public Integer getSixMonthBadRateAsBuyer() {
        return sixMonthBadRateAsBuyer;
    }

    public void setSixMonthBadRateAsBuyer(Integer sixMonthBadRateAsBuyer) {
        this.sixMonthBadRateAsBuyer = sixMonthBadRateAsBuyer;
    }

    public Integer getTotalBadRateAsBuyer() {
        return totalBadRateAsBuyer;
    }

    public void setTotalBadRateAsBuyer(Integer totalBadRateAsBuyer) {
        this.totalBadRateAsBuyer = totalBadRateAsBuyer;
    }

    public BigDecimal getRateSummaryAsSeller() {
        return rateSummaryAsSeller;
    }

    public void setRateSummaryAsSeller(BigDecimal rateSummaryAsSeller) {
        this.rateSummaryAsSeller = rateSummaryAsSeller;
    }

    public Integer getSixMonthGoodRateAsSeller() {
        return sixMonthGoodRateAsSeller;
    }

    public void setSixMonthGoodRateAsSeller(Integer sixMonthGoodRateAsSeller) {
        this.sixMonthGoodRateAsSeller = sixMonthGoodRateAsSeller;
    }

    public Integer getTotalGoodRateAsSeller() {
        return totalGoodRateAsSeller;
    }

    public void setTotalGoodRateAsSeller(Integer totalGoodRateAsSeller) {
        this.totalGoodRateAsSeller = totalGoodRateAsSeller;
    }

    public Integer getSixMonthNeutralRateAsSeller() {
        return sixMonthNeutralRateAsSeller;
    }

    public void setSixMonthNeutralRateAsSeller(Integer sixMonthNeutralRateAsSeller) {
        this.sixMonthNeutralRateAsSeller = sixMonthNeutralRateAsSeller;
    }

    public Integer getTotalNeutralRateAsSeller() {
        return totalNeutralRateAsSeller;
    }

    public void setTotalNeutralRateAsSeller(Integer totalNeutralRateAsSeller) {
        this.totalNeutralRateAsSeller = totalNeutralRateAsSeller;
    }

    public Integer getSixMonthBadRateAsSeller() {
        return sixMonthBadRateAsSeller;
    }

    public void setSixMonthBadRateAsSeller(Integer sixMonthBadRateAsSeller) {
        this.sixMonthBadRateAsSeller = sixMonthBadRateAsSeller;
    }

    public Integer getTotalBadRateAsSeller() {
        return totalBadRateAsSeller;
    }

    public void setTotalBadRateAsSeller(Integer totalBadRateAsSeller) {
        this.totalBadRateAsSeller = totalBadRateAsSeller;
    }

    public String getTaobaoUserId() {
        return taobaoUserId;
    }

    public void setTaobaoUserId(String taobaoUserId) {
        this.taobaoUserId = taobaoUserId;
    }

    public Date getEarliestTaobaoOrderDate() {
        return earliestTaobaoOrderDate;
    }

    public void setEarliestTaobaoOrderDate(Date earliestTaobaoOrderDate) {
        this.earliestTaobaoOrderDate = earliestTaobaoOrderDate;
    }

    public String getTaobaoImgUrl() {
        return taobaoImgUrl;
    }

    public void setTaobaoImgUrl(String taobaoImgUrl) {
        this.taobaoImgUrl = taobaoImgUrl;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public BigDecimal getFundAsset() {
        return fundAsset;
    }

    public void setFundAsset(BigDecimal fundAsset) {
        this.fundAsset = fundAsset;
    }

    public BigDecimal getCjbAsset() {
        return cjbAsset;
    }

    public void setCjbAsset(BigDecimal cjbAsset) {
        this.cjbAsset = cjbAsset;
    }

    public BigDecimal getZcbAsset() {
        return zcbAsset;
    }

    public void setZcbAsset(BigDecimal zcbAsset) {
        this.zcbAsset = zcbAsset;
    }

    public BigDecimal getFinanceAsset() {
        return financeAsset;
    }

    public void setFinanceAsset(BigDecimal financeAsset) {
        this.financeAsset = financeAsset;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, SHORT_PREFIX_STYLE);
    }
}

package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2018/6/4.
 */
public class MyBankAssetDetailDTO implements Serializable {
    private BigDecimal tradeAmt;
    private Date transDate;
    private String assetAccount;
    private String assetAccountType;
    private String assetDetailUrl;
    private String bizNo;
    private String tradeType;

    public BigDecimal getTradeAmt() {
        return tradeAmt;
    }

    public void setTradeAmt(BigDecimal tradeAmt) {
        this.tradeAmt = tradeAmt;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public String getAssetAccount() {
        return assetAccount;
    }

    public void setAssetAccount(String assetAccount) {
        this.assetAccount = assetAccount;
    }

    public String getAssetAccountType() {
        return assetAccountType;
    }

    public void setAssetAccountType(String assetAccountType) {
        this.assetAccountType = assetAccountType;
    }

    public String getAssetDetailUrl() {
        return assetDetailUrl;
    }

    public void setAssetDetailUrl(String assetDetailUrl) {
        this.assetDetailUrl = assetDetailUrl;
    }

    public String getBizNo() {
        return bizNo;
    }

    public void setBizNo(String bizNo) {
        this.bizNo = bizNo;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }
}
package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by yaojun on 2018/6/4.
 */
public class MyBankBindInfoDTO implements Serializable {
    private String weBankRepayAccount;
    private String weBankRepayAccountType;
    private BigDecimal weBankTotalAmount;
    private BigDecimal weBankOverdueAmount;
    private String weBankUserId;

    public String getWeBankRepayAccount() {
        return weBankRepayAccount;
    }

    public void setWeBankRepayAccount(String weBankRepayAccount) {
        this.weBankRepayAccount = weBankRepayAccount;
    }

    public String getWeBankRepayAccountType() {
        return weBankRepayAccountType;
    }

    public void setWeBankRepayAccountType(String weBankRepayAccountType) {
        this.weBankRepayAccountType = weBankRepayAccountType;
    }

    public BigDecimal getWeBankTotalAmount() {
        return weBankTotalAmount;
    }

    public void setWeBankTotalAmount(BigDecimal weBankTotalAmount) {
        this.weBankTotalAmount = weBankTotalAmount;
    }

    public BigDecimal getWeBankOverdueAmount() {
        return weBankOverdueAmount;
    }

    public void setWeBankOverdueAmount(BigDecimal weBankOverdueAmount) {
        this.weBankOverdueAmount = weBankOverdueAmount;
    }

    public String getWeBankUserId() {
        return weBankUserId;
    }

    public void setWeBankUserId(String weBankUserId) {
        this.weBankUserId = weBankUserId;
    }
}

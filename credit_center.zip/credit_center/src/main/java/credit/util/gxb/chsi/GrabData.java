package credit.util.gxb.chsi;

import java.io.Serializable;

@SuppressWarnings("serial")
public class GrabData implements Serializable {
	
	private String stage;// 当前任务阶段状态。PREPARE：预准备阶段；LOGINED：登录成功阶段；FINISHED:任务完成阶段
	private String phaseStatus;// 数据
	private GrabRemarkData extra;//状态为失败为LOGIN_FAILED、FAILED时给出相应的提示信息。如：用户名密码错误。状态为失败为REFRESH_IMAGE_SUCCESS时，是图片验证码的base64。
	
	public String getPhaseStatus() {
		return phaseStatus;
	}
	public void setPhaseStatus(String phaseStatus) {
		this.phaseStatus = phaseStatus;
	}
	public GrabRemarkData getExtra() {
		return extra;
	}
	public void setExtra(GrabRemarkData extra) {
		this.extra = extra;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
}

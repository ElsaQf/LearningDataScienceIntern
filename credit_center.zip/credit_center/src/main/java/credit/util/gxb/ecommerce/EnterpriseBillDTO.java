package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by yaojun on 2018/12/25.
 */
public class EnterpriseBillDTO implements Serializable {
    private static final long serialVersionUID = -7297418635371042305L;
    private Date billMonth;
    private BigDecimal incomeAmount;
    private Integer incomeCount;
    private BigDecimal expendAmount;
    private Integer expendCount;
    private List<EnterpriseBillDetailDTO> incomeDetails;
    private List<EnterpriseBillDetailDTO> expendDetails;

    public Date getBillMonth() {
        return billMonth;
    }

    public void setBillMonth(Date billMonth) {
        this.billMonth = billMonth;
    }

    public BigDecimal getIncomeAmount() {
        return incomeAmount;
    }

    public void setIncomeAmount(BigDecimal incomeAmount) {
        this.incomeAmount = incomeAmount;
    }

    public Integer getIncomeCount() {
        return incomeCount;
    }

    public void setIncomeCount(Integer incomeCount) {
        this.incomeCount = incomeCount;
    }

    public BigDecimal getExpendAmount() {
        return expendAmount;
    }

    public void setExpendAmount(BigDecimal expendAmount) {
        this.expendAmount = expendAmount;
    }

    public Integer getExpendCount() {
        return expendCount;
    }

    public void setExpendCount(Integer expendCount) {
        this.expendCount = expendCount;
    }

    public List<EnterpriseBillDetailDTO> getIncomeDetails() {
        return incomeDetails;
    }

    public void setIncomeDetails(List<EnterpriseBillDetailDTO> incomeDetails) {
        this.incomeDetails = incomeDetails;
    }

    public List<EnterpriseBillDetailDTO> getExpendDetails() {
        return expendDetails;
    }

    public void setExpendDetails(List<EnterpriseBillDetailDTO> expendDetails) {
        this.expendDetails = expendDetails;
    }
}
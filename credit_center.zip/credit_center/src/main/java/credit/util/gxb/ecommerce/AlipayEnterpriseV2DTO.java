package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yaojun on 2019/1/10.
 */
public class AlipayEnterpriseV2DTO implements Serializable {

    private static final long serialVersionUID = -6186441744632132831L;
    private EnterpriseBindInfoDTO enterpriseBindInfo;
    private List<EnterpriseBillDTO> enterpriseBillList;
    private List<EnterpriseAssetDTO> enterpriseAssetList;
    private List<EnterpriseTradeDTO> enterpriseTradeList;
    private List<EnterpriseFundDTO> enterpriseFundList;

    public EnterpriseBindInfoDTO getEnterpriseBindInfo() {
        return enterpriseBindInfo;
    }

    public void setEnterpriseBindInfo(EnterpriseBindInfoDTO enterpriseBindInfo) {
        this.enterpriseBindInfo = enterpriseBindInfo;
    }

    public List<EnterpriseBillDTO> getEnterpriseBillList() {
        return enterpriseBillList;
    }

    public void setEnterpriseBillList(List<EnterpriseBillDTO> enterpriseBillList) {
        this.enterpriseBillList = enterpriseBillList;
    }

    public List<EnterpriseAssetDTO> getEnterpriseAssetList() {
        return enterpriseAssetList;
    }

    public void setEnterpriseAssetList(List<EnterpriseAssetDTO> enterpriseAssetList) {
        this.enterpriseAssetList = enterpriseAssetList;
    }

    public List<EnterpriseTradeDTO> getEnterpriseTradeList() {
        return enterpriseTradeList;
    }

    public void setEnterpriseTradeList(List<EnterpriseTradeDTO> enterpriseTradeList) {
        this.enterpriseTradeList = enterpriseTradeList;
    }

    public List<EnterpriseFundDTO> getEnterpriseFundList() {
        return enterpriseFundList;
    }

    public void setEnterpriseFundList(List<EnterpriseFundDTO> enterpriseFundList) {
        this.enterpriseFundList = enterpriseFundList;
    }
}
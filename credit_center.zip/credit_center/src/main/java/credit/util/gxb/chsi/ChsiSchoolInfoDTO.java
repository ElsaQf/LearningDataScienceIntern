package credit.util.gxb.chsi;

import java.io.Serializable;
import java.util.Date;

/**
 * @author
 */
public class ChsiSchoolInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 姓名
     */
    private String name;

    /**
     * 性别,0(未知)、1(男)、2（女）
     */
    private Integer sex;

    /**
     * 生日
     */
    private Date birthday;

    /**
     * 民族
     */
    private String nation;

    /**
     * 证件号码
     */
    private String credentialsNum;

    /**
     * 毕业院校
     */
    private String university;

    /**
     * 学历层次包括：
     	专科	专科学习
		专科(高职)	专科(高职)学习
		博士研究生	博士研究生学习
		夜大电大函大普通班	夜大电大函大普通班学习
		本科	本科学习
		硕士研究生	硕士研究生学习
		第二专科	第二专科学习
		第二学士学位	第二学士学位学习
     */
    private String degree;

    /**
     * 专业
     */
    private String major;

    /**
     * 学制
     */
    private Double schoolYears;

    /**
     * 学历类别包括:
       	开放教育	开放教育类学历
		成人	成人类学历
		成人高等教育	成人高等教育类学历
		普通	普通类学历
		普通高等教育	普通高等教育类学历
		研究生	硕士研究生类学历
		网络教育	网络教育类学历
		高等教育学历文凭考试	高等教育学历文凭考试类学历
		高等教育自学考试	高等教育自学考试类学历
     */
    private String degreeType;

    /**
     * 学习形式（普通全日制）
     	业余	业余层次学历
		全日制	全日制层次学历
		函授	函授层次学历
		夜大学	夜大学层次学历
		开放教育	开放教育层次学历
		普通全日制	普通全日制层次学历
		网络教育	网络教育层次学历
		脱产	脱产层次学历
		非全日制	非全日制层次学历
		*	部分硕士研究生会有这类返回
		空	无返回数据
     */
    private String educationStyle;

    /**
     * 分院
     */
    private String branch;

    /**
     * 系（所、函授站）
     */
    private String series;

    /**
     * 班级
     */
    private String className;

    /**
     * 学号
     */
    private String studentNum;

    /**
     * 入学时间
     */
    private Date enrolDate;

    /**
     * 毕业时间
     */
    private Date graduateDate;

    /**
     * 学籍状态
     */
    private String status;

    /**
     * 毕业照
     */
    private String graduationPhoto;

    /**
     * 录取照片
     */
    private String enrolPhoto;

    private Date createdAt;

    private Date updatedAt;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getCredentialsNum() {
        return credentialsNum;
    }

    public void setCredentialsNum(String credentialsNum) {
        this.credentialsNum = credentialsNum;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public Double getSchoolYears() {
        return schoolYears;
    }

    public void setSchoolYears(Double schoolYears) {
        this.schoolYears = schoolYears;
    }

    public String getDegreeType() {
        return degreeType;
    }

    public void setDegreeType(String degreeType) {
        this.degreeType = degreeType;
    }

    public String getEducationStyle() {
        return educationStyle;
    }

    public void setEducationStyle(String educationStyle) {
        this.educationStyle = educationStyle;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public String getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(String studentNum) {
        this.studentNum = studentNum;
    }

    public Date getEnrolDate() {
        return enrolDate;
    }

    public void setEnrolDate(Date enrolDate) {
        this.enrolDate = enrolDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGraduationPhoto() {
        return graduationPhoto;
    }

    public void setGraduationPhoto(String graduationPhoto) {
        this.graduationPhoto = graduationPhoto;
    }

    public String getEnrolPhoto() {
        return enrolPhoto;
    }

    public void setEnrolPhoto(String enrolPhoto) {
        this.enrolPhoto = enrolPhoto;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Date getGraduateDate() {
        return graduateDate;
    }

    public void setGraduateDate(Date graduateDate) {
        this.graduateDate = graduateDate;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }
}
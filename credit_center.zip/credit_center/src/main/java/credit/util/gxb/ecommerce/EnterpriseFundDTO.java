package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2019/1/2.
 */
public class EnterpriseFundDTO implements Serializable {
    private static final long serialVersionUID = -2180324241048998671L;
    private String tradeNumber;
    private String orderNumber;
    private String tradeDetailUrl;
    private String title;
    private Date tradeDatetime;
    private String tradeStatus;
    private String otherSide;
    private String otherSideAccount;
    private BigDecimal amount;
    private int tradeType;
    private int type;

    public String getTradeNumber() {
        return tradeNumber;
    }

    public void setTradeNumber(String tradeNumber) {
        this.tradeNumber = tradeNumber;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getTradeDetailUrl() {
        return tradeDetailUrl;
    }

    public void setTradeDetailUrl(String tradeDetailUrl) {
        this.tradeDetailUrl = tradeDetailUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getTradeDatetime() {
        return tradeDatetime;
    }

    public void setTradeDatetime(Date tradeDatetime) {
        this.tradeDatetime = tradeDatetime;
    }

    public String getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(String tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    public String getOtherSide() {
        return otherSide;
    }

    public void setOtherSide(String otherSide) {
        this.otherSide = otherSide;
    }

    public String getOtherSideAccount() {
        return otherSideAccount;
    }

    public void setOtherSideAccount(String otherSideAccount) {
        this.otherSideAccount = otherSideAccount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public int getTradeType() {
        return tradeType;
    }

    public void setTradeType(int tradeType) {
        this.tradeType = tradeType;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}

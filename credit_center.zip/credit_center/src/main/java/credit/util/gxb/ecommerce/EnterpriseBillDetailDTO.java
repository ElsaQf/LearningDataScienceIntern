package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by yaojun on 2018/12/25.
 */
public class EnterpriseBillDetailDTO implements Serializable {
    private static final long serialVersionUID = -3279058584110815349L;
    private BigDecimal amount;
    private Integer counts;
    private String title;

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Integer getCounts() {
        return counts;
    }

    public void setCounts(Integer counts) {
        this.counts = counts;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
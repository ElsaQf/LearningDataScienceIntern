package credit.util.gxb.ecommerce;

import java.io.Serializable;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 芝麻数据
 * @author YCM
 * @date 2018年12月21日 下午7:29:39
 */
public class ZmCredit implements Serializable {
    private static final long serialVersionUID = 8315376004389044098L;
    
    @Field(type = FieldType.Text)
    private String month; 
    
    @Field(type = FieldType.Text)
    private String zmScore;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getZmScore() {
		return zmScore;
	}

	public void setZmScore(String zmScore) {
		this.zmScore = zmScore;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}

package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by yaojun on 2018/12/25.
 */
public class EnterpriseBindInfoDTO implements Serializable {

    private static final long serialVersionUID = 1661492140538747834L;
    private String enterpriseName;
    private String loginName;
    private Date authTime;
    private String bindingMobilePhone;
    private Integer enterpriseZmScore;
    private Date evalDate;
    private List<EnterpriseAssociatedAccountDTO> associatedAccountList;

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public Date getAuthTime() {
        return authTime;
    }

    public void setAuthTime(Date authTime) {
        this.authTime = authTime;
    }

    public String getBindingMobilePhone() {
        return bindingMobilePhone;
    }

    public void setBindingMobilePhone(String bindingMobilePhone) {
        this.bindingMobilePhone = bindingMobilePhone;
    }

    public Integer getEnterpriseZmScore() {
        return enterpriseZmScore;
    }

    public void setEnterpriseZmScore(Integer enterpriseZmScore) {
        this.enterpriseZmScore = enterpriseZmScore;
    }

    public Date getEvalDate() {
        return evalDate;
    }

    public void setEvalDate(Date evalDate) {
        this.evalDate = evalDate;
    }

    public List<EnterpriseAssociatedAccountDTO> getAssociatedAccountList() {
        return associatedAccountList;
    }

    public void setAssociatedAccountList(List<EnterpriseAssociatedAccountDTO> associatedAccountList) {
        this.associatedAccountList = associatedAccountList;
    }
}
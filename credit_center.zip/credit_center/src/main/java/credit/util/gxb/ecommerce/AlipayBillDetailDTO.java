package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2018/8/13.
 */
public class AlipayBillDetailDTO implements Serializable {
    private static final long serialVersionUID = -4673533886511800521L;
    private Date billMonth;
    private BigDecimal expendAmount;
    private Integer expendCount;
    private BigDecimal incomeAmount;
    private Integer incomeCount;
    private BigDecimal payableAmount;
    private Integer payableCount;
    private BigDecimal receivableAmount;
    private Integer receivableCount;

    public Date getBillMonth() {
        return billMonth;
    }

    public void setBillMonth(Date billMonth) {
        this.billMonth = billMonth;
    }

    public BigDecimal getExpendAmount() {
        return expendAmount;
    }

    public void setExpendAmount(BigDecimal expendAmount) {
        this.expendAmount = expendAmount;
    }

    public Integer getExpendCount() {
        return expendCount;
    }

    public void setExpendCount(Integer expendCount) {
        this.expendCount = expendCount;
    }

    public BigDecimal getIncomeAmount() {
        return incomeAmount;
    }

    public void setIncomeAmount(BigDecimal incomeAmount) {
        this.incomeAmount = incomeAmount;
    }

    public Integer getIncomeCount() {
        return incomeCount;
    }

    public void setIncomeCount(Integer incomeCount) {
        this.incomeCount = incomeCount;
    }

    public BigDecimal getPayableAmount() {
        return payableAmount;
    }

    public void setPayableAmount(BigDecimal payableAmount) {
        this.payableAmount = payableAmount;
    }

    public Integer getPayableCount() {
        return payableCount;
    }

    public void setPayableCount(Integer payableCount) {
        this.payableCount = payableCount;
    }

    public BigDecimal getReceivableAmount() {
        return receivableAmount;
    }

    public void setReceivableAmount(BigDecimal receivableAmount) {
        this.receivableAmount = receivableAmount;
    }

    public Integer getReceivableCount() {
        return receivableCount;
    }

    public void setReceivableCount(Integer receivableCount) {
        this.receivableCount = receivableCount;
    }
}

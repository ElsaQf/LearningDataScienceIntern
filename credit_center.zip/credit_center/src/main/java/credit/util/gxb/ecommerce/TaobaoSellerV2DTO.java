package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yaojun on 2019/1/10.
 */
public class TaobaoSellerV2DTO implements Serializable {

    private static final long serialVersionUID = -8154201549683544268L;
    private List<TaobaoBOrderDTO> soldOrders;

    public List<TaobaoBOrderDTO> getSoldOrders() {
        return soldOrders;
    }

    public void setSoldOrders(List<TaobaoBOrderDTO> soldOrders) {
        this.soldOrders = soldOrders;
    }
}
package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 花呗账单
 * Created by DOmmy on 2017/12/6.
 */
public class TaobaoHuabeiBillDTO implements Serializable{
    private static final long serialVersionUID = -7730644763448592477L;
    
    /**
     * 账单月
     */
    private Date billMonth;
    /**
     * 是否出账
     */
    private Integer isBilled;
    /**
     * 总欠款额度
     */
    private BigDecimal totalAmount;
    /**
     * 未还款额度
     */
    private BigDecimal unRepayAmount;
    /**
     * 还款日
     */
    private Date repayDate;
    /**
     * 是否还清
     */
    private Integer isClear;
    /**
     * 是否逾期
     */
    private Integer isOverDue;
    /**
     * 总罚息
     */
    private BigDecimal totalPenalty;
    /**
     * 最小还款额
     */
    private BigDecimal miniAmount;
    /**
     * 历史账单是否结清
     */
    private Integer hasHistoryOvdBill;
    /**
     * 退款金额
     */
    private BigDecimal refundAmount;

    public Date getBillMonth() {
        return billMonth;
    }

    public void setBillMonth(Date billMonth) {
        this.billMonth = billMonth;
    }

    public Integer getIsBilled() {
        return isBilled;
    }

    public void setIsBilled(Integer isBilled) {
        this.isBilled = isBilled;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getUnRepayAmount() {
        return unRepayAmount;
    }

    public void setUnRepayAmount(BigDecimal unRepayAmount) {
        this.unRepayAmount = unRepayAmount;
    }

    public Date getRepayDate() {
        return repayDate;
    }

    public void setRepayDate(Date repayDate) {
        this.repayDate = repayDate;
    }

    public Integer getIsClear() {
        return isClear;
    }

    public void setIsClear(Integer isClear) {
        this.isClear = isClear;
    }

    public Integer getIsOverDue() {
        return isOverDue;
    }

    public void setIsOverDue(Integer isOverDue) {
        this.isOverDue = isOverDue;
    }

    public BigDecimal getTotalPenalty() {
        return totalPenalty;
    }

    public void setTotalPenalty(BigDecimal totalPenalty) {
        this.totalPenalty = totalPenalty;
    }

    public BigDecimal getMiniAmount() {
        return miniAmount;
    }

    public void setMiniAmount(BigDecimal miniAmount) {
        this.miniAmount = miniAmount;
    }

    public Integer getHasHistoryOvdBill() {
        return hasHistoryOvdBill;
    }

    public void setHasHistoryOvdBill(Integer hasHistoryOvdBill) {
        this.hasHistoryOvdBill = hasHistoryOvdBill;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }
}

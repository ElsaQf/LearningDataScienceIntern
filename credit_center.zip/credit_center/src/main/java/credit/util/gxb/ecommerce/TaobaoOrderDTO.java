package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by DOmmy on 2017/7/14.
 */
@JSONType(ignores = {"id","baseInfoId","userId","tradeStatus","tradeType"})
public class TaobaoOrderDTO implements Serializable{
    private static final long serialVersionUID = -7699756791083313323L;

    private Integer id;
    private Integer baseInfoId;
    private Integer userId;
    /**
     * 支付宝交易号
     */
    private String tradeNumber;
    /**
     * 订单交易号
     */
    private String orderNumber;
    private Integer tradeStatus;
    private String tradeStatusName;
    private Integer tradeType;
    private String tradeTypeName;
    private Date createTime;
    private Date payTime;
    private Date endTime;
    /**
     * 商品总数量
     */
    private Integer totalQuantity;
    /**
     * 邮费
     */
    private BigDecimal postFees;
    /**
     * 实付
     */
    private BigDecimal actualFee;
    private boolean virtualSign;
    /**
     * 收货地址
     */
    private EcommerceAddressDTO address;

    private TaobaoSellerDTO seller;

    private TaobaoLogisticsDTO logistics;

    private List<TaobaoSubOrderDTO> subOrders;

    private String invoiceName;
    private String taxNumber;
    private Integer mobileTradeStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getTradeNumber() {
        return tradeNumber;
    }

    public void setTradeNumber(String tradeNumber) {
        this.tradeNumber = tradeNumber;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Integer getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(Integer tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    public Integer getTradeType() {
        return tradeType;
    }

    public void setTradeType(Integer tradeType) {
        this.tradeType = tradeType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }


    public Date getPayTime() {
        return payTime;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(Integer totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public BigDecimal getPostFees() {
        return postFees;
    }

    public void setPostFees(BigDecimal postFees) {
        this.postFees = postFees;
    }

    public BigDecimal getActualFee() {
        return actualFee;
    }

    public void setActualFee(BigDecimal actualFee) {
        this.actualFee = actualFee;
    }

    public EcommerceAddressDTO getAddress() {
        return address;
    }

    public void setAddress(EcommerceAddressDTO address) {
        this.address = address;
    }

    public TaobaoSellerDTO getSeller() {
        return seller;
    }

    public void setSeller(TaobaoSellerDTO seller) {
        this.seller = seller;
    }

    public TaobaoLogisticsDTO getLogistics() {
        return logistics;
    }

    public void setLogistics(TaobaoLogisticsDTO logistics) {
        this.logistics = logistics;
    }

    public List<TaobaoSubOrderDTO> getSubOrders() {
        return subOrders;
    }

    public void setSubOrders(List<TaobaoSubOrderDTO> subOrders) {
        this.subOrders = subOrders;
    }

    public String getTradeStatusName() {
        return tradeStatusName;
    }

    public void setTradeStatusName(String tradeStatusName) {
        this.tradeStatusName = tradeStatusName;
    }

    public String getInvoiceName() {
        return invoiceName;
    }

    public void setInvoiceName(String invoiceName) {
        this.invoiceName = invoiceName;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getTradeTypeName() {
        return tradeTypeName;
    }

    public void setTradeTypeName(String tradeTypeName) {
        this.tradeTypeName = tradeTypeName;
    }

    public boolean isVirtualSign() {
        return virtualSign;
    }

    public void setVirtualSign(boolean virtualSign) {
        this.virtualSign = virtualSign;
    }

    public Integer getMobileTradeStatus() {
        return mobileTradeStatus;
    }

    public void setMobileTradeStatus(Integer mobileTradeStatus) {
        this.mobileTradeStatus = mobileTradeStatus;
    }
}

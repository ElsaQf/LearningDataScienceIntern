package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yaojun on 2019/1/10.
 */
public class MyBankV2DTO implements Serializable {

    private static final long serialVersionUID = -2695047537558415909L;
    private MyBankBindInfoDTO myBankBindInfo;
    private List<MyBankLoanDetailDTO> myBankLoanDetails;
    private List<MyBankAssetDetailDTO> myBankAssetDetails;
    private List<MyBankRepayPlanDTO> myBankRepayPlanList;
    private List<MyBankCreditInfoDTO> myBankCreditInfoList;

    public MyBankBindInfoDTO getMyBankBindInfo() {
        return myBankBindInfo;
    }

    public void setMyBankBindInfo(MyBankBindInfoDTO myBankBindInfo) {
        this.myBankBindInfo = myBankBindInfo;
    }

    public List<MyBankLoanDetailDTO> getMyBankLoanDetails() {
        return myBankLoanDetails;
    }

    public void setMyBankLoanDetails(List<MyBankLoanDetailDTO> myBankLoanDetails) {
        this.myBankLoanDetails = myBankLoanDetails;
    }

    public List<MyBankAssetDetailDTO> getMyBankAssetDetails() {
        return myBankAssetDetails;
    }

    public void setMyBankAssetDetails(List<MyBankAssetDetailDTO> myBankAssetDetails) {
        this.myBankAssetDetails = myBankAssetDetails;
    }

    public List<MyBankRepayPlanDTO> getMyBankRepayPlanList() {
        return myBankRepayPlanList;
    }

    public void setMyBankRepayPlanList(List<MyBankRepayPlanDTO> myBankRepayPlanList) {
        this.myBankRepayPlanList = myBankRepayPlanList;
    }

    public List<MyBankCreditInfoDTO> getMyBankCreditInfoList() {
        return myBankCreditInfoList;
    }

    public void setMyBankCreditInfoList(List<MyBankCreditInfoDTO> myBankCreditInfoList) {
        this.myBankCreditInfoList = myBankCreditInfoList;
    }
}

package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2018/6/4.
 */
public class MyBankRepayPlanDTO implements Serializable {
    private BigDecimal feeAmount;
    private BigDecimal totalAmount;
    private BigDecimal prinAmount;
    private Date repayDate;
    private String repayAccountNo;
    private String repayAccountType;

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getPrinAmount() {
        return prinAmount;
    }

    public void setPrinAmount(BigDecimal prinAmount) {
        this.prinAmount = prinAmount;
    }

    public Date getRepayDate() {
        return repayDate;
    }

    public void setRepayDate(Date repayDate) {
        this.repayDate = repayDate;
    }

    public String getRepayAccountNo() {
        return repayAccountNo;
    }

    public void setRepayAccountNo(String repayAccountNo) {
        this.repayAccountNo = repayAccountNo;
    }

    public String getRepayAccountType() {
        return repayAccountType;
    }

    public void setRepayAccountType(String repayAccountType) {
        this.repayAccountType = repayAccountType;
    }
}

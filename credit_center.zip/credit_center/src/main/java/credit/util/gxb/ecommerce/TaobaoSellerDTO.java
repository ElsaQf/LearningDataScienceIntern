package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;

/**
 * Created by DOmmy on 2017/7/14.
 */
@JSONType(ignores = {"id","baseInfoId","userId"})
public class TaobaoSellerDTO implements Serializable{
    private static final long serialVersionUID = 7955009021667314497L;

    private Integer id;
    private Integer baseInfoId;
    private Integer userId;

    private String shopId;
    private String shopName;
    private String nick;
    private String url;
    private String pic;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}

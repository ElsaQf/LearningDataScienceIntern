package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;

/**
 * Created by DOmmy on 2017/11/17.
 */
@JSONType(ignores = {"id", "userId", "baseInfoId"})
public class EcommerceTransferBankCardDTO implements Serializable{
    private static final long serialVersionUID = 3999400365482919652L;
    private Integer id;

    private Integer baseInfoId;

    private Integer userId;
    private String bankName;
    private String cardNumber;
    private String cardOwnerName;
    private String cardFullNumber;
    private String bankShortName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardOwnerName() {
        return cardOwnerName;
    }

    public void setCardOwnerName(String cardOwnerName) {
        this.cardOwnerName = cardOwnerName;
    }

    public String getCardFullNumber() {
        return cardFullNumber;
    }

    public void setCardFullNumber(String cardFullNumber) {
        this.cardFullNumber = cardFullNumber;
    }

    public String getBankShortName() {
        return bankShortName;
    }

    public void setBankShortName(String bankShortName) {
        this.bankShortName = bankShortName;
    }
}

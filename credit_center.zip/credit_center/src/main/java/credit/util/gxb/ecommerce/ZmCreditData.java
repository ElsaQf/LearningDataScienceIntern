package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.util.List;

/**
 * 芝麻数据
 * @author YCM
 * @date 2018年12月21日 下午7:29:39
 */
public class ZmCreditData implements Serializable {
    private static final long serialVersionUID = 8315376004389044098L;
    
    private List<ZmCredit> zmCredits;

	public List<ZmCredit> getZmCredits() {
		return zmCredits;
	}

	public void setZmCredits(List<ZmCredit> zmCredits) {
		this.zmCredits = zmCredits;
	}
    
}

package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by DOmmy on 2017/11/19.
 */
@JSONType(ignores = {"id", "userId", "baseInfoId","huabeiStatusCode","huabeiFrozenCode", "huabeiNextMonthPayment", "huabeiCurrentMonthPayment", "huabeiPayDay", "huabeiOverdueBillCnt", "huabeiOverdueDays","huabeiOnTrial", "huabeiFrozenCode", "huabeiHasAnyOverdue"})
public class EcommerceHuabeiInfoDTO implements Serializable{
    private static final long serialVersionUID = 5339380299393320757L;
    private Integer id;
    private Integer baseInfoId;
    private Integer userId;

    /**
     * 1: 花呗冻结，0: 花呗没冻结
     */
    private Integer huabeiStatus;
    /**
     * 花呗额度
     */
    private Integer huabeiAmount;
    /**
     * 花呗余额
     */
    private BigDecimal huabeiBalance;

    /**
     * 花呗罚息
     */
    private BigDecimal huabeiPenaltyAmount;

    /**
     * 花呗逾期天数
     */
    private Integer huabeiOverdueDays;
    /**
     * 花呗下月还款额
     *
     */
    private BigDecimal huabeiNextMonthPayment;

    /**
     * 花呗当月还款额
     *
     */
    private BigDecimal huabeiCurrentMonthPayment;

    /**
     * 花呗还款日
     *
     */
    private Integer huabeiPayDay;

    /**
     * 当前用户花呗逾期账单数
     *
     */
    private Integer huabeiOverdueBillCnt;
    /**
     * 花呗原始信用额度
     */
    private BigDecimal huabeiOriginalAmount;
    /**
     * 	花呗状态码（不展示
     */
    private String huabeiStatusCode;
    /**
     * 花呗被诉讼,1是0否
     */
    private Integer huabeiOnTrial;
    /**
     * 花呗冻结码（不展示）
     */
    private String huabeiFrozenCode;
    /**
     * 花呗逾期,1是0否
     */
    private Integer huabeiHasAnyOverdue;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBaseInfoId() {
        return baseInfoId;
    }

    public void setBaseInfoId(Integer baseInfoId) {
        this.baseInfoId = baseInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getHuabeiStatus() {
        return huabeiStatus;
    }

    public void setHuabeiStatus(Integer huabeiStatus) {
        this.huabeiStatus = huabeiStatus;
    }

    public Integer getHuabeiAmount() {
        return huabeiAmount;
    }

    public void setHuabeiAmount(Integer huabeiAmount) {
        this.huabeiAmount = huabeiAmount;
    }

    public BigDecimal getHuabeiBalance() {
        return huabeiBalance;
    }

    public void setHuabeiBalance(BigDecimal huabeiBalance) {
        this.huabeiBalance = huabeiBalance;
    }

    public BigDecimal getHuabeiPenaltyAmount() {
        return huabeiPenaltyAmount;
    }

    public void setHuabeiPenaltyAmount(BigDecimal huabeiPenaltyAmount) {
        this.huabeiPenaltyAmount = huabeiPenaltyAmount;
    }

    public Integer getHuabeiOverdueDays() {
        return huabeiOverdueDays;
    }

    public void setHuabeiOverdueDays(Integer huabeiOverdueDays) {
        this.huabeiOverdueDays = huabeiOverdueDays;
    }

    public BigDecimal getHuabeiNextMonthPayment() {
        return huabeiNextMonthPayment;
    }

    public void setHuabeiNextMonthPayment(BigDecimal huabeiNextMonthPayment) {
        this.huabeiNextMonthPayment = huabeiNextMonthPayment;
    }

    public BigDecimal getHuabeiCurrentMonthPayment() {
        return huabeiCurrentMonthPayment;
    }

    public void setHuabeiCurrentMonthPayment(BigDecimal huabeiCurrentMonthPayment) {
        this.huabeiCurrentMonthPayment = huabeiCurrentMonthPayment;
    }

    public Integer getHuabeiPayDay() {
        return huabeiPayDay;
    }

    public void setHuabeiPayDay(Integer huabeiPayDay) {
        this.huabeiPayDay = huabeiPayDay;
    }

    public Integer getHuabeiOverdueBillCnt() {
        return huabeiOverdueBillCnt;
    }

    public void setHuabeiOverdueBillCnt(Integer huabeiOverdueBillCnt) {
        this.huabeiOverdueBillCnt = huabeiOverdueBillCnt;
    }

    public BigDecimal getHuabeiOriginalAmount() {
        return huabeiOriginalAmount;
    }

    public void setHuabeiOriginalAmount(BigDecimal huabeiOriginalAmount) {
        this.huabeiOriginalAmount = huabeiOriginalAmount;
    }

    public String getHuabeiStatusCode() {
        return huabeiStatusCode;
    }

    public void setHuabeiStatusCode(String huabeiStatusCode) {
        this.huabeiStatusCode = huabeiStatusCode;
    }

    public Integer getHuabeiOnTrial() {
        return huabeiOnTrial;
    }

    public void setHuabeiOnTrial(Integer huabeiOnTrial) {
        this.huabeiOnTrial = huabeiOnTrial;
    }

    public String getHuabeiFrozenCode() {
        return huabeiFrozenCode;
    }

    public void setHuabeiFrozenCode(String huabeiFrozenCode) {
        this.huabeiFrozenCode = huabeiFrozenCode;
    }

    public Integer getHuabeiHasAnyOverdue() {
        return huabeiHasAnyOverdue;
    }

    public void setHuabeiHasAnyOverdue(Integer huabeiHasAnyOverdue) {
        this.huabeiHasAnyOverdue = huabeiHasAnyOverdue;
    }
}

package credit.util.gxb.ecommerce;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by yaojun on 2019/1/9.
 */
public class MyBankCreditInfoDTO implements Serializable {
    private static final long serialVersionUID = -8680415130947979312L;
    private BigDecimal creditAmount;
    private BigDecimal originLoanableAmount;
    private BigDecimal loanableAmount;
    private BigDecimal tempLoanAmount;
    private BigDecimal tempLoanAmountAdmit;
    private String productCode;
    private String loanTerm;
    private String repayModeName;
    private String loanTitle;
    private Date creditStartDate;
    private Date creditExpireDate;
    private BigDecimal dailyBaseRate;
    private BigDecimal intRatePricing;
    private BigDecimal dailyIntRatePricing;

    public BigDecimal getCreditAmount() {
        return creditAmount;
    }

    public void setCreditAmount(BigDecimal creditAmount) {
        this.creditAmount = creditAmount;
    }

    public BigDecimal getOriginLoanableAmount() {
        return originLoanableAmount;
    }

    public void setOriginLoanableAmount(BigDecimal originLoanableAmount) {
        this.originLoanableAmount = originLoanableAmount;
    }

    public BigDecimal getLoanableAmount() {
        return loanableAmount;
    }

    public void setLoanableAmount(BigDecimal loanableAmount) {
        this.loanableAmount = loanableAmount;
    }

    public BigDecimal getTempLoanAmount() {
        return tempLoanAmount;
    }

    public void setTempLoanAmount(BigDecimal tempLoanAmount) {
        this.tempLoanAmount = tempLoanAmount;
    }

    public BigDecimal getTempLoanAmountAdmit() {
        return tempLoanAmountAdmit;
    }

    public void setTempLoanAmountAdmit(BigDecimal tempLoanAmountAdmit) {
        this.tempLoanAmountAdmit = tempLoanAmountAdmit;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public String getRepayModeName() {
        return repayModeName;
    }

    public void setRepayModeName(String repayModeName) {
        this.repayModeName = repayModeName;
    }

    public String getLoanTitle() {
        return loanTitle;
    }

    public void setLoanTitle(String loanTitle) {
        this.loanTitle = loanTitle;
    }

    public Date getCreditStartDate() {
        return creditStartDate;
    }

    public void setCreditStartDate(Date creditStartDate) {
        this.creditStartDate = creditStartDate;
    }

    public Date getCreditExpireDate() {
        return creditExpireDate;
    }

    public void setCreditExpireDate(Date creditExpireDate) {
        this.creditExpireDate = creditExpireDate;
    }

    public BigDecimal getDailyBaseRate() {
        return dailyBaseRate;
    }

    public void setDailyBaseRate(BigDecimal dailyBaseRate) {
        this.dailyBaseRate = dailyBaseRate;
    }

    public BigDecimal getIntRatePricing() {
        return intRatePricing;
    }

    public void setIntRatePricing(BigDecimal intRatePricing) {
        this.intRatePricing = intRatePricing;
    }

    public BigDecimal getDailyIntRatePricing() {
        return dailyIntRatePricing;
    }

    public void setDailyIntRatePricing(BigDecimal dailyIntRatePricing) {
        this.dailyIntRatePricing = dailyIntRatePricing;
    }
}
package credit.util.gxb.ecommerce;

import java.io.Serializable;

/**
 * Created by yaojun on 2019/1/2.
 */
public class AlipayContactDTO implements Serializable {
    private static final long serialVersionUID = 2887707047376733805L;
    private String account;
    private String alipayUserId;
    private String realName;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAlipayUserId() {
        return alipayUserId;
    }

    public void setAlipayUserId(String alipayUserId) {
        this.alipayUserId = alipayUserId;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
}
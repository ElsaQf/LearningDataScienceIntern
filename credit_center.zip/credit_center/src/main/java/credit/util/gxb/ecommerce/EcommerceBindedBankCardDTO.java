package credit.util.gxb.ecommerce;

import com.alibaba.fastjson.annotation.JSONType;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * 
 * @author likun
 * @version $Id: EcommerceBindedBankCardDTO.java, v 0.1 May 18, 2016 8:33:08 PM likun Exp $
 */
@JSONType(ignores = {"id","baseInfoId","bankId","userId","status","createDate","lastUpdateDate"})
public class EcommerceBindedBankCardDTO implements Serializable {
  private Integer id;

  private Integer baseInfoId;

  private Integer userId;

  private Short bankId;

  private String bankName;

  private String cardNo;

  private Byte cardType;

  private String cardOwnerName;

  private Boolean isExpress;
  /**
   * 	银行标示
   */
  private String bankSign;
  /**
   * 开通时间
   */
  private String applyTime;
  /**
   * 银行卡号
   */
  private String cardFullNumber;

  private String signid;
  private String mobile;
  /**
   * 银行缩写
   */
  private String bankShortName;

  private Byte status;

  private Date createDate;

  private Date lastUpdateDate;

  private static final long serialVersionUID = 1L;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getBaseInfoId() {
    return baseInfoId;
  }

  public void setBaseInfoId(Integer baseInfoId) {
    this.baseInfoId = baseInfoId;
  }

  public Integer getUserId() {
    return userId;
  }

  public void setUserId(Integer userId) {
    this.userId = userId;
  }

  public Short getBankId() {
    return bankId;
  }

  public void setBankId(Short bankId) {
    this.bankId = bankId;
  }

  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName == null ? null : bankName.trim();
  }

  public String getCardNo() {
    return cardNo;
  }

  public void setCardNo(String cardNo) {
    this.cardNo = cardNo == null ? null : cardNo.trim();
  }

  public Byte getCardType() {
    return cardType;
  }

  public void setCardType(Byte cardType) {
    this.cardType = cardType;
  }

  public String getCardOwnerName() {
    return cardOwnerName;
  }

  public void setCardOwnerName(String cardOwnerName) {
    this.cardOwnerName = cardOwnerName == null ? null : cardOwnerName.trim();
  }

  public Boolean getIsExpress() {
    return isExpress;
  }

  public void setIsExpress(Boolean isExpress) {
    this.isExpress = isExpress;
  }

  public Byte getStatus() {
    return status;
  }

  public void setStatus(Byte status) {
    this.status = status;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  public Date getLastUpdateDate() {
    return lastUpdateDate;
  }

  public void setLastUpdateDate(Date lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  public String getBankSign() {
    return bankSign;
  }

  public void setBankSign(String bankSign) {
    this.bankSign = bankSign;
  }

  public String getApplyTime() {
    return applyTime;
  }

  public void setApplyTime(String applyTime) {
    this.applyTime = applyTime;
  }

  public String getCardFullNumber() {
    return cardFullNumber;
  }

  public void setCardFullNumber(String cardFullNumber) {
    this.cardFullNumber = cardFullNumber;
  }

  public String getSignid() {
    return signid;
  }

  public void setSignid(String signid) {
    this.signid = signid;
  }

  public String getMobile() {
    return mobile;
  }

  public void setMobile(String mobile) {
    this.mobile = mobile;
  }

  public String getBankShortName() {
    return bankShortName;
  }

  public void setBankShortName(String bankShortName) {
    this.bankShortName = bankShortName;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append(getClass().getSimpleName());
    sb.append(" [");
    sb.append("Hash = ").append(hashCode());
    sb.append(", id=").append(id);
    sb.append(", baseInfoId=").append(baseInfoId);
    sb.append(", userId=").append(userId);
    sb.append(", bankId=").append(bankId);
    sb.append(", bankName=").append(bankName);
    sb.append(", cardNo=").append(cardNo);
    sb.append(", cardType=").append(cardType);
    sb.append(", cardOwnerName=").append(cardOwnerName);
    sb.append(", isExpress=").append(isExpress);
    sb.append(", status=").append(status);
    sb.append(", createDate=").append(createDate);
    sb.append(", lastUpdateDate=").append(lastUpdateDate);
    sb.append("]");
    return sb.toString();
  }
}

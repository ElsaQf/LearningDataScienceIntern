package credit.util.sjmh.taobao;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 个人信息
 * @author YCM
 * @date 2018年12月13日 下午2:17:31
 */
@SuppressWarnings("serial")
public class BaseInfo implements Serializable {
	@Field(type = FieldType.Text) 
	private	String	user_name;//用户名。如:taobao123
	
	@Field(type = FieldType.Text) 
	private	String	email;//邮箱。如:123@qq.com
	
	@Field(type = FieldType.Text) 
	private	String	user_level;//用户级别
	
	@Field(type = FieldType.Text) 
	private	String	nick_name;//昵称
	
	@Field(type = FieldType.Text) 
	private	String	name;//真实姓名
	
	@Field(type = FieldType.Text) 
	private	String	gender;//性别。男、女
	
	@Field(type = FieldType.Text) 
	private	String	mobile;//绑定手机号。脱敏部分用＊
	
	@Field(type = FieldType.Text) 
	private	String real_name;//实名认证姓名。脱敏部分用＊
	
	@Field(type = FieldType.Text) 
	private	String identity_code;//实名认证身份证。脱敏部分用＊
	
	@Field(type = FieldType.Text) 
	private	String	vip_count;//淘气值
	
	@Field(type = FieldType.Integer) 
	private	Integer tmallScore;//天猫积分
	

	@Field(type = FieldType.Text) 
	private	String postCode;//淘宝个人信息中邮编
	
	@Field(type = FieldType.Text) 
	private	String detailAddress;//淘宝个人信息中详细地址
	
	@Field(type = FieldType.Text) 
	private	String weiboAccount;//淘宝绑定的微博账号
	
	@Field(type = FieldType.Text) 
	private	String weiboNickName;//淘宝绑定的微博妮称
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUser_level() {
		return user_level;
	}
	public void setUser_level(String user_level) {
		this.user_level = user_level;
	}
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getReal_name() {
		return real_name;
	}
	public void setReal_name(String real_name) {
		this.real_name = real_name;
	}
	public String getIdentity_code() {
		return identity_code;
	}
	public void setIdentity_code(String identity_code) {
		this.identity_code = identity_code;
	}
	public String getVip_count() {
		return vip_count;
	}
	public void setVip_count(String vip_count) {
		this.vip_count = vip_count;
	}
	public Integer getTmallScore() {
		return tmallScore;
	}
	public void setTmallScore(Integer tmallScore) {
		this.tmallScore = tmallScore;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getDetailAddress() {
		return detailAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}
	public String getWeiboAccount() {
		return weiboAccount;
	}
	public void setWeiboAccount(String weiboAccount) {
		this.weiboAccount = weiboAccount;
	}
	public String getWeiboNickName() {
		return weiboNickName;
	}
	public void setWeiboNickName(String weiboNickName) {
		this.weiboNickName = weiboNickName;
	}
	
}

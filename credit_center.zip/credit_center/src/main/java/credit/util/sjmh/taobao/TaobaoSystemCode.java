package credit.util.sjmh.taobao;

public enum TaobaoSystemCode {
	/**
	 * 0:"爬取成功"
	 */
	PROCESS_STATUS_0(0, "爬取成功"),
	
	/**
	 * 100:"任务正在处理中，稍后查询"
	 */
	PROCESS_STATUS_100(100, "任务正在处理中，稍后查询"),
	
	/**
	 * 2012:"任务创建成功"
	 */
	PROCESS_STATUS_2012(2012, "任务创建成功");
	
	private Integer key;
	private String message;

	private TaobaoSystemCode(Integer key, String message) {
		this.key = key;
		this.message = message;
	}

	public Integer getKey() {
		return this.key;
	}

	public String getMessage() {
		return message;
	}

	public static String getYysCodeMessage(Integer key) {
		for (TaobaoSystemCode c : TaobaoSystemCode.values()) {
			if (c.getKey().equals(key))
				return c.getMessage();
		}
		return "";
	}
}

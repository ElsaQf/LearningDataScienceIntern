package credit.util.sjmh.taobao;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 收货地址月度汇总
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class AddressMonthSummary implements Serializable {
	@Field(type = FieldType.Text)
	private String buy_month;//月份
	@Field(type = FieldType.Integer) 
	private	int buy_count;//次数
	@Field(type = FieldType.Float) 
	private float buy_amount;//金额
	public String getBuy_month() {
		return buy_month;
	}
	public void setBuy_month(String buy_month) {
		this.buy_month = buy_month;
	}
	public int getBuy_count() {
		return buy_count;
	}
	public void setBuy_count(int buy_count) {
		this.buy_count = buy_count;
	}
	public float getBuy_amount() {
		return buy_amount;
	}
	public void setBuy_amount(float buy_amount) {
		this.buy_amount = buy_amount;
	}
	 
}

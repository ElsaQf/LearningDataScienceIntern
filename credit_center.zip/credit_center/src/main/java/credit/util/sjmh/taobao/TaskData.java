package credit.util.sjmh.taobao;

import java.io.Serializable;
import java.util.List;

/**
 * task_data
 * 
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class TaskData implements Serializable {

	private BaseInfo base_info;// 个人信息
	private AccountInfo account_info;// 账户信息
	private List<AddressDetail> receiver_list;// 收货地址
	private List<OrderDetail> order_list;// 订单列表
	private List<HuabeiBillDetail> huabei_bill_list;// 花呗账单

	public BaseInfo getBase_info() {
		return base_info;
	}

	public void setBase_info(BaseInfo base_info) {
		this.base_info = base_info;
	}

	public AccountInfo getAccount_info() {
		return account_info;
	}

	public void setAccount_info(AccountInfo account_info) {
		this.account_info = account_info;
	}

	public List<AddressDetail> getReceiver_list() {
		return receiver_list;
	}

	public void setReceiver_list(List<AddressDetail> receiver_list) {
		this.receiver_list = receiver_list;
	}

	public List<OrderDetail> getOrder_list() {
		return order_list;
	}

	public void setOrder_list(List<OrderDetail> order_list) {
		this.order_list = order_list;
	}

	public List<HuabeiBillDetail> getHuabei_bill_list() {
		return huabei_bill_list;
	}

	public void setHuabei_bill_list(List<HuabeiBillDetail> huabei_bill_list) {
		this.huabei_bill_list = huabei_bill_list;
	}

}

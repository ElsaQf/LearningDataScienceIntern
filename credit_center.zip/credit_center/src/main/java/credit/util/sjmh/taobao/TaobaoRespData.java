package credit.util.sjmh.taobao;

import java.io.Serializable;

public class TaobaoRespData implements Serializable {
	private Integer code;
	private TbData data;

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public TbData getData() {
		return data;
	}

	public void setData(TbData data) {
		this.data = data;
	}

}

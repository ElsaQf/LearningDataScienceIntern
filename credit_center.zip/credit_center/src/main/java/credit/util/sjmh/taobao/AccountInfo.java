package credit.util.sjmh.taobao;

import java.io.Serializable;

/**
 * 账户信息
 * @author YCM
 * @date 2018年12月13日 下午2:17:47
 */
@SuppressWarnings("serial")
public class AccountInfo implements Serializable {
	
	private	Float	account_balance	;//账户余额。单位分
	private	Float	financial_account_balance;//余额宝余额。单位分
	private	Float	credit_quota;//花呗信用额度
	private	Float	consume_quota;//花呗已消费额度
	private	Float	available_quota;//花呗可用额度
	private	Float	jiebei_quota;//借呗额度
	private	String	zhima_point;//芝麻信用分
	private	String	huabei_overdue_status;//花呗当期逾期状态。0: 未逾期，1: 逾期
	private	String	huabei_overdue_history;//花呗历史逾期次数
	private	Float	huabei_curreny_penalty;//花呗当期逾期罚息。单位分
	private	Float	huabei_history_penalty;//花呗历史逾期罚息。单位分
	private	Float	jiebei_available_quota;//借呗可借额度。单位分
	private	Float	jiebei_valid_quota;//借呗有效额度。单位分
	private	Float	jiebei_consume_quota;//借呗已用额度。单位分
	private	String	jiebei_overdue_status;//借呗当期逾期状态。0: 未逾期，1: 逾期
	private	String	jiebei_overdue_history;//借呗历史逾期次数
	private	String	credit_point;//淘宝未使用该字段
	public Float getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(Float account_balance) {
		this.account_balance = account_balance;
	}
	public Float getFinancial_account_balance() {
		return financial_account_balance;
	}
	public void setFinancial_account_balance(Float financial_account_balance) {
		this.financial_account_balance = financial_account_balance;
	}
	public Float getCredit_quota() {
		return credit_quota;
	}
	public void setCredit_quota(Float credit_quota) {
		this.credit_quota = credit_quota;
	}
	public Float getConsume_quota() {
		return consume_quota;
	}
	public void setConsume_quota(Float consume_quota) {
		this.consume_quota = consume_quota;
	}
	public Float getAvailable_quota() {
		return available_quota;
	}
	public void setAvailable_quota(Float available_quota) {
		this.available_quota = available_quota;
	}
	public Float getJiebei_quota() {
		return jiebei_quota;
	}
	public void setJiebei_quota(Float jiebei_quota) {
		this.jiebei_quota = jiebei_quota;
	}
	public String getZhima_point() {
		return zhima_point;
	}
	public void setZhima_point(String zhima_point) {
		this.zhima_point = zhima_point;
	}
	public String getHuabei_overdue_status() {
		return huabei_overdue_status;
	}
	public void setHuabei_overdue_status(String huabei_overdue_status) {
		this.huabei_overdue_status = huabei_overdue_status;
	}
	public String getHuabei_overdue_history() {
		return huabei_overdue_history;
	}
	public void setHuabei_overdue_history(String huabei_overdue_history) {
		this.huabei_overdue_history = huabei_overdue_history;
	}
	public Float getHuabei_curreny_penalty() {
		return huabei_curreny_penalty;
	}
	public void setHuabei_curreny_penalty(Float huabei_curreny_penalty) {
		this.huabei_curreny_penalty = huabei_curreny_penalty;
	}
	public Float getHuabei_history_penalty() {
		return huabei_history_penalty;
	}
	public void setHuabei_history_penalty(Float huabei_history_penalty) {
		this.huabei_history_penalty = huabei_history_penalty;
	}
	public Float getJiebei_available_quota() {
		return jiebei_available_quota;
	}
	public void setJiebei_available_quota(Float jiebei_available_quota) {
		this.jiebei_available_quota = jiebei_available_quota;
	}
	public Float getJiebei_valid_quota() {
		return jiebei_valid_quota;
	}
	public void setJiebei_valid_quota(Float jiebei_valid_quota) {
		this.jiebei_valid_quota = jiebei_valid_quota;
	}
	public Float getJiebei_consume_quota() {
		return jiebei_consume_quota;
	}
	public void setJiebei_consume_quota(Float jiebei_consume_quota) {
		this.jiebei_consume_quota = jiebei_consume_quota;
	}
	public String getJiebei_overdue_status() {
		return jiebei_overdue_status;
	}
	public void setJiebei_overdue_status(String jiebei_overdue_status) {
		this.jiebei_overdue_status = jiebei_overdue_status;
	}
	public String getJiebei_overdue_history() {
		return jiebei_overdue_history;
	}
	public void setJiebei_overdue_history(String jiebei_overdue_history) {
		this.jiebei_overdue_history = jiebei_overdue_history;
	}
	public String getCredit_point() {
		return credit_point;
	}
	public void setCredit_point(String credit_point) {
		this.credit_point = credit_point;
	}
	 
}

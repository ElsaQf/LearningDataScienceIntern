package credit.util.sjmh.taobao;

import java.io.Serializable;

/**
 * task_data
 * 
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class TbData implements Serializable {

	private TaskData task_data;

	public TaskData getTask_data() {
		return task_data;
	}

	public void setTask_data(TaskData task_data) {
		this.task_data = task_data;
	}
 
}

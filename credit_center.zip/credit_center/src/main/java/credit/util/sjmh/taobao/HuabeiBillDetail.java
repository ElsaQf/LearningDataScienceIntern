package credit.util.sjmh.taobao;

import java.io.Serializable;

/**
 * 花呗账单
 * 
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class HuabeiBillDetail implements Serializable {

	private String month;// 账单年月 YYYY-MM
	private String bill_status;// 账单状态 已还清、已逾期、待还款
	private String account_cycle;// 记账周期 YYYY-MM-DD 至 YYYY-MM-DD
	private String account_date;// 出账日期 YYYY-MM-DD
	private String payment_deadline;// 最后还款日期 YYYY-MM-DD
	private int total_amount;// 账单总额 单位分
	private int remain_amount;// 剩余应还 单位分
	private int min_payment;// 最低应还 单位分
	private int refund_amount;// 退款金额 单位分
	private int payed_amount;// 已还金额 单位分

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getBill_status() {
		return bill_status;
	}

	public void setBill_status(String bill_status) {
		this.bill_status = bill_status;
	}

	public String getAccount_cycle() {
		return account_cycle;
	}

	public void setAccount_cycle(String account_cycle) {
		this.account_cycle = account_cycle;
	}

	public String getAccount_date() {
		return account_date;
	}

	public void setAccount_date(String account_date) {
		this.account_date = account_date;
	}

	public String getPayment_deadline() {
		return payment_deadline;
	}

	public void setPayment_deadline(String payment_deadline) {
		this.payment_deadline = payment_deadline;
	}

	public int getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	public int getRemain_amount() {
		return remain_amount;
	}

	public void setRemain_amount(int remain_amount) {
		this.remain_amount = remain_amount;
	}

	public int getMin_payment() {
		return min_payment;
	}

	public void setMin_payment(int min_payment) {
		this.min_payment = min_payment;
	}

	public int getRefund_amount() {
		return refund_amount;
	}

	public void setRefund_amount(int refund_amount) {
		this.refund_amount = refund_amount;
	}

	public int getPayed_amount() {
		return payed_amount;
	}

	public void setPayed_amount(int payed_amount) {
		this.payed_amount = payed_amount;
	}
}

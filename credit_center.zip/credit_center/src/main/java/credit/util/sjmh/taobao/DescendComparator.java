package credit.util.sjmh.taobao;

import java.util.Comparator;

public class DescendComparator implements Comparator{
	public int compare(Object obj1, Object obj2) {
        // 降序排序
		String i1=(String)obj1;
		String i2=(String)obj2;
        return -i1.compareTo(i2);
     }
}

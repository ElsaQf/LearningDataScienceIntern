package credit.util.sjmh.taobao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 收货地址
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class AddressDetail implements Serializable {
	@Field(type = FieldType.Text)
	private String uuid;//地址唯一标示
	@Field(type = FieldType.Text) 
	private	String name;//收货人
	@Field(type = FieldType.Text) 
	private	String area;//地区
	@Field(type = FieldType.Text) 
	private	String address;//地址
	@Field(type = FieldType.Text) 
	private	String mobile;//手机号码
	@Field(type = FieldType.Text) 
	private	String telephone;//固定电话
	@Field(type = FieldType.Text) 
	private	String zip_code;//收货地址邮编
	@Field(type = FieldType.Boolean) 
	private Boolean isDefaultAddress;//是否默认地址
	@Field(type = FieldType.Date) 
	private Date tradeTime;//交易时间
	@Field(type = FieldType.Object) 
	private List<AddressMonthSummary> month_summary;//月度汇总
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getZip_code() {
		return zip_code;
	}
	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}
	public Boolean getIsDefaultAddress() {
		return isDefaultAddress;
	}
	public void setIsDefaultAddress(Boolean isDefaultAddress) {
		this.isDefaultAddress = isDefaultAddress;
	}
	public Date getTradeTime() {
		return tradeTime;
	}
	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public List<AddressMonthSummary> getMonth_summary() {
		return month_summary;
	}
	public void setMonth_summary(List<AddressMonthSummary> month_summary) {
		this.month_summary = month_summary;
	}
	
}

package credit.util.sjmh.taobao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 订单列表
 * 
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")

public class OrderDetail implements Serializable {

	
	@Field(type = FieldType.Text) 
	private String order_id;// 订单号
	
	@Field(type = FieldType.Float) 
	private float order_amount;// 订单金额。单位分
	
	@Field(type = FieldType.Integer) 
	private Integer total_quantity;//商品数量
	
	@Field(type = FieldType.Text) 
	private String order_type;// 订单类型
	
	@Field(type = FieldType.Text) 
	private String order_time;// 订单时间。YYYY-MM-DD HH:MM:SS
	
	@Field(type = FieldType.Text) 
	private String order_status;// 订单状态
	
	@Field(type = FieldType.Text) 
	private String order_shop;// 商铺名称
	
	@Field(type = FieldType.Text) 
	private String receiver_uuid;//地址唯一标示
	
	@Field(type = FieldType.Text) 
	private String receiver_name;// 收货人
	
	@Field(type = FieldType.Text) 
	private String receiver_addr;// 收货地址
	
	@Field(type = FieldType.Text) 
	private String receiver_mobile;// 手机号码
	
	@Field(type = FieldType.Text) 
	private String receiver_telephone;// 固定电话
	
	@Field(type = FieldType.Text) 
	private String receiver_zipCode;// 订单收货邮编

	@Field(type = FieldType.Boolean)
	private Boolean virtualSign;//是否虚拟商品
	
	@Field(type = FieldType.Integer)
    private Integer mobileTradeStatus;//是否手机订单 0：非手机订单 1：手机订单
	
	@Field(type = FieldType.Object)  
	private List<ProductDetail> product_list;// 商品详情

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public float getOrder_amount() {
		return order_amount;
	}

	public void setOrder_amount(float order_amount) {
		this.order_amount = order_amount;
	}

	public String getOrder_type() {
		return order_type;
	}

	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}

	public String getOrder_time() {
		return order_time;
	}

	public void setOrder_time(String order_time) {
		this.order_time = order_time;
	}

	public String getOrder_status() {
		return order_status;
	}

	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}

	public String getOrder_shop() {
		return order_shop;
	}

	public void setOrder_shop(String order_shop) {
		this.order_shop = order_shop;
	}

	public String getReceiver_name() {
		return receiver_name;
	}

	public void setReceiver_name(String receiver_name) {
		this.receiver_name = receiver_name;
	}

	public String getReceiver_addr() {
		return receiver_addr;
	}

	public void setReceiver_addr(String receiver_addr) {
		this.receiver_addr = receiver_addr;
	}

	public String getReceiver_mobile() {
		return receiver_mobile;
	}

	public void setReceiver_mobile(String receiver_mobile) {
		this.receiver_mobile = receiver_mobile;
	}

	public String getReceiver_telephone() {
		return receiver_telephone;
	}

	public void setReceiver_telephone(String receiver_telephone) {
		this.receiver_telephone = receiver_telephone;
	}

	public String getReceiver_zipCode() {
		return receiver_zipCode;
	}

	public void setReceiver_zipCode(String receiver_zipCode) {
		this.receiver_zipCode = receiver_zipCode;
	}

	public List<ProductDetail> getProduct_list() {
		return product_list;
	}

	public void setProduct_list(List<ProductDetail> product_list) {
		this.product_list = product_list;
	}

	public Integer getTotal_quantity() {
		return total_quantity;
	}

	public void setTotal_quantity(Integer total_quantity) {
		this.total_quantity = total_quantity;
	}

	public Boolean getVirtualSign() {
		return virtualSign;
	}

	public void setVirtualSign(Boolean virtualSign) {
		this.virtualSign = virtualSign;
	}

	public Integer getMobileTradeStatus() {
		return mobileTradeStatus;
	}

	public void setMobileTradeStatus(Integer mobileTradeStatus) {
		this.mobileTradeStatus = mobileTradeStatus;
	}

	public String getReceiver_uuid() {
		return receiver_uuid;
	}

	public void setReceiver_uuid(String receiver_uuid) {
		this.receiver_uuid = receiver_uuid;
	}
	
}

package credit.util.sjmh.taobao;

import java.io.Serializable;

import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 商品详情
 * 
 * @author YCM
 * @date 2018年12月13日 下午2:16:54
 */
@SuppressWarnings("serial")
public class ProductDetail implements Serializable {
	
	@Field(type = FieldType.Text) 
	private String product_name;// 商品名称
	
	@Field(type = FieldType.Float) 
	private float product_price;// 商品单价。单位分
	
	@Field(type = FieldType.Integer) 
	private int product_amount;// 商品数量

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public float getProduct_price() {
		return product_price;
	}

	public void setProduct_price(float product_price) {
		this.product_price = product_price;
	}

	public int getProduct_amount() {
		return product_amount;
	}

	public void setProduct_amount(int product_amount) {
		this.product_amount = product_amount;
	}

}
